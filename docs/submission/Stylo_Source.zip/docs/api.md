# API contract

Source of truth for the Express API and the Android client. Schema: [erd.md](erd.md).
Decisions: [ADR-0005](adr/0005-api-contract-conventions.md), [ADR-0006](adr/0006-checkout-idempotency.md),
[ADR-0007](adr/0007-payment-confirmation-at-return.md). Ticket: [05](../.scratch/stylo-app/issues/05-dac-ta-api.md).

Base path `/api/v1`. The API serves JSON with `Content-Type: application/json; charset=utf-8`
except the three HTML pages the browser opens during payment.

---

## Conventions

| Rule | Value |
|---|---|
| Field names | `camelCase` in JSON; `snake_case` only inside the database |
| Enums | `SCREAMING_SNAKE_CASE` strings |
| IDs | JSON numbers |
| Money | Integer VND, never a decimal or a string |
| Timestamps | ISO-8601 UTC with milliseconds: `2026-11-04T03:12:45.123Z` |
| Calendar dates | `YYYY-MM-DD`, interpreted in `Asia/Ho_Chi_Minh` |
| Missing values | The field is present with `null`; never omitted |
| Unknown body fields | Rejected with `VALIDATION_FAILED` (Zod strict objects) |
| Unknown query params | Ignored |
| Success body | The resource itself, or `{ items, page, limit, total }` for a paginated list |
| Create | `201` plus the created resource; cart mutations are `200` with the whole cart |
| Delete | `204` with no body, except cart mutations, which return the whole cart with `200` |
| Error body | `{ "error": { "code", "message", "details?" } }` |
| Error `message` | English, for developers and logs; the client renders `code` in Vietnamese and never parses the message |
| Auth header | `Authorization: Bearer <accessToken>` |
| Versioning | Additive fields are not a breaking change; breaking changes move to `/api/v2` |

Bounded collections are returned as a plain array inside their parent and are not paginated:
addresses, product images, product variants, order items, payment attempts, receipt items.

### Pagination

| Param | Default | Rules |
|---|---|---|
| `page` | `1` | Integer ≥ 1; out of range returns an empty page, not a 404 |
| `limit` | `20` | Integer 1–100; outside the range is `VALIDATION_FAILED` |
| `total` | n/a | Total matching rows, ignoring pagination |

Every list is stable: the order always ends with `id` as a tie-breaker, so rows cannot jump
between pages while the user scrolls.

### Sorting

| Endpoint | `sort` values | Default |
|---|---|---|
| `GET /products` | `newest`, `price_asc`, `price_desc`, `name_asc` | `newest` |
| `GET /orders` | `newest`, `oldest` | `newest` |
| `GET /admin/products` | `newest`, `name_asc` | `newest` |
| `GET /admin/categories`, `GET /admin/brands` | `newest`, `name_asc` | `newest` |
| `GET /admin/users` | `newest`, `name_asc` | `newest` |
| `GET /admin/orders` | `newest`, `oldest` | `newest` |
| `GET /admin/inventory-receipts` | `newest`, `oldest` | `newest` |

An unknown `sort` value is `VALIDATION_FAILED`. `price_asc` and `price_desc` compare the
product's `minPrice`; `name_asc` uses the database collation.

### Dates, time zone

`from` and `to` are inclusive calendar days in `Asia/Ho_Chi_Minh`; the service converts them to
UTC boundaries before querying. `from > to` is `VALIDATION_FAILED`. A range longer than 366 days
is `VALIDATION_FAILED`. Omitting both parameters defaults to the last 30 days, ending today.

### Shipping fee

`SHIPPING_FEE` (integer VND, default `30000`) is read once per order and snapshotted into
`order.shipping_fee`. Changing the env value never changes an existing order.

---

## Error model

```json
{
  "error": {
    "code": "OUT_OF_STOCK",
    "message": "Not enough stock for the requested items.",
    "details": [
      { "sku": "AT-DEN-M", "requested": 3, "available": 2 }
    ]
  }
}
```

`details` is optional and its shape is fixed per code:

- `VALIDATION_FAILED`: `[{ "field": "email", "message": "Invalid email" }]`, one entry per error.
- `OUT_OF_STOCK`: `[{ "sku": "AT-DEN-M", "requested": 3, "available": 2 }]`.
- `ITEM_UNAVAILABLE`: `[{ "sku": "AT-DEN-M", "reason": "PRODUCT_INACTIVE" }]`; `reason` is
  `PRODUCT_INACTIVE` or `VARIANT_MISSING`.
- `INVALID_ORDER_STATE`: `{ "current": "SHIPPING", "target": "CANCELLED" }`.
- `IN_USE`: `{ "entity": "product", "id": 9 }`.

### Code catalogue

| Code | HTTP | When |
|---|---|---|
| `VALIDATION_FAILED` | 400 | Malformed JSON, failed Zod schema, invalid enum, unknown body field, bad date range |
| `UNAUTHORIZED` | 401 | Missing, expired or malformed access token |
| `INVALID_CREDENTIALS` | 401 | Wrong email or password (same response for both) |
| `INVALID_TOKEN` | 401 | Refresh token unknown, expired or revoked |
| `FORBIDDEN` | 403 | Authenticated user lacks the role for the endpoint |
| `ACCOUNT_DISABLED` | 403 | Login or refresh for a `DISABLED` account; also any request from one |
| `NOT_FOUND` | 404 | Missing row, row not owned by the caller, or inactive product on the storefront |
| `EMAIL_TAKEN` | 409 | Register with an existing email |
| `SKU_TAKEN` | 409 | Duplicate `sku` across variants |
| `VARIANT_EXISTS` | 409 | Duplicate `(size, color)` within one product |
| `NAME_TAKEN` | 409 | Duplicate category or brand name |
| `IN_USE` | 409 | Delete blocked by a foreign key: product, variant, category or brand |
| `OUT_OF_STOCK` | 409 | Cart quantity or checkout exceeds current stock |
| `ITEM_UNAVAILABLE` | 409 | Cart or checkout line whose product is inactive or whose variant is gone |
| `CART_EMPTY` | 409 | Checkout with no cart or no items |
| `INVALID_ORDER_STATE` | 409 | Transition or payment attempt not allowed from the current status |
| `ORDER_ALREADY_PAID` | 409 | Cancel, or a new attempt, on an order with `paidAt` set |
| `PAYMENT_NOT_ALLOWED` | 409 | Online payment attempt on a `COD` order |
| `CANNOT_DISABLE_SELF` | 409 | Admin disabling their own account |
| `FILE_TOO_LARGE` | 413 | Product image over 5 MB |
| `INTERNAL` | 500 | Unhandled error; the response never leaks a stack trace or SQL |

Ownership errors are deliberately `NOT_FOUND`, not `FORBIDDEN`: the API must not confirm that
another customer's order or address exists.

---

## Objects

```ts
type User = {
  id: number;
  email: string;
  fullName: string;
  phone: string | null;
  role: "CUSTOMER" | "ADMIN";
  status: "ACTIVE" | "DISABLED";
  createdAt: string;
  updatedAt: string;
};

type Address = {
  id: number;
  recipientName: string;
  phone: string;
  line: string;
  isDefault: boolean;
  createdAt: string;
  updatedAt: string;
};

type CategoryRef = { id: number; name: string };
type BrandRef = { id: number; name: string };

type ProductImage = { id: number; url: string; position: number };

type Variant = {
  id: number;
  sku: string;
  size: string;
  color: string;
  price: number;
  stock: number;
};

type ProductCard = {
  id: number;
  name: string;
  coverUrl: string | null;   // product_image with position 0, else null
  minPrice: number | null;   // over variants with stock > 0
  maxPrice: number | null;
  category: CategoryRef;
  brand: BrandRef;
};

type ProductDetail = {
  id: number;
  name: string;
  description: string | null;
  category: CategoryRef;
  brand: BrandRef;
  images: ProductImage[];    // sorted by position
  variants: Variant[];       // sorted by id, including stock = 0
  minPrice: number | null;
  maxPrice: number | null;
  createdAt: string;
  updatedAt: string;
};

type CartItem = {
  id: number;
  variantId: number;
  sku: string;
  productId: number;
  productName: string;
  imageUrl: string | null;
  size: string;
  color: string;
  unitPrice: number;         // current price, not the price when added
  quantity: number;
  lineTotal: number;         // unitPrice * quantity
  availableStock: number;
  available: boolean;        // false when the product is inactive
};

type Cart = {
  id: number | null;         // null until the first item is added
  items: CartItem[];
  itemCount: number;         // sum of quantities of all lines
  subtotal: number;          // sum of lineTotal over available lines only
};

type OrderItem = {
  id: number;
  productId: number;
  variantId: number;
  productName: string;
  sku: string;
  size: string;
  color: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
};

type OrderSummary = {
  id: number;
  code: string;
  status: "PENDING" | "CONFIRMED" | "SHIPPING" | "DELIVERED" | "CANCELLED";
  paymentMethod: "COD" | "ONLINE";
  paymentStatus: "UNPAID" | "PAID" | "FAILED";
  total: number;
  itemCount: number;
  createdAt: string;
};

type Order = {
  id: number;
  code: string;
  status: "PENDING" | "CONFIRMED" | "SHIPPING" | "DELIVERED" | "CANCELLED";
  paymentMethod: "COD" | "ONLINE";
  paymentStatus: "UNPAID" | "PAID" | "FAILED";
  subtotal: number;
  shippingFee: number;
  total: number;
  note: string | null;
  recipientName: string;
  recipientPhone: string;
  shippingAddress: string;
  items: OrderItem[];
  paidAt: string | null;
  createdAt: string;
  updatedAt: string;
};

type PaymentAttempt = {
  id: number;
  txnRef: string;
  provider: "MOCK" | "VNPAY";
  status: "PENDING" | "SUCCEEDED" | "FAILED";
  amount: number;
  paymentUrl: string;        // rebuilt on read, never stored
  failureReason: string | null;
  createdAt: string;
};

type Payment = Omit<PaymentAttempt, "paymentUrl">;
```

`paymentStatus` is derived, never stored: `PAID` when `paidAt` is set; else `FAILED` when the
latest attempt is `FAILED`; else `UNPAID`.

Admin-only shapes:

```ts
type AdminProductSummary = {
  id: number;
  name: string;
  status: "ACTIVE" | "INACTIVE";
  category: CategoryRef;
  brand: BrandRef;
  coverUrl: string | null;   // product_image with position 0, else null
  variantCount: number;
  totalStock: number;        // SUM(variant.stock)
  minPrice: number | null;   // over all variants, including stock = 0
  maxPrice: number | null;
  createdAt: string;
  updatedAt: string;
};

type AdminOrderDetail = {
  id: number;
  code: string;
  status: Order["status"];
  paymentMethod: Order["paymentMethod"];
  paymentStatus: Order["paymentStatus"];
  customer: { id: number; email: string; fullName: string; phone: string | null };
  subtotal: number;
  shippingFee: number;
  total: number;
  note: string | null;
  recipientName: string;
  recipientPhone: string;
  shippingAddress: string;
  items: (OrderItem & { unitCost: number | null })[];
  payments: Payment[];
  paidAt: string | null;
  createdAt: string;
  updatedAt: string;
};

type InventoryReceiptItem = {
  id: number;
  variantId: number;
  sku: string;
  productName: string;
  size: string;
  color: string;
  quantity: number;
  unitCost: number;
  lineTotal: number;
};

type InventoryReceipt = {
  id: number;
  code: string;
  supplier: string;
  note: string | null;
  totalCost: number;
  itemCount: number;         // number of lines, not the sum of their quantities
  createdBy: { id: number; fullName: string };
  items: InventoryReceiptItem[];  // detail only
  createdAt: string;
};
```

---

## Auth

### `POST /auth/register`

Body: `email` (≤ 255, valid, lowercased by the service), `password` (8–100), `fullName`
(1–100), `phone` (optional, ≤ 20). The account is always `CUSTOMER` and `ACTIVE`.

```json
{
  "email": "an@example.com",
  "password": "matkhau123",
  "fullName": "Nguyễn Văn An",
  "phone": "0901234567"
}
```

`201`:

```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOjcsInJvbGUiOiJDVVNUT01FUiJ9.signature",
  "refreshToken": "0f9c1c2e8b7a4d6f9a3e5c1b2d4f6a8c9e0b1d2c3a4f5e6b7c8d9e0f1a2b3c4d",
  "user": {
    "id": 7,
    "email": "an@example.com",
    "fullName": "Nguyễn Văn An",
    "phone": "0901234567",
    "role": "CUSTOMER",
    "status": "ACTIVE",
    "createdAt": "2026-11-04T03:12:45.123Z",
    "updatedAt": "2026-11-04T03:12:45.123Z"
  }
}
```

Errors: `VALIDATION_FAILED`, `EMAIL_TAKEN`.

### `POST /auth/login`

Body `{ "email", "password" }`. `200` with the same shape as register.
Errors: `VALIDATION_FAILED`, `INVALID_CREDENTIALS`, `ACCOUNT_DISABLED`.

### `POST /auth/refresh`

Body `{ "refreshToken": "..." }`. No auth header.

`200`:

```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOjcsInJvbGUiOiJDVVNUT01FUiJ9.new",
  "refreshToken": "9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b"
}
```

Every refresh rotates: the presented token gets `revokedAt` and a new token is issued. Presenting
a revoked or expired token is `INVALID_TOKEN`; there is no reuse-detection chain revoke.
Concurrent refreshes with the same token: exactly one succeeds.

Errors: `VALIDATION_FAILED`, `INVALID_TOKEN`, `ACCOUNT_DISABLED`.

### `POST /auth/logout`

Body `{ "refreshToken": "..." }`. Returns `204`, also when the token is already revoked or
unknown. Owning the refresh token is enough; no access token is required.

### `GET /me`

`200` with `User`.

### `PATCH /me`

Body with at least one of `fullName`, `phone`; `phone: null` clears it. Email, role and status
are not editable here (strict body).

```json
{ "fullName": "Nguyễn Văn An", "phone": "0912345678" }
```

`200` with `User`. Errors: `VALIDATION_FAILED`, `UNAUTHORIZED`, `ACCOUNT_DISABLED`.

---

## Addresses

All endpoints operate on the caller's own addresses; another user's id is `NOT_FOUND`.

### `GET /me/addresses`

Bounded list, default first, then newest first.

```json
{
  "items": [
    {
      "id": 11,
      "recipientName": "Nguyễn Văn An",
      "phone": "0901234567",
      "line": "12 Nguyễn Trãi, P. Bến Thành, Q.1, TP.HCM",
      "isDefault": true,
      "createdAt": "2026-11-01T09:00:00.000Z",
      "updatedAt": "2026-11-01T09:00:00.000Z"
    }
  ]
}
```

### `POST /me/addresses`

Body `{ recipientName, phone, line, isDefault? }`. The first address is always the default.

`201` with `Address`. Errors: `VALIDATION_FAILED`.

### `PATCH /me/addresses/:id`

Partial body of the same fields. `isDefault: true` clears the previous default in the same
transaction; `isDefault: false` is `VALIDATION_FAILED` (unset the default by setting another).
`200` with `Address`. Errors: `VALIDATION_FAILED`, `NOT_FOUND`.

### `DELETE /me/addresses/:id`

`204`. If the deleted row was the default, the oldest remaining address becomes the default.
Errors: `NOT_FOUND`.

---

## Catalog

Public; no auth. Only `ACTIVE` products are visible; a `INACTIVE` product is `NOT_FOUND`, also
by direct id.

### `GET /products`

| Param | Rules |
|---|---|
| `q` | ≤ 100 chars; matches product name, brand name or category name, accent-insensitive |
| `categoryId`, `brandId` | Integer; an unknown id matches nothing |
| `color` | Exact value from `GET /catalog/filters`, accent- and case-insensitive |
| `size` | Exact value from `GET /catalog/filters` |
| `minPrice`, `maxPrice` | Integer ≥ 0; `minPrice > maxPrice` is `VALIDATION_FAILED` |
| `sort`, `page`, `limit` | See conventions |

A product matches when **one variant** satisfies every variant-level filter (`color`, `size`,
`minPrice`, `maxPrice`) and that variant has `stock > 0`. `q`, `categoryId` and `brandId` apply
to the product itself. The listing excludes products with no sellable variant.

`200`:

```json
{
  "items": [
    {
      "id": 9,
      "name": "Áo thun cotton",
      "coverUrl": "/uploads/products/9a1c.jpg",
      "minPrice": 199000,
      "maxPrice": 229000,
      "category": { "id": 2, "name": "Áo thun" },
      "brand": { "id": 3, "name": "Stylo" }
    }
  ],
  "page": 1,
  "limit": 20,
  "total": 1
}
```

`minPrice` and `maxPrice` are computed over all in-stock variants, not only the ones that
matched a price filter.

### `GET /products/:id`

`200` with `ProductDetail`:

```json
{
  "id": 9,
  "name": "Áo thun cotton",
  "description": "Cotton 100%, form rộng.",
  "category": { "id": 2, "name": "Áo thun" },
  "brand": { "id": 3, "name": "Stylo" },
  "images": [
    { "id": 31, "url": "/uploads/products/9a1c.jpg", "position": 0 },
    { "id": 32, "url": "/uploads/products/9a1d.jpg", "position": 1 }
  ],
  "variants": [
    { "id": 44, "sku": "AT-DEN-M", "size": "M", "color": "Đen", "price": 199000, "stock": 5 },
    { "id": 45, "sku": "AT-DEN-L", "size": "L", "color": "Đen", "price": 199000, "stock": 0 }
  ],
  "minPrice": 199000,
  "maxPrice": 199000,
  "createdAt": "2026-10-20T02:00:00.000Z",
  "updatedAt": "2026-10-20T02:00:00.000Z"
}
```

`minPrice`/`maxPrice` are `null` when every variant has `stock = 0`.

### `GET /catalog/filters`

Values are computed from sellable data only: `ACTIVE` products with at least one variant with
`stock > 0`, plus the `ACTIVE` categories and brands referenced by them.

```json
{
  "categories": [{ "id": 2, "name": "Áo thun" }],
  "brands": [{ "id": 3, "name": "Stylo" }],
  "colors": ["Be", "Đen", "Trắng"],
  "sizes": ["L", "M", "S"],
  "priceRange": { "min": 199000, "max": 899000 }
}
```

`priceRange` is `{ "min": null, "max": null }` when nothing is sellable. Colors and sizes are
sorted by the database collation; the client may re-order sizes for display.

---

## Cart

Requires an authenticated user. One cart per user; it is created on the first add. Every
mutation returns the whole `Cart` with `200`, so the client has one source of truth.

### `GET /cart`

```json
{
  "id": 7,
  "items": [
    {
      "id": 21,
      "variantId": 44,
      "sku": "AT-DEN-M",
      "productId": 9,
      "productName": "Áo thun cotton",
      "imageUrl": "/uploads/products/9a1c.jpg",
      "size": "M",
      "color": "Đen",
      "unitPrice": 199000,
      "quantity": 2,
      "lineTotal": 398000,
      "availableStock": 5,
      "available": true
    }
  ],
  "itemCount": 2,
  "subtotal": 398000
}
```

No cart yet returns `{ "id": null, "items": [], "itemCount": 0, "subtotal": 0 }`.

Lines whose product became `INACTIVE` stay visible with `available: false` and are excluded
from `subtotal`; checkout rejects them with `ITEM_UNAVAILABLE`. Prices are always the current
variant price.

### `POST /cart/items`

Body `{ "variantId": 44, "quantity": 2 }`. Adding an existing variant sums the quantities.
`200` with `Cart`.

Errors: `VALIDATION_FAILED`, `NOT_FOUND` (variant does not exist), `ITEM_UNAVAILABLE`,
`OUT_OF_STOCK` (the resulting quantity exceeds stock; no silent clamp).

### `PATCH /cart/items/:itemId`

Body `{ "quantity": 3 }`, `1 ≤ quantity ≤ stock`. `200` with `Cart`.
Errors: `VALIDATION_FAILED`, `NOT_FOUND`, `OUT_OF_STOCK`.

### `DELETE /cart/items/:itemId`

`200` with `Cart`. A line not in the caller's cart is `NOT_FOUND`.

### `DELETE /cart`

Empties the cart and returns it: `{ "id": null, "items": [], "itemCount": 0, "subtotal": 0 }`.

---

## Orders

Requires an authenticated user. Customers see only their own orders; another user's order is
`NOT_FOUND`.

### `POST /orders`

```json
{
  "clientOrderId": "3f0c2b7e-8a41-4f6d-9c2e-1b5a7d9e0f12",
  "addressId": 11,
  "paymentMethod": "ONLINE",
  "note": "Giao giờ hành chính"
}
```

| Field | Rules |
|---|---|
| `clientOrderId` | Required UUID; unique per user; sent again on every retry |
| `addressId` | Must belong to the caller |
| `paymentMethod` | `COD` or `ONLINE` |
| `note` | Optional, ≤ 255 chars; empty string becomes `null` |

The body is strict: `items`, prices, totals or any other field are rejected. The server reads
the caller's cart and recomputes everything.

`201`:

```json
{
  "order": {
    "id": 123,
    "code": "STY-261104-A7K2",
    "status": "PENDING",
    "paymentMethod": "ONLINE",
    "paymentStatus": "UNPAID",
    "subtotal": 398000,
    "shippingFee": 30000,
    "total": 428000,
    "note": "Giao giờ hành chính",
    "recipientName": "Nguyễn Văn An",
    "recipientPhone": "0901234567",
    "shippingAddress": "12 Nguyễn Trãi, P. Bến Thành, Q.1, TP.HCM",
    "items": [
      {
        "id": 501,
        "productId": 9,
        "variantId": 44,
        "productName": "Áo thun cotton",
        "sku": "AT-DEN-M",
        "size": "M",
        "color": "Đen",
        "unitPrice": 199000,
        "quantity": 2,
        "lineTotal": 398000
      }
    ],
    "paidAt": null,
    "createdAt": "2026-11-04T03:20:00.000Z",
    "updatedAt": "2026-11-04T03:20:00.000Z"
  },
  "payment": {
    "id": 88,
    "txnRef": "STY261104032000123",
    "provider": "VNPAY",
    "status": "PENDING",
    "amount": 428000,
    "paymentUrl": "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html?vnp_TxnRef=STY261104032000123",
    "failureReason": null,
    "createdAt": "2026-11-04T03:20:00.000Z"
  }
}
```

`payment` is `null` for `COD`. For `ONLINE`, the order and the first payment attempt are created
in the same transaction.

Repeating the same `clientOrderId` (same user) returns `200` with the existing order and, for
`ONLINE`, its current `PENDING` attempt with a rebuilt `paymentUrl` (`payment` is `null` when no
`PENDING` attempt exists); it does not touch stock, the cart or the payment table. A different
user reusing the UUID creates their own order.

Checkout is one transaction: lock every referenced variant `FOR UPDATE` in ascending `id` order,
re-check status/stock, snapshot product, price, cost and address, insert order and items,
decrement stock and insert `SALE` movements, delete the cart items, and for `ONLINE` insert the
`PENDING` payment attempt. Any failure rolls everything back and leaves the cart intact.

Errors: `VALIDATION_FAILED`, `NOT_FOUND` (address), `CART_EMPTY`, `OUT_OF_STOCK`,
`ITEM_UNAVAILABLE`, `INTERNAL`. Stock errors list **every** failing variant in `details`.

### `GET /orders`

Query: `status` (optional), `sort`, `page`, `limit`. `200` with `OrderSummary` items:

```json
{
  "items": [
    {
      "id": 123,
      "code": "STY-261104-A7K2",
      "status": "PENDING",
      "paymentMethod": "ONLINE",
      "paymentStatus": "UNPAID",
      "total": 428000,
      "itemCount": 2,
      "createdAt": "2026-11-04T03:20:00.000Z"
    }
  ],
  "page": 1,
  "limit": 20,
  "total": 1
}
```

### `GET /orders/:id`

`200` with `Order` (no `unitCost`, no payment attempts). Errors: `NOT_FOUND`.

### `POST /orders/:id/cancel`

No body. Allowed for the owning customer while the order is `PENDING` or `CONFIRMED`, and while
`paidAt` is still `null`. Cancelling restocks every item and appends `CANCEL_RESTOCK` movements
in the same transaction.

`200` with the updated `Order`. Errors: `NOT_FOUND`, `INVALID_ORDER_STATE`,
`ORDER_ALREADY_PAID`.

---

## Payments

### `POST /orders/:id/payments`

Creates or reuses an online attempt for the caller's own order. No body.

| Condition | Result |
|---|---|
| Order not `ONLINE` | `409 PAYMENT_NOT_ALLOWED` |
| `paidAt` set | `409 ORDER_ALREADY_PAID` |
| Status not `PENDING` or `CONFIRMED` | `409 INVALID_ORDER_STATE` |
| Latest attempt `PENDING` and younger than 15 minutes | `200` with that attempt, URL rebuilt |
| Latest attempt `PENDING` and older than 15 minutes | Mark it `FAILED` with `EXPIRED`, create a new one |
| Latest attempt `FAILED`, or no attempt | Create a new one, `201` |

Only one `PENDING` attempt exists at a time: the endpoint locks the order row, so a double tap
cannot create two. Previously `FAILED` attempts are never reused.

```json
{
  "id": 89,
  "txnRef": "STY261104032530456",
  "provider": "VNPAY",
  "status": "PENDING",
  "amount": 428000,
  "paymentUrl": "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html?vnp_TxnRef=STY261104032530456",
  "failureReason": null,
  "createdAt": "2026-11-04T03:25:30.000Z"
}
```

Errors: `NOT_FOUND`, `PAYMENT_NOT_ALLOWED`, `ORDER_ALREADY_PAID`, `INVALID_ORDER_STATE`.

### `GET /payments/:txnRef`

Owner or admin. Used by the app to poll after the browser returns.

```json
{
  "txnRef": "STY261104032000123",
  "provider": "VNPAY",
  "status": "SUCCEEDED",
  "amount": 428000,
  "orderId": 123,
  "orderCode": "STY-261104-A7K2",
  "failureReason": null,
  "createdAt": "2026-11-04T03:20:00.000Z",
  "updatedAt": "2026-11-04T03:21:12.000Z"
}
```

Errors: `NOT_FOUND`, `UNAUTHORIZED`.

### `GET /payments/vnpay/return`

Browser-facing. VNPay redirects here after the customer pays. The response is an HTML page in
Vietnamese, **not** the JSON error envelope.

- Signature invalid → `400` HTML, no state change.
- `txnRef` unknown → `404` HTML.
- Amount differs from `payment.amount` → HTML failure page, attempt marked `FAILED`
  (`AMOUNT_MISMATCH`).
- `vnp_ResponseCode`/`vnp_TransactionStatus` not `00` → HTML failure page, attempt marked
  `FAILED` with the gateway code.
- Success → confirm the attempt and the order, HTML success page with order code and amount.
- An already `SUCCEEDED` attempt renders the success page; it is not an error.

### `GET /payments/vnpay/ipn`

Server-to-server, no auth. Always HTTP `200` with VNPay's JSON contract:

```json
{ "RspCode": "00", "Message": "Confirm Success" }
```

| Case | `RspCode` | Message | Side effect |
|---|---|---|---|
| Success | `00` | `Confirm Success` | attempt `SUCCEEDED`, `paidAt` set once, order `PENDING → CONFIRMED` |
| `txnRef` unknown | `01` | `Order not found` | none |
| Amount mismatch | `04` | `Invalid amount` | attempt `FAILED`, `AMOUNT_MISMATCH` |
| Bad signature | `97` | `Invalid signature` | none |
| Already `SUCCEEDED` | `00` | `Confirm Success` | none |
| Anything unexpected | `99` | `Unknown error` | none |

A signature is verified before any read or write that changes state. A `FAILED` attempt may still
become `SUCCEEDED` from a genuine gateway callback: the money moved, so the local state follows.
`SUCCEEDED` is terminal.

`paidAt` is written exactly once. If it is already set, the callback still gets `00`.

### Mock provider

Available only when `PAYMENT_PROVIDER=MOCK` **and** the attempt's `provider` is `MOCK`;
otherwise both endpoints are `404`.

`GET /payments/mock/:txnRef` renders a Vietnamese page with the order code, amount, and two
buttons.

`POST /payments/mock/:txnRef/complete` accepts form field `result=success|failed`:
success runs the same confirm service as IPN (attempt `SUCCEEDED`, `paidAt`, order confirmed),
failure marks the attempt `FAILED` with `MOCK_FAILED`. The response is the HTML result page; a
repeated submit is idempotent. There is no auth on these two routes, because a browser, not the
app, opens them; the `txnRef` is the capability.

`PUBLIC_BASE_URL` builds `vnp_ReturnUrl` and the mock URL. It must be the host reachable from the
device browser (LAN IP, not `localhost`).

---

## Admin

Every `/admin/**` route requires `Role.ADMIN`; a customer gets `403 FORBIDDEN`.
All bodies are strict.

### Categories and brands

`GET /admin/categories?q&status&sort&page&limit` → paginated
`{ id, name, status, productCount, createdAt, updatedAt }`.
`POST /admin/categories` body `{ "name": "Áo thun" }` → `201`.
`PATCH /admin/categories/:id` body `{ "name"?, "status"? }` → `200`.
`DELETE /admin/categories/:id` → `204`; if products reference it → `409 IN_USE`.

The same four routes exist for brands, with identical rules and shapes:
`GET /admin/brands?q&status&sort&page&limit`, `POST /admin/brands`, `PATCH /admin/brands/:id`,
`DELETE /admin/brands/:id`.
Errors: `VALIDATION_FAILED`, `NAME_TAKEN`, `NOT_FOUND`, `IN_USE`.

### Products

`GET /admin/products?q&status&categoryId&brandId&sort&page&limit` → paginated
`AdminProductSummary` items. `q` matches the product name.

`GET /admin/products/:id` → full product: `id`, `name`, `description`, `status`, `category`,
`brand`, `images`, `variants` (with `stock`), `minPrice`, `maxPrice`, timestamps. Works for
`INACTIVE` products.

`POST /admin/products`:

```json
{
  "name": "Áo thun cotton",
  "description": "Cotton 100%, form rộng.",
  "categoryId": 2,
  "brandId": 3,
  "status": "ACTIVE"
}
```

`201` with the product. A new product has no variants and no images, so it does not appear on
the storefront until a variant with stock exists. Errors: `VALIDATION_FAILED`, `NOT_FOUND`
(category/brand).

`PATCH /admin/products/:id` accepts `name`, `description`, `categoryId`, `brandId`, `status`.
`200` with the product. `status: "INACTIVE"` hides it from the storefront; `stock` is not a
product field.

`DELETE /admin/products/:id` → `204` only when no order item, receipt item or stock movement
references any of its variants. Otherwise `409 IN_USE`. Image files are deleted best-effort.

### Variants

`POST /admin/products/:id/variants`:

```json
{ "sku": "AT-DEN-M", "size": "M", "color": "Đen", "price": 199000 }
```

`201` with the variant and `stock: 0`. `sku` is required and unique system-wide;
`(productId, size, color)` is unique. Errors: `VALIDATION_FAILED`, `SKU_TAKEN`,
`VARIANT_EXISTS`, `NOT_FOUND`.

`PATCH /admin/variants/:id` accepts `sku`, `size`, `color`, `price`. `200` with the variant.
`stock` is rejected: it changes only through checkout, cancellation and inventory receipts
([ADR-0002](adr/0002-stock-ledger-and-checkout-deduction.md)).

`DELETE /admin/variants/:id` → `204` only when unreferenced by orders, receipts or movements;
otherwise `409 IN_USE`. Variants have no status of their own; to stop selling an entire product,
set the product `INACTIVE`.

`GET /admin/variants?q&limit` → `{ items: [{ id, productId, productName, sku, size, color,
price, stock }] }`. `q` matches a substring of the SKU or the product name; `limit` is 1–50,
default 20, ordered by SKU. It exists for the receipt form's variant picker; unlike the
storefront it includes variants of `INACTIVE` products and zero stock.

### Product images

`POST /admin/products/:id/images`, `multipart/form-data`, one file in field `file`:

- JPEG, PNG or WebP, verified by magic bytes, not by `Content-Type`.
- At most 5 MB → otherwise `413 FILE_TOO_LARGE`.
- At most 5 images per product → otherwise `400 VALIDATION_FAILED`.
- The product must exist.

`201`:

```json
{ "id": 33, "url": "/uploads/products/6b1f0e2a.jpg", "position": 2 }
```

`position` is the lowest free slot (0–4). There is no reorder endpoint: delete and re-upload to
change order. `url` is relative; the Android client prefixes `API_BASE_URL`.

`DELETE /admin/products/:id/images/:imageId` → `204`; the file is removed best-effort, the
position is freed for the next upload.

### Users

`GET /admin/users?q&status&role&page&limit&sort` → paginated `User` rows. `q` matches email,
full name or phone.

`PATCH /admin/users/:id/status` body `{ "status": "DISABLED" }` → `200` with `User`.

- Disabling revokes all of that user's refresh tokens; access stops on the next request.
- An admin cannot disable themself: `409 CANNOT_DISABLE_SELF`.
- `role` is not editable; users are never deleted.
  Errors: `VALIDATION_FAILED`, `NOT_FOUND`, `CANNOT_DISABLE_SELF`.

### Orders

`GET /admin/orders?status&q&from&to&page&limit&sort` → paginated summaries:
`{ id, code, status, paymentMethod, paymentStatus, total, itemCount, customerName,
recipientName, recipientPhone, createdAt }`. `q` matches order code, recipient name or phone;
`from`/`to` filter `created_at`.

`GET /admin/orders/:id` → `AdminOrderDetail`, including the customer, `unitCost` per item and
every payment attempt.

`PATCH /admin/orders/:id/status` body `{ "status": "CONFIRMED" }` → `200` with
`AdminOrderDetail`.

| From | To | Side effects |
|---|---|---|
| `PENDING` | `CONFIRMED` | none |
| `PENDING` | `CANCELLED` | restock items |
| `CONFIRMED` | `SHIPPING` | none |
| `CONFIRMED` | `CANCELLED` | restock items |
| `SHIPPING` | `DELIVERED` | for `COD`: set `paidAt` once |
| `DELIVERED`, `CANCELLED` | n/a | terminal |

Any other target, including the current status, is `409 INVALID_ORDER_STATE` with `details`.
Cancelling an order with `paidAt` set is `409 ORDER_ALREADY_PAID` (there is no refund flow).
Cancelling appends `CANCEL_RESTOCK` movements and is applied once.

### Inventory receipts

`POST /admin/inventory-receipts`:

```json
{
  "supplier": "Xưởng may Bình Tân",
  "note": "Lô thu đông",
  "items": [
    { "variantId": 44, "quantity": 20, "unitCost": 120000 },
    { "variantId": 45, "quantity": 10, "unitCost": 125000 }
  ]
}
```

`201` with the receipt: `id`, `code` (`PN-YYMMDD-XXXX`), `supplier`, `note`, `totalCost`,
`itemCount`, `createdBy`, `items`, `createdAt`.

Rules: `supplier` 1–150 chars, `note` ≤ 255, 1–100 items, `quantity ≥ 1`, `unitCost ≥ 0`,
`variantId` must exist, at most 100 distinct variants. The same variant may appear on two lines
at different costs (the ERD permits it; `totalCost` sums them). One transaction inserts the
receipt and items, increments `stock`, and appends `RECEIPT` movements with the receipt as
`ref`.

`GET /admin/inventory-receipts?from&to&page&limit&sort` → summaries without `items`.
`GET /admin/inventory-receipts/:id` → full receipt.
Receipts are immutable: there is no `PATCH` or `DELETE`.

Errors: `VALIDATION_FAILED`, `NOT_FOUND`.

### Reports

All reports require `ADMIN` and use inclusive `from`/`to` calendar days in `Asia/Ho_Chi_Minh`
(default: last 30 days). Missing `from`/`to` is not an error.

#### `GET /admin/reports/revenue?from&to&groupBy=day|month`

Revenue and order count grouped by `order.paid_at`; paid orders only. Every period in the range
is present, with `0` for empty ones. `groupBy` defaults to `day`; `month` renders `YYYY-MM`.

```json
{
  "from": "2026-11-01",
  "to": "2026-11-03",
  "groupBy": "day",
  "totalRevenue": 1600000,
  "totalOrders": 5,
  "series": [
    { "period": "2026-11-01", "revenue": 350000, "orders": 2 },
    { "period": "2026-11-02", "revenue": 0, "orders": 0 },
    { "period": "2026-11-03", "revenue": 1250000, "orders": 3 }
  ]
}
```

#### `GET /admin/reports/top-products?from&to&limit`

Products sold in paid orders in the range, sorted by `quantitySold` descending, then revenue.
`limit` defaults to 10, max 50. Revenue uses the `unitPrice` snapshot.

```json
{
  "from": "2026-10-01",
  "to": "2026-10-31",
  "items": [
    { "productId": 9, "name": "Áo thun cotton", "quantitySold": 12, "revenue": 2388000 }
  ]
}
```

#### `GET /admin/reports/orders-by-status?from&to`

Orders **created** in the range, counted by current status. All five statuses are present,
including zeros; `total` is the sum of `order.total` for that status.

```json
{
  "from": "2026-10-01",
  "to": "2026-10-31",
  "items": [
    { "status": "PENDING", "count": 3, "total": 450000 },
    { "status": "CONFIRMED", "count": 5, "total": 1200000 },
    { "status": "SHIPPING", "count": 2, "total": 600000 },
    { "status": "DELIVERED", "count": 30, "total": 9000000 },
    { "status": "CANCELLED", "count": 2, "total": 300000 }
  ]
}
```

#### `GET /admin/reports/low-stock?threshold`

Variants of `ACTIVE` products with `stock <= threshold`. `threshold` defaults to
`LOW_STOCK_THRESHOLD` (5) and accepts 0–1000. Sorted by `stock` ascending, then `sku`.

```json
{
  "threshold": 5,
  "items": [
    {
      "variantId": 44,
      "sku": "AT-DEN-M",
      "productName": "Áo thun cotton",
      "size": "M",
      "color": "Đen",
      "stock": 2
    }
  ]
}
```

#### `GET /admin/reports/inventory-cost?from&to`

```json
{
  "from": "2026-10-01",
  "to": "2026-10-31",
  "receiptsCost": 5000000,
  "cogs": 3200000,
  "revenue": 12500000,
  "grossProfit": 9300000
}
```

- `receiptsCost` = Σ `quantity × unitCost` for receipts created in the range.
- `cogs` = Σ `unitCost × quantity` for items of orders paid in the range.
- `revenue` = `totalRevenue` from the revenue report.
- `grossProfit` = `revenue − cogs`.

The weighted-average `unitCost` definition is fixed in [erd.md](erd.md); the null-`unitCost`
policy and the report SQL are specified in [reports.md](reports.md) (decided at
[ticket 10](../.scratch/stylo-app/issues/10-cong-thuc-gia-von.md)). This shape does not change.

---

## Static files and health

- `GET /health` → `200 { "status": "ok" }`, not versioned, no auth.
- `GET /uploads/**` serves product images from `UPLOAD_DIR` (default `uploads/`), no auth,
  `Cache-Control: public, max-age=86400`. Not under `/api/v1`.
- There is no CORS configuration: the client is a native app and the HTML payment pages are
  same-origin.

## Configuration the contract depends on

| Variable | Used by |
|---|---|
| `PUBLIC_BASE_URL` | `vnp_ReturnUrl`, mock payment page, any absolute URL rendered in HTML |
| `SHIPPING_FEE` | `order.shippingFee` (default `30000`) |
| `PAYMENT_PROVIDER` | `MOCK` or `VNPAY`; decides which adapter creates attempts |
| `LOW_STOCK_THRESHOLD` | default for the low-stock report (default `5`) |
| `UPLOAD_DIR` | image storage and `/uploads` static root (default `uploads/`) |

## Invariants the API enforces

- `stock` changes only through checkout, cancellation and receipts, always with a
  `StockMovement` in the same transaction.
- `paidAt` is written exactly once; `SUCCEEDED` is terminal.
- A customer can never read or mutate another customer's cart, order, payment or address.
- `clientOrderId` is unique per user and makes checkout retry-safe.
- An `INACTIVE` product is invisible on the storefront but still readable by admins.
- Product images are at most five, at most 5 MB, and stored as relative URLs.
