# ỨNG DỤNG BÁN QUẦN ÁO

## Tên đề tài

**Ứng dụng bán quần áo**

## Nội dung yêu cầu của đề tài

- Phân tích chức năng của một ứng dụng bán quần áo;
- Thiết kế cơ sở dữ liệu;
- Thiết kế giao diện;
- Các chức năng chính:
  - Đăng ký / Đăng nhập
  - Chức năng quản lý thông tin cá nhân
  - Chức năng quản lý giỏ hàng (thêm, sửa, xóa)
  - Chức năng quản lý sản phẩm (thêm, sửa, xóa)
  - Chức năng quản lý đơn hàng
  - Chức năng quản lý người dùng
  - Chức năng tìm kiếm sản phẩm (theo danh mục, tên, màu sắc, giá, thương hiệu)
  - Chức năng chi tiết sản phẩm
  - Chức năng thanh toán
  - Báo cáo và thống kê
  - Phiếu giá nhập kho sản phẩm

## Môi trường phát triển

- **Ngôn ngữ lập trình:** Kotlin (Android) với Node.js (Backend)
- **Hệ quản trị CSDL:** MySQL