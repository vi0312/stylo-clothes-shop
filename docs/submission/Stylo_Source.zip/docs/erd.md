# ERD and data conventions

Decided in [ticket 04](../.scratch/stylo-app/issues/04-thiet-ke-erd.md); `order.client_order_id` and the query recipes were aligned with the API contract in [ticket 05](../.scratch/stylo-app/issues/05-dac-ta-api.md). This file is the source of truth for `prisma/schema.prisma` and the first migration; the wire contract is [api.md](api.md).

**Scope of the schema:** 16 tables for the 11 functions in `PROJECT.md` — auth, profile/address, cart, catalog (category, brand, product, variant, image), orders, payments, inventory receipts. Promotions, vouchers, reviews, wishlist, returns/refunds and multi-currency are out of scope.

Decisions with their own ADRs: [payments per attempt](adr/0001-payment-attempts-per-order.md), [stock ledger](adr/0002-stock-ledger-and-checkout-deduction.md), [integer VND](adr/0003-money-as-integer-vnd.md), [order snapshots](adr/0004-order-snapshots.md).

## Conventions

| Rule | Value |
|---|---|
| Engine / charset | InnoDB, `utf8mb4`, database collation `utf8mb4_0900_ai_ci` (accent- and case-insensitive) |
| Table names | singular `snake_case`, via Prisma `@@map`; model names `PascalCase` |
| Column names | `snake_case` via `@map`; Prisma fields `camelCase` |
| Primary keys | `id INT AUTO_INCREMENT`, no UUIDs |
| Timestamps | `created_at` / `updated_at` are `DATETIME(3)`, stored in **UTC**; the app renders `Asia/Ho_Chi_Minh`. Immutable tables have `created_at` only |
| Money | `INT`, VND, no fraction ([ADR-0003](adr/0003-money-as-integer-vnd.md)) |
| Enums | MySQL native `ENUM` via Prisma `enum`; values are `SCREAMING_SNAKE_CASE` |
| Hiding vs deleting | visibility is `status`; hard delete only when nothing references the row (FK `RESTRICT` enforces it) |
| Time zone | gateway payloads (`vnp_PayDate`) are converted to UTC before storage |

`order` is a reserved MySQL word: Prisma quotes identifiers, but raw SQL in migrations and report queries must write `` `order` ``.

## ERD

```mermaid
erDiagram
    USER ||--o{ REFRESH_TOKEN : owns
    USER ||--o{ ADDRESS : has
    USER ||--o| CART : has
    CART ||--o{ CART_ITEM : contains
    PRODUCT_VARIANT ||--o{ CART_ITEM : "is added"
    CATEGORY ||--o{ PRODUCT : classifies
    BRAND ||--o{ PRODUCT : brands
    PRODUCT ||--o{ PRODUCT_VARIANT : has
    PRODUCT ||--o{ PRODUCT_IMAGE : has
    USER ||--o{ ORDER : places
    ORDER ||--o{ ORDER_ITEM : contains
    PRODUCT ||--o{ ORDER_ITEM : "is referenced"
    PRODUCT_VARIANT ||--o{ ORDER_ITEM : "is referenced"
    ORDER ||--o{ PAYMENT : "is attempted by"
    USER ||--o{ INVENTORY_RECEIPT : creates
    INVENTORY_RECEIPT ||--o{ INVENTORY_RECEIPT_ITEM : contains
    PRODUCT_VARIANT ||--o{ INVENTORY_RECEIPT_ITEM : "is received"
    PRODUCT_VARIANT ||--o{ STOCK_MOVEMENT : logs
```

## Tables

### user

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `email` | `VARCHAR(255)` NOT NULL, UNIQUE | service lowercases before write; uniqueness is case-insensitive |
| `password_hash` | `VARCHAR(255)` NOT NULL | argon2id |
| `full_name` | `VARCHAR(100)` NOT NULL | |
| `phone` | `VARCHAR(20)` NULL | |
| `role` | `ENUM('CUSTOMER','ADMIN')` NOT NULL DEFAULT `CUSTOMER` | one role per account; admins come from seed |
| `status` | `ENUM('ACTIVE','DISABLED')` NOT NULL DEFAULT `ACTIVE` | lock/unlock, never delete |
| `created_at`, `updated_at` | `DATETIME(3)` NOT NULL | |

### refresh_token

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `user_id` | `INT` NOT NULL | FK → `user.id`, `ON DELETE CASCADE` |
| `token_hash` | `CHAR(64)` NOT NULL UNIQUE | SHA-256 hex of the raw token; raw token never stored |
| `expires_at` | `DATETIME(3)` NOT NULL | 30 days after issue |
| `revoked_at` | `DATETIME(3)` NULL | set on logout/rotation |
| `created_at` | `DATETIME(3)` NOT NULL | |

Index: `(user_id, expires_at)`.

### address

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `user_id` | `INT` NOT NULL | FK → `user.id`, `RESTRICT` |
| `recipient_name` | `VARCHAR(100)` NOT NULL | |
| `phone` | `VARCHAR(20)` NOT NULL | |
| `line` | `VARCHAR(255)` NOT NULL | one free-text line: số nhà, đường, phường/xã, quận/huyện, tỉnh/thành. No 3-level administrative dropdowns |
| `is_default` | `TINYINT(1)` NOT NULL DEFAULT 0 | exactly one per user, enforced in the service inside a transaction (MySQL has no partial unique index) |
| `created_at`, `updated_at` | `DATETIME(3)` NOT NULL | |

Index: `(user_id)`. Orders snapshot the address, so an address can be deleted freely.

### category / brand

Identical shape:

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `name` | `VARCHAR(100)` NOT NULL UNIQUE | |
| `status` | `ENUM('ACTIVE','INACTIVE')` NOT NULL DEFAULT `ACTIVE` | |
| `created_at`, `updated_at` | `DATETIME(3)` NOT NULL | |

### product

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `name` | `VARCHAR(200)` NOT NULL | |
| `description` | `TEXT` NULL | |
| `category_id` | `INT` NOT NULL | FK → `category.id`, `RESTRICT` |
| `brand_id` | `INT` NOT NULL | FK → `brand.id`, `RESTRICT` |
| `status` | `ENUM('ACTIVE','INACTIVE')` NOT NULL DEFAULT `ACTIVE` | hidden from the storefront when `INACTIVE` |
| `created_at`, `updated_at` | `DATETIME(3)` NOT NULL | |

Indexes: `(status, created_at)` for the listing, `(category_id)`, `(brand_id)`.
There is no price on `product`: it lives on variants; the listing shows `MIN(variant.price)`.

### product_variant

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `product_id` | `INT` NOT NULL | FK → `product.id`, `ON DELETE CASCADE` |
| `sku` | `VARCHAR(50)` NOT NULL UNIQUE | system-wide unique |
| `size` | `VARCHAR(20)` NOT NULL | free text (`S`, `M`, `L`, `XL`, `39`…) |
| `color` | `VARCHAR(40)` NOT NULL | free text, Vietnamese |
| `price` | `INT` NOT NULL | ≥ 1 |
| `stock` | `INT` NOT NULL DEFAULT 0 | ≥ 0; guarded by row lock + `StockMovement` ([ADR-0002](adr/0002-stock-ledger-and-checkout-deduction.md)) |
| `created_at`, `updated_at` | `DATETIME(3)` NOT NULL | |

Constraints: `UNIQUE (product_id, size, color)`; indexes `(product_id)`, `(color)`, `(product_id, price)` (the last serves `MIN(price)` on the listing and price-range filters).
Checks, added by hand-editing the generated migration (Prisma does not model `CHECK`): `CHECK (stock >= 0)`, `CHECK (price > 0)`.

### product_image

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `product_id` | `INT` NOT NULL | FK → `product.id`, `ON DELETE CASCADE` |
| `url` | `VARCHAR(255)` NOT NULL | relative path returned by the API, e.g. `/uploads/products/<uuid>.jpg`; the client prefixes its base URL |
| `position` | `TINYINT` NOT NULL | 0–4, first is the cover |
| `created_at` | `DATETIME(3)` NOT NULL | |

`UNIQUE (product_id, position)` makes "at most 5 images" a hard DB limit; the service rejects positions outside 0–4 and more than 5 uploads.

### cart

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `user_id` | `INT` NOT NULL UNIQUE | FK → `user.id`, `ON DELETE CASCADE`; one cart per customer, created on first add |
| `created_at`, `updated_at` | `DATETIME(3)` NOT NULL | |

### cart_item

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `cart_id` | `INT` NOT NULL | FK → `cart.id`, `ON DELETE CASCADE` |
| `variant_id` | `INT` NOT NULL | FK → `product_variant.id`, `ON DELETE CASCADE` |
| `quantity` | `INT` NOT NULL | `> 0` and `<= variant.stock`, enforced in the service; re-checked under the checkout lock |
| `created_at`, `updated_at` | `DATETIME(3)` NOT NULL | |

`UNIQUE (cart_id, variant_id)`; index `(variant_id)`.

### order

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `code` | `VARCHAR(20)` NOT NULL UNIQUE | `STY-YYMMDD-XXXX`, XXXX is 4 chars `A–Z0–9`; display and reconciliation only, never sent to the gateway |
| `user_id` | `INT` NOT NULL | FK → `user.id`, `RESTRICT` |
| `client_order_id` | `CHAR(36)` NOT NULL | UUID generated by the app for one checkout; makes retries idempotent ([ADR-0006](adr/0006-checkout-idempotency.md)) |
| `status` | `ENUM('PENDING','CONFIRMED','SHIPPING','DELIVERED','CANCELLED')` NOT NULL DEFAULT `PENDING` | transitions below |
| `payment_method` | `ENUM('COD','ONLINE')` NOT NULL | customer's choice |
| `paid_at` | `DATETIME(3)` NULL | set once: online on gateway confirmation, COD on `DELIVERED`. Single source of "paid" |
| `recipient_name` | `VARCHAR(100)` NOT NULL | snapshot |
| `recipient_phone` | `VARCHAR(20)` NOT NULL | snapshot |
| `shipping_address` | `VARCHAR(255)` NOT NULL | snapshot of `address.line` |
| `subtotal` | `INT` NOT NULL | snapshot of Σ `unit_price × quantity` |
| `shipping_fee` | `INT` NOT NULL DEFAULT 0 | flat, copied from `SHIPPING_FEE` (API default 30,000); the DB default is only a safety net |
| `total` | `INT` NOT NULL | `subtotal + shipping_fee` |
| `note` | `VARCHAR(255)` NULL | customer note |
| `created_at`, `updated_at` | `DATETIME(3)` NOT NULL | |

`UNIQUE (user_id, client_order_id)` (retry lookup); indexes `(user_id, created_at)` (my orders), `(status)` (admin queue), `(paid_at)` (revenue), `(created_at)` (date filters).

### order_item

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `order_id` | `INT` NOT NULL | FK → `order.id`, `RESTRICT` |
| `product_id` | `INT` NOT NULL | FK → `product.id`, `RESTRICT` |
| `variant_id` | `INT` NOT NULL | FK → `product_variant.id`, `RESTRICT` |
| `product_name` | `VARCHAR(200)` NOT NULL | snapshot |
| `variant_sku` | `VARCHAR(50)` NOT NULL | snapshot |
| `size` | `VARCHAR(20)` NOT NULL | snapshot |
| `color` | `VARCHAR(40)` NOT NULL | snapshot |
| `unit_price` | `INT` NOT NULL | snapshot |
| `unit_cost` | `INT` NULL | weighted-average receipt cost at order time; null when the variant was never received |
| `quantity` | `INT` NOT NULL | > 0 |

Indexes: `(order_id)`, `(variant_id)`, `(product_id)`.

### payment

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `order_id` | `INT` NOT NULL | FK → `order.id`, `RESTRICT` |
| `provider` | `ENUM('MOCK','VNPAY')` NOT NULL | adapter that produced this attempt, from `PAYMENT_PROVIDER` |
| `status` | `ENUM('PENDING','SUCCEEDED','FAILED')` NOT NULL DEFAULT `PENDING` | one row per attempt |
| `amount` | `INT` NOT NULL | copied from `order.total`; compared against `vnp_Amount / 100` |
| `txn_ref` | `VARCHAR(50)` NOT NULL UNIQUE | sent as `vnp_TxnRef`; `STY` + `YYMMDDHHmmss` + 3 random digits, alphanumeric only |
| `provider_txn_no` | `VARCHAR(64)` NULL | `vnp_TransactionNo` |
| `bank_code` | `VARCHAR(20)` NULL | `vnp_BankCode` |
| `pay_date` | `DATETIME(3)` NULL | `vnp_PayDate`, converted to UTC |
| `raw_response` | `JSON` NULL | full gateway payload, for reconciliation |
| `failure_reason` | `VARCHAR(255)` NULL | `vnp_ResponseCode` / signature error text |
| `created_at`, `updated_at` | `DATETIME(3)` NOT NULL | |

Index: `(order_id)`. No `Payment` row exists for COD orders.

### inventory_receipt

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `code` | `VARCHAR(20)` NOT NULL UNIQUE | `PN-YYMMDD-XXXX`, same generator as `order.code` |
| `supplier` | `VARCHAR(150)` NOT NULL | free text, no supplier table |
| `note` | `VARCHAR(255)` NULL | |
| `total_cost` | `INT` NOT NULL | Σ `quantity × unit_cost`, snapshot |
| `created_by` | `INT` NOT NULL | FK → `user.id` (admin), `RESTRICT` |
| `created_at` | `DATETIME(3)` NOT NULL | immutable: no `updated_at`, no update/delete endpoint |

Indexes: `(created_at)`, `(created_by)`.

### inventory_receipt_item

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `receipt_id` | `INT` NOT NULL | FK → `inventory_receipt.id`, `RESTRICT` |
| `variant_id` | `INT` NOT NULL | FK → `product_variant.id`, `RESTRICT` |
| `quantity` | `INT` NOT NULL | > 0 |
| `unit_cost` | `INT` NOT NULL | purchase price per unit, VND |

Indexes: `(receipt_id)`, `(variant_id)`. No unique on `(receipt_id, variant_id)`: the same variant may appear twice at different costs, and the weighted average absorbs it.

### stock_movement

| Column | Type | Notes |
|---|---|---|
| `id` | `INT` PK AI | |
| `variant_id` | `INT` NOT NULL | FK → `product_variant.id`, `RESTRICT` |
| `delta` | `INT` NOT NULL | positive on receipt/restock, negative on sale |
| `reason` | `ENUM('RECEIPT','SALE','CANCEL_RESTOCK')` NOT NULL | |
| `ref_type` | `ENUM('RECEIPT','ORDER')` NOT NULL | polymorphic source of the movement |
| `ref_id` | `INT` NOT NULL | `receipt.id` or `order.id`; no FK because it is polymorphic |
| `unit_cost` | `INT` NULL | receipt cost; null for sales |
| `created_at` | `DATETIME(3)` NOT NULL | append-only: no update, no delete |

Indexes: `(variant_id, created_at)`, `(ref_type, ref_id)`.

## Order lifecycle

```
PENDING ──confirm(admin | gateway success)──> CONFIRMED ──ship(admin)──> SHIPPING ──deliver(admin)──> DELIVERED
   │                                              │
   └──────────────cancel(customer, admin)─────────┴──> CANCELLED      (requires paid_at IS NULL)
```

| From | To | Actor | Side effects |
|---|---|---|---|
| `PENDING` | `CONFIRMED` | admin, or the gateway on payment success | online: `paid_at = now()` |
| `PENDING` | `CANCELLED` | owning customer, admin | restock |
| `CONFIRMED` | `SHIPPING` | admin | |
| `CONFIRMED` | `CANCELLED` | owning customer, admin | restock |
| `SHIPPING` | `DELIVERED` | admin | COD: `paid_at = now()` |

`DELIVERED` and `CANCELLED` are terminal. Any transition is validated by one service function `transitionOrder(orderId, next, actor)`; a DB trigger is not used because the side effects (restock, `paid_at`) need application logic. Blocking rules: `CANCELLED` requires `paid_at IS NULL` (no refund flow in scope); the owning customer may cancel only `PENDING` / `CONFIRMED`.

Derived order payment state (never stored):

| Value | Condition |
|---|---|
| `PAID` | `paid_at IS NOT NULL` |
| `FAILED` | `paid_at IS NULL` and the latest `Payment` for the order is `FAILED` |
| `UNPAID` | otherwise, including every COD order before delivery |

## Transactions

**Place order** — one transaction:

1. Read the customer's cart lines.
2. `SELECT id, price, stock, product_id FROM product_variant WHERE id IN (…) ORDER BY id FOR UPDATE` — ascending `id` avoids deadlocks between two checkouts sharing variants.
3. Re-check `product.status = ACTIVE` and `stock >= quantity`; reject with `OUT_OF_STOCK` naming the SKU.
4. Compute `subtotal` from the locked variant prices, add the flat `shipping_fee`, write `order` and `order_item` snapshots. `unit_cost` comes from the weighted average below.
5. For each line: insert `stock_movement` (`-quantity`, `SALE`, `ORDER`, `order.id`) and `UPDATE product_variant SET stock = stock - ? WHERE id = ?`.
6. Delete the cart's `cart_item` rows.
7. For `ONLINE`, insert the `Payment` row (`PENDING`, fresh `txn_ref`); the URL is rebuilt from the row when read. Commit.

`unit_cost` at sale time:

```sql
SELECT variant_id,
       ROUND(SUM(quantity * unit_cost) / SUM(quantity)) AS avg_cost
FROM inventory_receipt_item
WHERE variant_id IN (?, …)
GROUP BY variant_id;
```

No rows means `unit_cost` is null. The formula itself belongs to the cost report ticket; this query is the only definition used by checkout.

**Create inventory receipt** — one transaction: insert `inventory_receipt` (+ items), insert one `stock_movement` (`+quantity`, `RECEIPT`, `RECEIPT`, `receipt.id`, `unit_cost`) per line, `UPDATE product_variant SET stock = stock + ?`. No update or delete afterwards.

**Cancel order** — one transaction: ``SELECT … FROM `order` WHERE id = ? FOR UPDATE``, validate the transition and `paid_at IS NULL`, insert `stock_movement` (`+quantity`, `CANCEL_RESTOCK`, `ORDER`) per line, add the stock back, set `status = CANCELLED`.

**Confirm payment** — lookup `payment` by `txn_ref`; if already `SUCCEEDED`, ack and return without touching the order (IPN is retried). Otherwise verify amount and signature, store `provider_txn_no`, `bank_code`, `pay_date`, `raw_response`, set `status = SUCCEEDED`; set `paid_at = now()` if it is null, whatever the order status (a genuine late success after a cancellation still records the money), and if the order is still `PENDING`, move it to `CONFIRMED` in the same transaction.

## Query recipes

Search (all filters combine, no stored normalised name — collation makes `LIKE` accent-insensitive):

```sql
SELECT p.id, p.name, MIN(v.price) AS from_price
FROM product p
JOIN product_variant v ON v.product_id = p.id
JOIN brand b ON b.id = p.brand_id
JOIN category c ON c.id = p.category_id
WHERE p.status = 'ACTIVE'
  AND v.stock > 0
  AND (p.name LIKE CONCAT('%', ?, '%')          -- 'ao thun' matches 'Áo Thun'
       OR b.name LIKE CONCAT('%', ?, '%')
       OR c.name LIKE CONCAT('%', ?, '%'))
  AND (? IS NULL OR p.category_id = ?)
  AND (? IS NULL OR p.brand_id = ?)
  AND EXISTS (SELECT 1 FROM product_variant f
              WHERE f.product_id = p.id
                AND f.stock > 0
                AND (? IS NULL OR f.color = ?)
                AND (? IS NULL OR f.size = ?)
                AND (? IS NULL OR f.price BETWEEN ? AND ?))
GROUP BY p.id, p.name, p.created_at
ORDER BY p.created_at DESC;                     -- or MIN(v.price) ASC / DESC
```

`q` matches product, brand or category name. Colour is an exact match on a value returned by
`GET /catalog/filters`; the collation makes it case- and accent-insensitive, and the `(color)`
index stays usable. `LIKE '%…%'` cannot use an index; at seed scale (hundreds of products) the
scan is accepted and recorded as a limitation, not optimised prematurely. Colour and size
filters reuse the variant indexes above.

Low stock:

```sql
SELECT v.id, v.sku, v.stock
FROM product_variant v
JOIN product p ON p.id = v.product_id
WHERE p.status = 'ACTIVE' AND v.stock <= ?
ORDER BY v.stock ASC, v.sku ASC;
```

The threshold comes from config (`LOW_STOCK_THRESHOLD=5`) or the API query override; there is no
column.

Revenue:

```sql
SELECT DATE(paid_at + INTERVAL 7 HOUR) AS d,
       SUM(total) AS revenue,
       COUNT(*) AS orders
FROM `order`
WHERE paid_at >= ? AND paid_at < ?
GROUP BY d
ORDER BY d;
```

`?` are the UTC boundaries of the requested `Asia/Ho_Chi_Minh` days. Vietnam is UTC+7 with no
DST, so `+ INTERVAL 7 HOUR` groups UTC timestamps by the local calendar day; grouping by
`DATE(paid_at)` would put late-evening sales on the wrong day.

Top products: `SUM(order_item.quantity)` joined to `order` filtered by `paid_at` in range, using
the same UTC boundaries.

Stock ledger reconciliation (run after seed, in tests, and when stock looks wrong):

```sql
SELECT v.id, v.sku, v.stock, COALESCE(SUM(m.delta), 0) AS ledger
FROM product_variant v
LEFT JOIN stock_movement m ON m.variant_id = v.id
GROUP BY v.id, v.sku, v.stock
HAVING v.stock <> ledger;
```

## Delete rules

| Entity | Rule |
|---|---|
| `product` | Delete only while no order, receipt or movement references any of its variants (FK `RESTRICT` fails → API returns `409 IN_USE`, admin uses `INACTIVE` instead). Deleting cascades variants, images and cart lines |
| `category`, `brand` | Delete only when no product references it, whatever the product status |
| `address` | Delete freely; orders keep the snapshot |
| `cart_item` | Delete freely |
| `user` | Never deleted; lock with `status = DISABLED` |
| `order`, `order_item`, `payment` | Never deleted |
| `inventory_receipt`, `inventory_receipt_item`, `stock_movement` | Never deleted (immutable history) |
| `refresh_token` | Deleted/revoked on logout, rotation and expiry cleanup |

FK actions: `CASCADE` only where the child has no independent meaning (`refresh_token`, `cart_item`, `product_image`, `product_variant`); everything that carries history is `RESTRICT`.

## Known limitations

- No scheduled job cancels abandoned `PENDING` online orders, so their stock stays reserved until the admin cancels.
- No refund flow: cancelling an order with `paid_at` set is refused rather than reversing money. A genuine gateway success that arrives after a cancellation still sets `paid_at` on the cancelled order; the admin resolves it by hand.
- A variant has no status of its own: to stop selling one size or colour, the admin hides the whole product with `INACTIVE` (deleting a referenced variant is blocked).
- Exactly one default address is a service invariant; the DB cannot express a partial unique index.
- `CHECK` constraints must be added by editing the generated migration (`prisma migrate dev --create-only`); `prisma db pull` ignores them.
- Money values are capped at 2,147,483,647 VND each ([ADR-0003](adr/0003-money-as-integer-vnd.md)).
