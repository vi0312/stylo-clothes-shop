# Architecture

Source of truth for the repository layout, dependency pins and local runtime. Decisions with
their own rationale: [ADR-0008](adr/0008-android-client-architecture.md) (Android client) and
[ADR-0009](adr/0009-backend-architecture-and-runtime.md) (backend). Wire contract:
[api.md](api.md). Schema: [erd.md](erd.md). Verification: [testing.md](testing.md). Ticket:
[06](../.scratch/stylo-app/issues/06-chot-skeleton-kien-truc.md).

`server/` exists from [ticket 12](../.scratch/stylo-app/issues/12-server-foundation.md); `android/`
starts at [ticket 13](../.scratch/stylo-app/issues/13-android-foundation.md). This document is what
those build tickets scaffold.

---

## Repository

```
stylo-clothing-store/
├── AGENTS.md
├── GLOSSARY.md
├── docs/
│   ├── PROJECT.md
│   ├── api.md
│   ├── architecture.md          ← this file
│   ├── erd.md
│   ├── testing.md
│   └── adr/0001..0010
├── .scratch/
├── android/
└── server/
```

`android/` and `server/` are independent builds. `docs/` and `.scratch/` stay at the root.

---

## Android

### Module and packages

One Gradle module `:app`, application id and namespace `com.stylo.shop`, `minSdk 26`,
`compileSdk`/`targetSdk 36`, Java 17.

```
android/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/libs.versions.toml
└── app/
    ├── build.gradle.kts
    └── src/
        ├── main/AndroidManifest.xml
        ├── main/java/com/stylo/shop/
        │   ├── StyloApp.kt
        │   ├── MainActivity.kt
        │   ├── core/
        │   │   ├── network/      ApiClient, ApiResult, ApiError, AuthInterceptor,
        │   │   │                TokenAuthenticator
        │   │   ├── storage/      TokenStore, SessionManager
        │   │   ├── ui/           UiState, UiEffect, ErrorMessages, Formatters,
        │   │   │                components/, theme/
        │   │   ├── navigation/   Routes, StyloNavHost
        │   │   └── di/           NetworkModule, StorageModule, RepositoryModule
        │   └── feature/
        │       ├── auth/         data/, ui/
        │       ├── catalog/      data/, ui/
        │       ├── cart/         data/, ui/
        │       ├── checkout/     data/, ui/
        │       ├── orders/       data/, ui/
        │       ├── profile/      data/, ui/
        │       └── admin/
        │           ├── data/     AdminApi, AdminRepository, DTOs
        │           └── ui/       dashboard/, products/, categories/, brands/,
        │                        orders/, users/, inventory/, reports/
        ├── test/java/com/stylo/shop/   JVM tests and fakes
        ├── debug/AndroidManifest.xml
        └── debug/res/xml/network_security_config.xml
```

Each `feature/<name>/data` holds `XApi` (Retrofit), DTOs, mappers and the repository interface plus
its implementation. ViewModels depend on the repository interface only. There is no use-case
layer and no `domain` package; adding one would only forward calls.

### Result and UI state

```kotlin
sealed interface ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>
    data class Failure(val error: ApiError) : ApiResult<Nothing>
}

enum class ApiErrorKind { NETWORK, TIMEOUT, HTTP, PARSE }

data class ApiError(
    val kind: ApiErrorKind,
    val code: String? = null,       // server code when kind == HTTP
    val httpStatus: Int? = null,
    val details: JsonElement? = null,
    val developerMessage: String? = null,
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Content<T>(val data: T) : UiState<T>
    data class Error(val error: ApiError) : UiState<Nothing>
}
```

- Repositories catch `IOException`, `HttpException` and serialization failures and return
  `ApiResult.Failure`; exceptions never cross the repository boundary.
- A screen-specific state class wraps `UiState` and adds `isRefreshing`, `isLoadingMore` or form
  fields. An empty collection is `Content(emptyList())`; there is no `Empty` state.
- One-off navigation, messages and payment hand-off go through `Channel<UiEffect>`, collected with
  `repeatOnLifecycle`.
- `ErrorMessages` maps `ApiError.code` to Vietnamese. The server `message` is for logs only.
  `VALIDATION_FAILED.details` is decoded into field errors; unknown codes use one generic string.

### Session and networking

- `TokenStore` keeps `access_token` and `refresh_token` in Preferences DataStore. No encrypted
  prefs. `SessionManager` holds the current access token in memory for the synchronous
  interceptor; DataStore is the durable copy, loaded once at launch and updated on login, refresh
  and logout.
- `AuthInterceptor` adds `Authorization: Bearer <accessToken>`.
- `TokenAuthenticator` handles `401` once per request: a `Mutex` serialises refresh, the rotated
  refresh token is persisted, and the request is retried once. Failure clears tokens and emits
  `SessionState.Unauthenticated`. The refresh call itself uses a bare OkHttp client without the
  `Authenticator`, so a rejected refresh cannot recurse.
- App launch calls `GET /me` while showing the splash/loading state. It decides the start graph
  and the role. `ACCOUNT_DISABLED`, `UNAUTHORIZED` and `INVALID_TOKEN` terminate the session.
- Logout calls `POST /auth/logout` best effort, then clears local state.
- Retrofit base URL must end with `/`: `http://127.0.0.1:8787/api/v1/`.
- kotlinx.serialization uses `ignoreUnknownKeys = true` and explicit nullable DTO fields, so
  additive server fields do not break the client; enums are decoded with a fallback so an unknown
  future value does not crash a screen.

### Navigation

- One `NavHost`; routes are `@Serializable` types, not string patterns.
- Nested graphs: `auth`, `customer`, `admin`. The start destination follows the session.
- Login and logout use `popUpTo(0) { inclusive = true }`.
- The client hides admin destinations from non-admins; the server still enforces
  `Role.ADMIN` on every `/admin/**` route.
- No deep links. Checkout opens `paymentUrl` in a Custom Tab; when the app resumes, the order is
  fetched again to show the confirmed state.
- Concrete navigation, screens and design tokens are specified in [ui.md](ui.md).

### UI conventions

- Vietnamese strings live in `res/values/strings.xml`; code identifiers are English.
- Money is `Long` VND and is formatted with grouping, no decimals. Timestamps arrive as UTC
  ISO-8601 and are rendered in `Asia/Ho_Chi_Minh` with `java.time`.
- Images use Coil 3; the server returns relative `/uploads/...` paths and the client resolves them
  against `BuildConfig.API_BASE_URL` origin.
- No Room, no offline queue, no Paging 3. Lists paginate with `page`/`limit` and append.
- Debug build only: cleartext traffic is enabled by a debug network security config. Release keeps
  the platform default.

### Naming

- Packages are lowercase, no underscores: `com.stylo.shop.feature.catalog.data`.
- Classes and composables are `PascalCase`; functions and properties `camelCase`; constants
  `SCREAMING_SNAKE_CASE`.
- A feature uses `XApi`, `XDto`, `XRepository`, `DefaultXRepository`, `XViewModel`, `XUiState`,
  `XEffect`, `XScreen` and `XRoute`. One repository per feature unless a screen needs a second
  source.
- UI strings are Vietnamese in `strings.xml`; identifiers, comments and API fields are English.

### Build configuration

`BuildConfig.API_BASE_URL` is set from the Gradle property `stylo.apiBaseUrl` when present, and
defaults to `http://127.0.0.1:8787/api/v1/`. `buildFeatures.buildConfig = true` is required. This
is the only environment-specific value in the client.

---

## Backend

### Layout

```
server/
├── package.json
├── tsconfig.json
├── tsconfig.build.json
├── prisma.config.ts
├── vitest.unit.config.ts
├── vitest.integration.config.ts
├── .env.example
├── prisma/
│   ├── schema.prisma
│   ├── migrations/
│   └── seed.ts
├── seed-assets/                  committed catalog snapshot + product images
├── uploads/                      gitignored runtime storage
├── tests/
│   ├── unit/
│   ├── integration/
│   ├── factories/
│   └── helpers/
└── src/
    ├── index.ts                  listen, signals, shutdown
    ├── app.ts                    express app, exported for supertest
    ├── config/env.ts
    ├── generated/prisma/         gitignored Prisma 7 client
    ├── lib/
    │   ├── prisma.ts             PrismaClient + MariaDB adapter singleton
    │   ├── jwt.ts
    │   ├── password.ts           argon2id
    │   ├── refreshToken.ts       generate, hash, compare
    │   └── fileStorage.ts        magic-byte check, UUID file writes
    ├── middleware/
    │   ├── auth.ts               verify JWT, load user, reject DISABLED
    │   ├── requireRole.ts
    │   ├── validate.ts           Zod parse → typed value
    │   ├── upload.ts             multer memory storage, 5 MB
    │   ├── notFound.ts
    │   └── error.ts
    ├── modules/
    │   ├── auth/                 routes, service, repository, schema
    │   ├── users/
    │   ├── addresses/
    │   ├── products/
    │   ├── categories/
    │   ├── brands/
    │   ├── cart/
    │   ├── orders/
    │   ├── payments/             gateway/PaymentGateway.ts, mock.ts, vnpay.ts, signature.ts
    │   ├── inventory/
    │   ├── reports/
    │   └── uploads/              product image add/delete routes
    ├── types/express.d.ts        req.user
    └── utils/
        ├── pagination.ts
        ├── dateRange.ts
        └── errors.ts             AppError + factories
```

Module rule: `*.routes.ts` parses HTTP input and calls one service method; `*.service.ts` owns
business rules, transactions and error codes; `*.repository.ts` owns Prisma queries only;
`*.schema.ts` owns Zod schemas. A service never imports Express types. A repository never throws
an `AppError`.

Modules export plain functions, not classes; there is no DI container. Services import repository
functions, and the repository imports the Prisma singleton. Zod schemas are the only source of
request types: `type CreateProductInput = z.infer<typeof createProductSchema>`, and services accept
those parsed types, never `req.body`.

### HTTP pipeline

Order in `app.ts`:

1. `pino-http` with request id and redaction of `authorization`, `password`, `refreshToken`.
2. `express.json({ limit: "1mb" })`.
3. `GET /uploads/**` static files from `UPLOAD_DIR`, one-day cache, outside `/api/v1`.
4. `GET /health` → `200 { "status": "ok" }`.
5. `/api/v1` routers.
6. `notFound` and `error` middleware.

`error.ts` maps:

| Source | Response |
|---|---|
| `AppError` | its code, status, message and optional details |
| `ZodError` | `400 VALIDATION_FAILED`, one `details` entry per field |
| malformed JSON (`entity.parse.failed`) | `400 VALIDATION_FAILED` |
| multer `LIMIT_FILE_SIZE` | `413 FILE_TOO_LARGE` |
| other multer errors (wrong field, unexpected file) | `400 VALIDATION_FAILED`, `details[].field` names the offending field |
| Prisma `P2025` | `404 NOT_FOUND` |
| Prisma `P2003` | `409 IN_USE` |
| anything else | `500 INTERNAL`, stack logged, never leaked |

Uniqueness violations are not in the global table. The owning service catches `P2002` and throws
the semantic code (`EMAIL_TAKEN`, `SKU_TAKEN`, `VARIANT_EXISTS`, `NAME_TAKEN`); an unmapped one is
logged and returns `INTERNAL`.

Body schemas use `.strict()`; query schemas drop unknown keys, matching the API contract. The
`validate` helper turns parse failures into `AppError("VALIDATION_FAILED", 400, ...)`.

### Auth

- Access token: JWT, 15 minutes, `sub` and `role` claims, `JWT_ACCESS_SECRET`.
- Refresh token: 32 random bytes hex, 30 days, stored as SHA-256 in `refresh_token`; every refresh
  revokes the presented row and issues a new one.
- `auth` middleware verifies the JWT, then loads the user row and rejects missing or `DISABLED`
  accounts on every request, as the contract requires.
- `requireRole("ADMIN")` guards `/admin/**`.
- `POST /auth/logout` is idempotent and revokes the presented refresh token.

### Uploads

`POST /admin/products/:id/images` accepts `multipart/form-data` with field `file`. Multer buffers
at most 5 MB in memory; `lib/fileStorage.ts` verifies JPEG, PNG or WebP by magic bytes; the file
is written as `<uuid>.<ext>` under `UPLOAD_DIR/products`. At most five images per product,
`position` is the lowest free slot. Deletes remove the row and the file best effort.
`Cache-Control: public, max-age=86400` on `/uploads`.

### Configuration

`src/config/env.ts` validates every variable with Zod and exits before listening on failure.
`.env.example` carries development values.

| Variable | Default | Use |
|---|---|---|
| `NODE_ENV` | `development` | log formatting |
| `PORT` | `8787` | HTTP port |
| `DATABASE_URL` | required | MySQL connection; parsed into the MariaDB adapter |
| `PUBLIC_BASE_URL` | `http://127.0.0.1:8787` | VNPay return URL, mock payment page, HTML links |
| `JWT_ACCESS_SECRET` | required | access token signing |
| `ACCESS_TOKEN_TTL_SECONDS` | `900` | 15 minutes |
| `REFRESH_TOKEN_TTL_DAYS` | `30` | refresh lifetime |
| `PAYMENT_PROVIDER` | `MOCK` | `MOCK` or `VNPAY` |
| `SHIPPING_FEE` | `30000` | order shipping fee |
| `LOW_STOCK_THRESHOLD` | `5` | low-stock report default |
| `UPLOAD_DIR` | `uploads` | product image storage and static root |
| `SEED_ADMIN_EMAIL` | `admin@stylo.local` | seed admin |
| `SEED_ADMIN_PASSWORD` | `Admin@12345` | seed admin, development only |
| `SEED_ADMIN_NAME` | `Stylo Admin` | seed admin |
| `VNPAY_TMN_CODE` | empty | required when `PAYMENT_PROVIDER=VNPAY` |
| `VNPAY_HASH_SECRET` | empty | required when `PAYMENT_PROVIDER=VNPAY` |
| `VNPAY_URL` | sandbox URL | payment gateway endpoint |
| `VNPAY_IP_ADDR` | `127.0.0.1` | `vnp_IpAddr`; VNPay requires the customer IP, which a local server cannot know |

There is no CORS, helmet or rate limiting. That is a local-demo decision, not a production
posture. VNPay IPN is not reachable from localhost; confirmation is finalised at return, as
decided in [ticket 03](../.scratch/stylo-app/issues/03-xac-minh-vnpay-sandbox.md).

### Prisma and seed

- `prisma/schema.prisma` is the executable form of [erd.md](erd.md).
- `generator client { provider = "prisma-client"; output = "../src/generated/prisma" }`.
- `src/lib/prisma.ts` builds one `PrismaMariaDb` adapter from `DATABASE_URL`, one `PrismaClient`,
  and disconnects on `SIGINT`/`SIGTERM`. `@prisma/adapter-mariadb` is Prisma's driver adapter for
  MySQL and MariaDB; it speaks the MySQL protocol, so the database image remains `mysql:8.4`.
- `prisma.config.ts` declares the schema path, migrations path and seed command. Prisma loads
  `.env` through `dotenv` in that config.
- Development: `prisma migrate dev`; demo: `prisma migrate deploy`; `npm run db:reset` is
  `prisma migrate reset --force`, which drops the schema, applies migrations and runs the
  configured seed.
- Seed is deterministic and idempotent: admin from env, 4 categories, 4 brands, 185 products
  (546 variants) and 185 images from the committed snapshot in `seed-assets/catalog/`, 12
  customers, 140 generated orders across every status and payment state, and 3 inventory
  receipts. `prisma/seed.ts` reads `catalog.json` and copies the committed JPEGs; it never
  downloads at runtime. Orders and receipts derive from the snapshot with a fixed seed. Each
  receipt writes the matching `StockMovement` rows, and the final reconciliation query sets
  `stock` from the ledger, so the check in `erd.md` stays clean. Source, licence and the
  generator are documented in `seed-assets/README.md` and ADR-0014. The full specification,
  including seeded accounts and edge cases, is in
  [testing.md](testing.md#seed-and-demo-data).

### npm scripts

```json
{
  "dev": "tsx watch src/index.ts",
  "build": "tsc -p tsconfig.build.json",
  "start": "node dist/index.js",
  "typecheck": "tsc --noEmit",
  "test": "npm run test:unit && npm run test:integration",
  "test:unit": "vitest run --config vitest.unit.config.ts",
  "test:integration": "vitest run --config vitest.integration.config.ts",
  "db:generate": "prisma generate",
  "db:migrate": "prisma migrate dev",
  "db:deploy": "prisma migrate deploy",
  "db:seed": "prisma db seed",
  "db:reset": "prisma migrate reset --force && prisma db seed",
  "db:studio": "prisma studio"
}
```

`postinstall` runs `prisma generate`. ESM with `module: NodeNext` means relative imports end in
`.js`. `db:reset` chains `prisma db seed` because Prisma 7's `migrate reset` does not run the
configured seed ([prisma#27773](https://github.com/prisma/prisma/issues/27773)).

---

## Dependencies

### Android

| Purpose | Artifact | Version |
|---|---|---|
| Kotlin / Compose compiler | Kotlin Gradle plugin | 2.3.21 |
| Build | AGP / Gradle | 8.13.2 / 8.13 |
| Compose | `androidx.compose:compose-bom` | 2026.03.00 (Compose 1.10.5, Material3 1.4.0) |
| Activity | `androidx.activity:activity-compose` | 1.12.0 |
| Core | `androidx.core:core-ktx` | 1.18.0 |
| Lifecycle | `lifecycle-runtime-compose`, `lifecycle-viewmodel-compose` | 2.10.0 |
| Navigation | `androidx.navigation:navigation-compose` | 2.9.6 |
| DI | Hilt | 2.58 |
| DI + Compose | `androidx.hilt:hilt-navigation-compose` | 1.3.0 |
| KSP | `com.google.devtools.ksp` | 2.3.13 |
| HTTP | Retrofit + kotlinx.serialization converter | 3.0.0 |
| HTTP | OkHttp + logging interceptor | 4.12.0 |
| JSON | `kotlinx-serialization-json` | 1.12.0 |
| Coroutines | `kotlinx-coroutines-android` | 1.11.0 |
| Storage | `androidx.datastore:datastore-preferences` | 1.2.0 |
| Images | Coil 3 (`coil-compose`, `coil-network-okhttp`) | 3.6.3 |
| Custom Tabs | `androidx.browser:browser` | 1.10.0 |
| Icons | `androidx.compose.material:material-icons-core` | via BOM |
| Test | JUnit4 / `kotlinx-coroutines-test` / Turbine | 4.13.2 / 1.11.0 / 1.2.1 |

These are the versions the scaffold build proves on this machine (ticket 13). Later AndroidX
releases — core-ktx 1.19, activity 1.13, lifecycle 2.11, navigation 2.10, Compose 1.11, OkHttp 5 —
require AGP 9.1, Gradle 9.3.1 and `compileSdk 37`; do not bump them without upgrading the whole
toolchain. Hilt 2.59+ also requires AGP 9, so Hilt stays at 2.58 and the build forces
`kotlin-metadata-jvm:2.3.21` (the version Hilt 2.60.1 ships) so its compiler can read Kotlin 2.3
metadata.

### Backend

| Purpose | Package | Version |
|---|---|---|
| Runtime | Node.js | 24 |
| HTTP | `express` | 5.3.0 |
| Validation | `zod` | 4.6.7 |
| ORM | `@prisma/client` | 7.10.1 |
| ORM adapter | `@prisma/adapter-mariadb` | 7.10.1 |
| DB driver | `mariadb` (dependency of the adapter) | 3.5.4 |
| Auth | `jsonwebtoken` | 9.0.3 |
| Password | `argon2` | 0.45.2 |
| Logging | `pino` / `pino-http` | 10.4.0 / 11.0.0 |
| Upload | `multer` | 2.5.0 |
| Env | `dotenv` | 18.0.9 |
| Build | `typescript` / `tsx` | 7.0.2 / 4.23.15 |
| Prisma CLI | `prisma` | 7.10.1 |
| Types | `@types/node` / `@types/express` / `@types/jsonwebtoken` / `@types/multer` / `@types/supertest` | 24.19.2 / 5.0.6 / 9.0.10 / 2.3.0 / 7.2.1 |
| Test | `vitest` / `supertest` | 5.1.0 / 7.3.1 |
| Dev logs | `pino-pretty` | 13.2.0 |

TypeScript 7.0.2 is proven against the generated Prisma client by `npm run typecheck` during the
scaffold. If its type resolution breaks, the latest 5.x release is pinned and recorded here.

---

## Local runtime

### MySQL

```bash
docker run --name stylo-mysql \
  -e MYSQL_ROOT_PASSWORD=stylo-root \
  -e MYSQL_DATABASE=stylo \
  -e MYSQL_USER=stylo \
  -e MYSQL_PASSWORD=stylo \
  -p 3306:3306 \
  -d mysql:8.4
```

`DATABASE_URL="mysql://stylo:stylo@127.0.0.1:3306/stylo"`.

Create the test schema once (the app user cannot create databases):

```bash
docker exec stylo-mysql mysql -uroot -pstylo-root -e \
  "CREATE DATABASE IF NOT EXISTS stylo_test CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci; \
   GRANT ALL PRIVILEGES ON stylo_test.* TO 'stylo'@'%';"
```

`server/.env.test` then uses
`DATABASE_URL="mysql://stylo:stylo@127.0.0.1:3306/stylo_test"`.

`prisma migrate dev` needs a shadow database, which Prisma creates and drops. Grant the local
`stylo` user that right once (local Docker only, never a shared or production server):

```bash
docker exec stylo-mysql mysql -uroot -pstylo-root -e \
  "GRANT ALL PRIVILEGES ON *.* TO 'stylo'@'%';"
```

### Backend

```bash
cd server
cp .env.example .env
npm install
npm run db:migrate
npm run db:seed
npm run dev            # http://0.0.0.0:8787, /health
```

### Android on the AVD

Start the AVD from [`mobile-cli.md`](mobile-cli.md) if it is not running, then:

```bash
adb -s emulator-5554 reverse tcp:8787 tcp:8787
cd android
./gradlew assembleDebug
adb -s emulator-5554 install -r app/build/outputs/apk/debug/app-debug.apk
```

Override the API origin when not using `adb reverse`:

```bash
./gradlew assembleDebug -Pstylo.apiBaseUrl=http://10.0.2.2:8787/api/v1/
```

`PUBLIC_BASE_URL` must match the URL the device browser can reach. With `adb reverse`, the
default `http://127.0.0.1:8787` works for the app, images and VNPay return pages opened on the
device.

---

## Verification before closing the scaffold

1. `npm install` resolves the backend set; `npm run typecheck` and `npm run test:unit` pass. With
   the MySQL container and the `stylo_test` schema up, `npm test` also passes.
2. `./gradlew assembleDebug` resolves the Android catalog.
3. API boots, `GET /health` returns `200`, `GET /uploads/...` serves a seed image.
4. App builds, installs on the AVD, reaches `/health` through the network layer and reaches the first
   screen.

Later tickets: 07 owns screens and design system, 08 owns submission artifacts, 10 owns report
formulas. Ticket 09 decided test coverage and demo data in [testing.md](testing.md).
