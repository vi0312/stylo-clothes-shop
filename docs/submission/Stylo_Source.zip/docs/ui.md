# UI design

Chốt 2026-11-05 tại [ticket 07](../.scratch/stylo-app/issues/07-thiet-ke-ui.md), sau khi dựng
prototype Compose và xem trên AVD. Đây là nguồn chuẩn cho các ticket dựng UI Android (15, 17, 20,
25, 27, 29, 30, 32) và cho chương "Thiết kế giao diện" của báo cáo.

## Quyết định đã chốt

| Chủ đề | Chốt |
|---|---|
| Palette | **Ấm**: ivory + mực + terracotta, heading serif |
| Theme | **Chỉ light**; không dark mode, không toggle |
| Trang chủ | Bố cục **A** — hero, category chips, carousel "Mới về", dải freeship, hai khối danh mục "Áo" và "Quần" (4 sản phẩm mỗi khối + "Xem tất cả") |
| Catalog / tìm kiếm | Bố cục **B** — search + filter chips + sort + grid 2 cột + bottom nav |
| Dashboard admin | **A** — 4 thẻ KPI, bar chart 7 ngày, top sản phẩm, đơn gần đây |
| Ảnh sản phẩm | **3:4 dọc**; gallery chi tiết crop **1:1** |
| Ngôn ngữ | UI tiếng Việt; số tiền VND (`289.000 ₫`), ngày `dd/MM/yyyy HH:mm`, giờ `Asia/Ho_Chi_Minh` |
| Thuật ngữ | Chuỗi hiển thị theo `GLOSSARY.md` §Thuật ngữ UI ("Kích cỡ", "Biến thể"); không để tên model (`Variant`, `size`) lọt ra UI |

Prototype và ảnh: [`.scratch/stylo-app/assets/07/`](../.scratch/stylo-app/assets/07/). Mã
prototype nằm ở `android/app/src/debug/java/com/stylo/shop/prototype/`, chỉ có trong bản debug
(`UiPreviewActivity`), không vào release. Prototype và app dùng chung `StyloTheme`; các palette
steel/mono và dark chỉ còn trong ảnh lịch sử.

## Design system

`StyloTheme` là nguồn duy nhất cho màu, chữ và shape; không dùng `darkColorScheme`, không dynamic
color. Mọi màn (kể cả prototype) lấy token từ `MaterialTheme`; không hardcode hex trong screen.

Control lặp lại **chỉ** được định nghĩa một lần trong
`android/app/src/main/java/com/stylo/shop/core/ui/components/` (`StyloCard`, `StyloFilterChip`,
`StyloSwatch`, `StyloSizeChip`, `StyloQtyStepper`, `StyloBusyButton`, `StyloStatusBadge`,
`StyloListSkeleton`, `StyloEmptyState`, `StyloErrorState`, `StyloInlineError`, `StyloSearchField`,
`StyloThumbnail`, `StyloConfirmDialog`, `StyloStickyCta`). Screen chỉ bố cục + state; nếu một màn
cần quy cách khác thì sửa component, không dựng lại chip/card/badge tại chỗ (ADR 0016 §2).

### Màu

Nền và bề mặt tách nhẹ để card nổi mà không cần shadow. Terracotta chỉ dùng cho link, nhấn phụ và
trạng thái cần chú ý; CTA chính luôn là mực đặc.

| Token | Hex | Dùng cho |
|---|---|---|
| `background` | `#F6F1E8` | Nền màn hình |
| `surface` | `#FBF8F1` | Bottom bar, sheet |
| `surfaceContainerLowest` | `#FFFFFF` | Card (1.13:1 trên nền — xem §Spacing) |
| `surfaceVariant` | `#EDE5D8` | Search field, chip chưa chọn, hàng highlight |
| `primary` / ink | `#1E1C18` | CTA, heading, chữ chính |
| `secondary` / terracotta | `#A6512B` | Link "Xem tất cả", delta, cảnh báo nhẹ |
| `onSurfaceVariant` | `#6C6255` | Chữ phụ, metadata |
| `outline` | `#8F8069` | Viền input, chip, stepper |
| `outlineVariant` | `#E8DFD1` | Divider, đường phân cách trang trí |
| `success` | `#256B45` trên `#E3F4EA` | Đã giao, đang bán |
| `warning` | `#8A5300` trên `#FDF0D9` | Chờ xử lý, tồn thấp |
| `info` | `#1C4E80` trên `#E4EFFA` | Đã xác nhận, đã thanh toán |
| `indigo` | `#3D3A8C` trên `#E9E8FA` | Đang giao |
| `neutral` | `#5B5B5B` trên `#EFEFEF` | Đã huỷ, đã ẩn |
| `error` | `#B3261E` | Lỗi form, lỗi tải |

`outline` phải đạt ≥3:1 với mọi nền mà nó đặt lên; `#8F8069` đạt 3.63 trên `surface`,
3.42 trên `background`, 3.08 trên `surfaceVariant` (WCAG 1.4.11). Không dùng `outlineVariant`
làm viền control. Focus của input dùng `primary` 2dp; selected chip dùng `primary`/`onPrimary`
kèm icon check, không chỉ đổi màu.

#### Map sang Compose `ColorScheme`

`StyloTheme` cung cấp đủ role; không để component rơi về scheme mặc định của Material3.

| Role | Hex | Role | Hex |
|---|---|---|---|
| `primary` | `#1E1C18` | `onPrimary` | `#FBF8F1` |
| `primaryContainer` | `#E4DACB` | `onPrimaryContainer` | `#1E1C18` |
| `secondary` | `#A6512B` | `onSecondary` | `#FFF6EF` |
| `secondaryContainer` | `#F5DFD4` | `onSecondaryContainer` | `#3F1B0C` |
| `tertiary` | `#4F5E3F` | `onTertiary` | `#FFFFFF` |
| `tertiaryContainer` | `#E3E9D9` | `onTertiaryContainer` | `#1A2412` |
| `error` | `#B3261E` | `onError` | `#FFFFFF` |
| `errorContainer` | `#F9DEDC` | `onErrorContainer` | `#410E0B` |
| `background` | `#F6F1E8` | `onBackground` | `#1E1C18` |
| `surface` | `#FBF8F1` | `onSurface` | `#1E1C18` |
| `surfaceVariant` | `#EDE5D8` | `onSurfaceVariant` | `#6C6255` |
| `surfaceDim` | `#E9E3D8` | `surfaceBright` | `#FFFBF5` |
| `surfaceContainerLowest` | `#FFFFFF` | `surfaceContainerLow` | `#FBF8F1` |
| `surfaceContainer` | `#F6F1E8` | `surfaceContainerHigh` | `#F0E9DD` |
| `surfaceContainerHighest` | `#EDE5D8` | `inverseSurface` | `#332F29` |
| `inverseOnSurface` | `#F8F3EA` | `inversePrimary` | `#D9CEBD` |
| `outline` | `#8F8069` | `outlineVariant` | `#E8DFD1` |
| `scrim` | `#000000` | `surfaceTint` | `#1E1C18` |

Năm màu trạng thái (`success`, `warning`, `info`, `indigo`, `neutral`) không có trong
`ColorScheme`; code cung cấp qua `MaterialTheme.statusColors` (`StyloStatusColors`) với cặp
`*Container` / `on*Container` trong bảng trên.

### Brand

Logo là một kit riêng, lưu ở [`docs/brand/`](../brand/); app dùng 4 VectorDrawable sinh từ SVG và
không copy file thiết kế vào `res/`. Quyết định: [ADR 0015](adr/0015-brand-identity-assets.md).

| Surface | Asset gốc | Resource |
|---|---|---|
| Launcher icon (adaptive + themed) | `stylo-symbol-terracotta-tile` / `stylo-symbol-mono-black` | `mipmap-anydpi-v26/ic_launcher.xml` |
| Header Home / Catalog | `stylo-lockup-horizontal-mono-black` | `drawable/ic_stylo_lockup_horizontal.xml`, cao 22dp / 20dp |
| Đăng nhập / Đăng ký | `stylo-lockup-stacked-color` (recolor một màu) | `drawable/ic_stylo_lockup_stacked.xml`, cao 96dp |

- Mark trong app **luôn monochrome**, tô bằng `MaterialTheme.colorScheme.primary` trong
  `core/ui/BrandMark.kt`; không hardcode `#E04F26` hay `#141210` trong screen.
- Cam `#E04F26` chỉ sống trên icon launcher — surface hệ thống, ngoài `StyloTheme`. Palette UI
  không đổi, nên không có chuyện hai màu cam cạnh nhau.
- Không dùng PNG 512 làm icon launcher: đó là tile full-bleed đã bo góc, glyph sát mép nên mask
  của launcher sẽ cắt.

### Typography

Heading dùng `FontFamily.Serif` (Noto Serif trên máy), body/label dùng sans mặc định. Không bundle
font file; không dùng font ngoài hệ thống.

| Vai trò | Token Compose | Style |
|---|---|---|
| Hero trang chủ | `headlineMedium` | 28sp / 36sp, serif, semibold |
| Display / lookbook | `displaySmall` | 40sp / 44sp, serif, semibold |
| KPI | `headlineSmall` | 24sp / 30sp, serif, semibold |
| Screen / section title | `headlineSmall` | 24sp / 30sp, serif, semibold |
| Card title | `titleLarge` | 18sp / 24sp, serif, semibold |
| Price lớn | `titleMedium` | 16sp / 24sp, sans, semibold |
| Price thường | `titleSmall` | 14sp / 20sp, sans, semibold |
| Body | `bodyMedium` | 14sp / 20sp, sans |
| Button / chip | `labelLarge` | 14sp / 20sp, sans, medium |
| Badge / metadata | `labelMedium` | 12sp / 16sp, sans, medium |
| Overline | `labelSmall` | 11sp / 16sp, sans, 1.5sp tracking |

Không đặt `fontSize`/`lineHeight` rời trong screen; dùng đúng token. Giá gạch ngang dùng
`bodySmall` màu `onSurfaceVariant`. Không viết tắt "tr"/"k" trên UI khách; dashboard được dùng
"tr" cho KPI. Số tiền và ký hiệu `₫` nối bằng NBSP (`Formatters.money`).

### Spacing, shape, elevation

- Lưới 4dp. Page margin ngang **20dp**. Khoảng giữa section **24dp**, giữa card trong lưới **14dp**,
  trong một row list **10–12dp**.
- Shape: `extraSmall 4`, `small 8`, `medium 12`, `large 18`, `extraLarge 24`. Card 12; ảnh card
  12; thumbnail 8; text field/menu 8; chip/button pill; dialog và sheet 24 (sheet chỉ hai góc
  trên); FAB 18.
- Phẳng: card không shadow, không viền; phân tách bằng **bề mặt**, không bằng đường kẻ. Cơ chế đã
  đo (audit 2026-11-08, ADR 0016): card dùng `surfaceContainerLowest` `#FFFFFF` trên nền
  `background` `#F6F1E8` = **1.13:1**; `surface` `#FBF8F1` chỉ đạt 1.06:1 nên **không dùng làm
  card**. Skeleton dùng `surfaceDim` `#E9E3D8` (1.28:1 trên card); `surfaceVariant` (1.18:1)
  không đủ thấy.
  Không thêm `BorderStroke` cho card ở bất kỳ màn nào — nếu card không nổi thì sửa bề mặt, không
  thêm viền.
  Chỉ `NavigationBar` có `tonalElevation = 3dp`. Dialog dùng `surfaceContainerHigh`, bottom sheet
  dùng `surfaceContainerLow`, menu dùng `surfaceContainer`; modal thêm `scrim`, không đổ shadow.
  Không dùng gradient ở đâu cả (kể cả hero): hero dùng bề mặt đặc để giữ đúng tông ấm.
- Touch target tối thiểu **48dp** cho mọi control. Icon 22–24dp nằm trong `IconButton` 48dp.
  `SizeChips` 48dp; `SearchField` 48dp; stepper nút 26dp nhưng bọc vùng chạm 48dp.

### Component dùng lại

| Component | Quy cách |
|---|---|
| `ProductCard` | Ảnh 3:4 + badge góc phải; tên `titleLarge` 1 dòng; brand `labelMedium`; giá. Không overlay tên lên ảnh |
| `PriceText` | `titleSmall` (lớn: `titleMedium`) + giá so sánh gạch ngang `bodySmall` |
| `ColorSwatches` | Chấm 26dp trong vùng chạm 48dp; swatch chọn có vòng 36dp + viền 2dp nổi bật trên cả màu tối; label "N màu" |
| `SizeChips` | Ô 48dp; size hết hàng mờ 40% và không chọn được |
| `QtyStepper` | Nút 26dp trong vùng chạm 48dp, số ở giữa; disable khi chạm tồn |
| `StickyCTA` | Bottom bar: giá bên trái, button 48dp bên phải; luôn nằm trên keyboard và trên `NavigationBar` ở màn tab |
| `StatusBadge` | Pill 8×3dp, `labelMedium`, `maxLines = 1`; map màu theo bảng trạng thái |
| `FilterChip` | `labelLarge`; chưa chọn `surfaceVariant`/`onSurfaceVariant` + viền `outline`, chọn `primary`/`onPrimary` + icon check; target 48dp |
| `AppNavBar` | `NavigationBar` M3: cao 80dp, active indicator `secondaryContainer`, icon 24dp, label 12sp; 5 tab customer, 4 tab admin |
| `Snackbar` | `inverseSurface`/`inverseOnSurface`, action `inversePrimary`; tối đa 2 dòng; hiện trên nav bar |
| `Dialog` | `surfaceContainerHigh`, shape 24dp, title `headlineSmall`, action text button `primary` |
| `BottomSheet` | `surfaceContainerLow`, 24dp hai góc trên, drag handle, scrim |
| `Menu` | `surfaceContainer`, shape 8dp, tonal elevation 2 |
| `TextField` | Outlined 56dp; viền `outline` 1dp, focus `primary` 2dp, lỗi `error`; label và supporting text `labelMedium`/`bodySmall` |
| `EmptyState` | Icon 48dp, tiêu đề, một dòng hướng dẫn, CTA nếu có |
| `ErrorState` | Thông điệp từ `ApiError.message`, nút "Thử lại" |
| `SearchField` | Pill 48dp, fill `surfaceVariant`, viền `outline`, icon search, hành động "Bộ lọc" bên phải; focus `primary` 2dp |
| `FilterSheet` | Bottom sheet shape 24dp: danh mục, thương hiệu, màu, size, khoảng giá; "Xoá lọc" / "Áp dụng" |
| `KpiCard` | Nhãn `labelMedium`, số `headlineSmall`, delta `labelMedium`; delta tồn thấp dùng `warning` |
| `RevenueBarChart` | Canvas, 7–14 cột, cột cuối `primary`; label trục `labelMedium`; bắt buộc text alternative (giá trị từng cột) cho TalkBack |
| `ImageUploader` | Tối đa 5 ảnh 3:4; ảnh đầu là cover; kéo/đổi thứ tự bằng nút, không drag |

### Ảnh

- Ảnh sản phẩm chuẩn **3:4**; grid/carousel hiển thị đúng tỉ lệ, `ContentScale.Crop`.
- Gallery chi tiết dùng khung **1:1** crop giữa, dots ở đáy; không pinch-zoom.
- Thumbnail giỏ hàng 84×112dp, admin row 46×61dp.
- Ảnh trả về dạng `/uploads/...`; resolve theo origin của `BuildConfig.API_BASE_URL` và tải bằng
  Coil 3. Placeholder: nền `surfaceVariant` + tên sản phẩm, không icon "broken image".
- Nội dung ảnh đồ án: ảnh chụp thật hoặc placeholder gradient có nhãn; không dùng ảnh mạng khi demo
  offline.

### Nhãn trạng thái

| Giá trị | Nhãn UI | Màu |
|---|---|---|
| `PENDING` | Chờ xử lý | warning |
| `CONFIRMED` | Đã xác nhận | info |
| `SHIPPING` | Đang giao | indigo |
| `DELIVERED` | Đã giao | success |
| `CANCELLED` | Đã huỷ | neutral |
| `UNPAID` | Chưa thanh toán | warning |
| `PAID` | Đã thanh toán | success |
| `FAILED` | Thanh toán lỗi | error |
| `ACTIVE` (product/user) | Đang bán / Hoạt động | success |
| `INACTIVE` / `DISABLED` | Đã ẩn / Đã khoá | neutral |
| Tồn thấp | Tồn thấp / "Còn N" | warning |
| Sản phẩm mới | Mới | `surface` / `onSurface` |

Không dùng màu làm tín hiệu duy nhất: badge luôn có chữ.

## Điều hướng

Một `NavHost` type-safe, ba graph lồng nhau; start graph theo session và role
([ADR-0008](adr/0008-android-client-architecture.md)).

- **auth**: `Login`, `Register`. Đăng nhập/xong dùng `popUpTo(0) { inclusive = true }` khi vào
  graph theo role; khách đăng nhập từ tab bị chặn thì pop `Login` và mở đúng tab đã chặn, không
  dựng lại back stack.
- **customer**: bottom nav 5 tab — `Home`, `Catalog` ("Tìm kiếm"), `Cart` (badge số món),
  `Orders`, `Profile`. Các màn đẩy tiếp: `ProductDetail(productId)`, `Checkout`,
  `OrderDetail(orderId)`, `AddressList`, `AddressForm(addressId?)`.
- **admin**: bottom nav 4 tab vận hành — `Dashboard`, `AdminOrders`, `AdminProducts`, `Inventory`
  ("Kho"); `NavigationDrawer` mở từ icon menu ở top bar cho `AdminCatalog` (danh mục & thương
  hiệu), `AdminUsers`, `AdminReports` và `Đăng xuất` (có dialog xác nhận). `AdminOrderDetail`,
  `AdminProductForm`, `AdminReceiptForm`, `AdminReceiptDetail` đẩy tiếp. Lý do dùng drawer thay
  overflow menu: Material 3 đặt >5 destination vào drawer, và mục ẩn trong ⋮ thì không có nhãn
  thường trực (ADR 0016 §3).
- Guest xem được Home/Catalog/ProductDetail. Chạm Giỏ/Đơn/Tôi → `Login`; sau đăng nhập quay lại
  đúng tab.
- Không deep link. VNPay mở bằng Custom Tab; khi app resume, refetch order và hiện banner kết quả.
- Admin không thấy tab customer; customer không thấy graph admin (server vẫn chặn `/admin/**`).
- Tab screen dùng `NavigationBar` Material3 (cao 80dp, active indicator `secondaryContainer`,
  icon 24dp, label 12sp), có ở Home, Catalog, Cart, Orders, Profile và 4 tab admin. Màn đẩy tiếp
  (ProductDetail, Checkout, form, detail) ẩn nav. Cart giữ nav; `StickyCTA` nằm trên nav, không
  che nội dung. Admin overflow dùng `Menu` (`surfaceContainer`, shape 8dp).

## Màn hình customer

Mọi màn dùng `UiState` chung: `Loading` (skeleton cho list, spinner cho detail/action), `Content`,
`Error(message, retry)`; list rỗng dùng `EmptyState`; form có `submitting` chặn double submit.

### Đăng nhập / Đăng ký

- Mục đích: lấy access + refresh token; không quên mật khẩu, không xác thực email.
- Thành phần: stacked lockup (monochrome, `StyloLockupStacked`), segmented "Đăng nhập | Đăng ký"; email, mật khẩu; đăng ký thêm họ
  tên, SĐT (optional); CTA; link đổi mode.
- Trạng thái: lỗi chung "Email hoặc mật khẩu không đúng" cho mọi lỗi đăng nhập; lỗi field inline
  cho đăng ký; nút loading khi submit.
- Điều hướng: thành công → graph theo role; đóng app giữa chừng thì lần mở sau vào thẳng.

### Trang chủ (A)

- Mục đích: dẫn vào bộ sưu tập và sản phẩm mới; không cần đăng nhập.
- Thành phần: header horizontal lockup (monochrome, `StyloLockupHorizontal`) + search (giỏ hàng và hồ sơ nằm ở bottom nav); hero 1.15:1;
  category chips; "Mới về" carousel ngang (8 sản phẩm); dải "Miễn phí giao hàng từ 500.000 ₫";
  hai khối danh mục "Áo" và "Quần", mỗi khối 4 sản phẩm + "Xem tất cả"; bottom nav 5 tab.
- Dữ liệu: `GET /products?sort=newest&limit=8` cho carousel; `GET /products?categoryId=…&limit=4`
  cho hai khối danh mục (id lấy từ `GET /catalog/filters`). API không có sort "bán chạy", nên
  không dựng section đó.
- Trạng thái: hero tĩnh; list lỗi → chỉ section lỗi + "Thử lại", không chặn cả trang; rỗng → ẩn
  section.
- Điều hướng: chip → Catalog đã lọc; card → ProductDetail; search → Catalog focus.

### Catalog / Tìm kiếm (B)

- Mục đích: duyệt, tìm không dấu, lọc kết hợp, sắp xếp, phân trang.
- Thành phần: search field, chip danh mục, nút "Bộ lọc" mở `FilterSheet` (danh mục, thương hiệu,
  màu, size, khoảng giá theo `GET /catalog/filters`), sort (Mới nhất / Giá tăng / Giá giảm), dòng
  "N sản phẩm", grid 2 cột, footer tải thêm.
- Trạng thái: loading skeleton 6 card; empty "Không tìm thấy sản phẩm" + "Xoá lọc"; lỗi + retry;
  hết trang → không còn spinner.
- Điều hướng: card → ProductDetail; back giữ nguyên filter trong `SavedStateHandle`.

### Chi tiết sản phẩm

- Mục đích: chọn đúng variant, thêm vào giỏ.
- Thành phần: gallery 1:1 + dots + nút back; brand; tên; giá; chọn màu (kèm "N màu"); chọn size
  (size hết hàng mờ 40% + nhãn đọc "hết hàng", hiện "Còn N" theo variant); mô tả; `StickyCTA`
  giá + "Thêm size {size} vào giỏ".
- Quy tắc: app chọn sẵn variant đầu tiên còn hàng (màu + size), nên CTA luôn bật **nhưng phải nêu
  variant đang mua** — "Thêm size S vào giỏ", đổi size/màu thì label đổi theo (ADR 0016 §5).
  Variant hết hàng không chọn được. Guest chạm CTA → Login.
- Không hiển thị "Đã bán N": API không có số bán tổng hợp (ADR 0016 §4).
- Trạng thái: 404/INACTIVE → ErrorState "Sản phẩm không còn bán" + về Catalog; lỗi mạng → retry.
- Điều hướng: thêm thành công → snackbar "Đã thêm vào giỏ" + badge tab; "Xem giỏ" trong snackbar.

### Giỏ hàng

- Mục đích: sửa số lượng, xoá, kiểm tra tồn trước checkout.
- Thành phần: list line (ảnh, tên, màu/size, giá, stepper, "Xoá"), line không khả dụng (sản phẩm
  ngừng bán) gắn nhãn và không tính tiền, summary (tạm tính, freeship), `StickyCTA` "Thanh toán"
  đặt trên `NavigationBar`; nav vẫn hiện vì Cart là tab.
- Quy tắc: stepper chặn ở `availableStock`; server là nguồn tổng tiền; sửa/xoá lạc quan nhưng
  rollback khi lỗi.
- Trạng thái: rỗng → EmptyState "Giỏ hàng trống" + "Mua sắm"; lỗi tải → retry; lỗi thao tác →
  snackbar, hoàn nguyên số lượng.

### Thanh toán

- Mục đích: chọn địa chỉ, phương thức thanh toán, đặt hàng idempotent.
- Thành phần: card địa chỉ mặc định + "Đổi" (mở `AddressList`); chọn COD / VNPay; ghi chú (nếu
  API hỗ trợ); tóm tắt đơn; `StickyCTA` "Đặt hàng · tổng".
  Không có endpoint public cho `SHIPPING_FEE`, nên màn này chỉ hiển thị tạm tính kèm ghi chú "phí
  vận chuyển xác nhận khi đặt hàng"; tổng chính xác hiện ở `OrderDetail`.
- Trạng thái: chưa có địa chỉ → CTA "Thêm địa chỉ"; `OUT_OF_STOCK` → highlight line và yêu cầu
  quay lại giỏ; `VALIDATION_FAILED` → lỗi field; submit chỉ một lần (`Idempotency-Key`).
- Điều hướng: COD/thanh toán mock thành công → `OrderDetail`; VNPay → Custom Tab, resume →
  refetch `OrderDetail` với banner "Đã thanh toán" / "Thanh toán chưa hoàn tất".

### Đơn hàng

- Danh sách: chip trạng thái (Tất cả + 5 trạng thái), row mã đơn + ngày + tổng + badge, phân trang,
  empty "Chưa có đơn hàng", lỗi + retry.
- Chi tiết: timeline trạng thái, danh sách item (ảnh, tên, size/màu, SL, giá), địa chỉ snapshot,
  tóm tắt tiền, payment status + phương thức, nút "Huỷ đơn" chỉ khi `PENDING`/`CONFIRMED`.
  `GET /orders/:id` không trả `imageUrl` cho item nên bản dựng ở ticket 25 hiển thị dòng item
  không ảnh; ảnh chỉ thêm được nếu API bổ sung trường đó.
- Trạng thái: loading skeleton; 404 → ErrorState + về danh sách; lỗi tải → retry; huỷ lỗi →
  snackbar và refetch.
- Hành động: huỷ → dialog xác nhận, refetch; VNPay `UNPAID` sau khi hết hạn có thể "Thanh toán
  lại" nếu API cho phép.

### Hồ sơ và địa chỉ

- Hồ sơ: email (read-only), họ tên, SĐT; nút Lưu; link "Địa chỉ giao hàng"; nút Đăng xuất (xác
  nhận). Không avatar.
- Địa chỉ: list card, badge "Mặc định", sửa/xoá, CTA "Thêm địa chỉ"; form gồm người nhận, SĐT,
  địa chỉ một dòng, toggle mặc định; xoá địa chỉ mặc định phải chọn địa chỉ khác làm mặc định hoặc
  chặn và giải thích.
- Trạng thái: hồ sơ đọc từ session cache nên **không có** loading/error riêng (không request);
  "Lưu" chỉ bật khi form khác bản gốc, lỗi lưu → snackbar. Địa chỉ: loading skeleton, empty
  "Chưa có địa chỉ" + CTA, lỗi tải → retry, form có field inline error và `submitting`.

## Màn hình admin

### Dashboard (A)

- Thành phần: bộ lọc ngày (mặc định 30 ngày gần nhất); 4 KPI — doanh thu, số đơn, giá trị đơn TB,
  số variant tồn thấp; bar chart doanh thu 7 ngày; top 3 sản phẩm; 3 đơn gần đây.
- Nguồn: `GET /admin/reports/revenue?groupBy=day` (doanh thu, số đơn, giá trị TB), `top-products`,
  `low-stock`, và `GET /admin/orders?limit=3`.
- Trạng thái: KPI lỗi riêng từng thẻ thì hiện "—"; chart rỗng → "Chưa có doanh thu trong khoảng";
  lỗi toàn bộ → ErrorState.

### Đơn hàng

- Danh sách: chip trạng thái, row mã + khách + tổng + badge; lọc theo ngày nếu API có; phân trang.
- Chi tiết: khách + SĐT + địa chỉ, item kèm `unit_cost` (chỉ admin), payment, tổng; nút chuyển
  trạng thái theo transition hợp lệ — "Xác nhận", "Giao hàng", "Đã giao" (COD → `PAID`), "Huỷ"
  (chỉ `PENDING`/`CONFIRMED`); dialog xác nhận; lỗi transition → snackbar và refetch.
- Trạng thái: list loading skeleton, empty "Chưa có đơn trong khoảng", lỗi + retry; detail loading,
  404 → ErrorState + quay lại, lỗi tải + retry.

### Sản phẩm

- Danh sách: search theo tên, chip trạng thái (Tất cả/Đang bán/Đã ẩn/Tồn thấp), filter danh mục +
  thương hiệu, row ảnh + tên + brand + số variant + giá + badge + chevron; nút "Thêm".
- Form tạo/sửa: tên, mô tả, danh mục, thương hiệu, trạng thái; `ImageUploader` tối đa 5 ảnh; danh
  sách variant (SKU, size, màu, giá) thêm/sửa/xoá từng dòng; **stock không sửa ở đây** — chỉ đổi
  qua phiếu nhập, hiển thị read-only kèm ghi chú.
- Xoá: chỉ khi chưa phát sinh đơn/phiếu; nếu `409 IN_USE` → gợi ý chuyển `INACTIVE` thay vì xoá.
- Trạng thái: list loading skeleton, empty "Chưa có sản phẩm" + CTA, lỗi + retry; SKU trùng →
  lỗi inline; upload lỗi → giữ form, cho thử lại từng ảnh; submit chặn double tap.

### Danh mục và thương hiệu

- Hai tab trong một màn; list + search + trạng thái; dialog tạo/sửa tên và trạng thái; xoá bị chặn
  khi `productCount > 0` (`409 IN_USE`) → giải thích thay vì xoá.
- Trạng thái: loading skeleton, empty theo tab, lỗi + retry; dialog lỗi tên trùng → field inline.

### Người dùng

- Search theo tên/email; row avatar chữ cái + tên + email + role + badge; chỉ hành động khoá/mở
  (`PATCH` status), không đổi role, không tạo user trong app; empty state khi không khớp.
- Trạng thái: loading skeleton, empty "Không tìm thấy người dùng", lỗi + retry; lỗi khoá/mở →
  snackbar và refetch.

### Phiếu nhập kho

- Danh sách: mã `PN-…`, ngày, nhà cung cấp, số dòng, tổng tiền; phân trang; nút "Tạo phiếu".
- Form: nhà cung cấp (text), ghi chú, các dòng chọn variant (search theo SKU/tên), số lượng, đơn
  giá nhập; cộng dòng; tổng tiền; submit một lần. Sau lưu: chỉ xem, không sửa/xoá.
- Chi tiết: thông tin phiếu + các dòng + tổng; không có action sửa.
- Trạng thái: list loading skeleton, empty "Chưa có phiếu nhập" + CTA, lỗi + retry; form lỗi dòng
  (variant/quantity/price) inline; submit chặn double tap; chi tiết 404 → ErrorState.

### Báo cáo

- Một màn, segmented chọn báo cáo, bộ lọc `from`/`to` dùng chung; 5 báo cáo: doanh thu theo
  ngày/tháng, top sản phẩm (limit 10), đơn theo trạng thái, tồn kho thấp (threshold mặc định 5),
  chi phí nhập + lãi gộp.
- Hiển thị: chart cột cho doanh thu; bảng cho các báo cáo còn lại; mọi số tiền có nhãn đơn vị; empty
  "Không có dữ liệu trong khoảng"; không export file.
- Trạng thái: loading skeleton, lỗi + retry; chart có text alternative (giá trị từng cột) cho
  TalkBack; bảng giữ header khi cuộn nếu dài.

## Trạng thái dùng chung

- **Loading**: list dùng skeleton 3–6 hàng cùng chiều cao item; detail/action dùng spinner nhỏ
  trong nút hoặc giữa màn.
- **Empty**: icon + một câu nêu lý do + CTA khi có hành động hợp lý. Không dùng "Không có dữ liệu"
  trần.
- **Error**: message lấy từ `ApiError.message` theo catalogue `api.md`; luôn có "Thử lại" trừ lỗi
  validation. Không hiện stack trace hay mã lỗi thô.
- **Pagination**: append khi cuộn gần cuối; footer spinner chỉ khi còn trang; lỗi trang sau giữ
  item cũ + nút "Tải lại".
- **Form**: validate client theo cùng rule server; lỗi server map về field khi có `details`, còn
  lại hiện banner trên CTA.
- **Session hết hạn**: `TokenAuthenticator` refresh một lần; thất bại → về Login với thông báo
  "Phiên đăng nhập đã hết hạn".

## Kiểm chứng

Prototype đã được dựng và chụp trên AVD `stylo_api35` (Android 15, 360×640dp). Palette chốt là **Ấm + light**;
prototype hiện chỉ render palette này. Các ảnh steel/mono/dark bên dưới là lịch sử khảo sát, không
dùng làm ảnh cuối trong báo cáo.

| Màn | Ảnh |
|---|---|
| Trang chủ A | `07/home-a-warm.png` |
| Catalog B | `07/home-b-warm.png` |
| Chi tiết SP A | `07/product-a-warm.png` |
| Giỏ / Thanh toán | `07/cart-warm.png`, `07/checkout-warm.png` |
| Dashboard A / B | `07/admin-dash-a-warm.png`, `07/admin-dash-b-warm.png` |
| Danh sách SP admin | `07/admin-products-warm.png` |
| Design system (token + component) | `07/tokens-warm.png` |

Ảnh lịch sử (không dùng làm ảnh cuối): `home-b-steel.png`, `admin-*-steel.png`,
`product-b-steel.png`, `home-c-mono.png`, `tokens-steel.png`, `tokens-mono.png`,
`home-a-warm-dark.png`, `home-b-steel-dark.png`, `switcher-bar.png`.

Trang chủ chỉ chụp phần đầu (hero, chips, "Mới về"); hai khối "Áo"/"Quần" nằm dưới fold. Ảnh
được chụp lại ngày 2026-11-05 bằng `StyloTheme` ấm/light; ảnh cũ lưu ở `07/history/previous-device/`.
`ThemeContrastTest` khóa ngưỡng outline ≥3:1 và các cặp chữ ≥4.5:1 để tránh tái phát lỗi contrast.

Chạy lại prototype:

```bash
cd android
gradlew.bat :app:assembleDebug
adb -s emulator-5554 install -r app/build/outputs/apk/debug/app-debug.apk
adb -s emulator-5554 shell am start -n com.stylo.shop/.prototype.UiPreviewActivity
```

Extras để chụp từng màn: `--ei screen 0..5 --ei variant N --ez chrome false`. Prototype dùng mock
data, không gọi API, luôn chạy `StyloTheme` (ấm, light-only).

## Ngoài scope

- Dark mode và theme toggle.
- Landscape, tablet, foldable.
- Animation/motion ngoài transition mặc định của Compose.
- Web admin, app admin riêng.
- Push notification, deep link, chia sẻ sản phẩm.
- Export báo cáo, in PDF.
