# Brand assets

Nguồn sự thật cho logo Stylo. Android không giữ bản sao file thiết kế: `res/` chỉ chứa
VectorDrawable sinh ra từ đây.

## Hai loại hình

| Thuật ngữ | File | Dùng ở đâu |
|---|---|---|
| **Symbol** | `svg/stylo-symbol-*.svg` – 5 polygon trong canvas 256×256 | Icon launcher, themed icon |
| **Wordmark** | `svg/stylo-wordmark-*.svg` – 4 path chữ "stylo" | Chỉ dùng trong lockup |
| **Lockup** | `svg/stylo-lockup-horizontal-*.svg`, `svg/stylo-lockup-stacked-*.svg` | Header (horizontal), màn đăng nhập (stacked) |

## Surface → asset

| Surface | Asset gốc | Resource Android | Ghi chú |
|---|---|---|---|
| Launcher icon (adaptive) | `stylo-symbol-terracotta-tile.svg` | `res/drawable/ic_launcher_foreground.xml` + `res/values/colors.xml` (`#E04F26`) | Glyph = 58% canvas 108dp để nằm trong safe zone 66dp; nền lấy từ `ic_launcher_background` |
| Themed icon (Android 13+) | `stylo-symbol-mono-black.svg` | `res/drawable/ic_launcher_monochrome.xml` | Chỉ alpha; hệ thống tô màu |
| Header Home/Catalog | `stylo-lockup-horizontal-mono-black.svg` | `res/drawable/ic_stylo_lockup_horizontal.xml` | Monochrome, tint bằng `MaterialTheme.colorScheme.primary` |
| Login/Register | `stylo-lockup-stacked-color.svg` | `res/drawable/ic_stylo_lockup_stacked.xml` | Recolor toàn bộ sang 1 màu ink (kit không có bản stacked mono) |

## Luật dùng

- Mark **trong app luôn monochrome** và lấy màu từ `MaterialTheme`; không hardcode `#E04F26`
  hay `#141210` trong screen (xem [ADR 0015](../adr/0015-brand-identity-assets.md)).
- Cam `#E04F26` chỉ sống trên surface hệ thống (icon launcher). Palette UI vẫn là palette ấm của
  [docs/ui.md](../ui.md): ink `#1E1C18`, terracotta `#A6512B`.
- Không scale icon launcher bằng cách cắt từ PNG: file `png/android-chrome-512x512.png` là tile
  full-bleed bo góc, glyph sát mép, sẽ bị mask của launcher cắt mất.
- `png/app-store-icon-1024x1024.png` và `png/android-chrome-512x512.png` giữ cho báo cáo/store
  listing; không dùng làm resource Android.

## Sinh lại resource

Bốn file trong `res/drawable/` được dựng từ toạ độ trong SVG (polygon → `pathData`, group
transform giữ nguyên). Khi kit thay đổi, phải sửa tay bốn file đó; kiểm tra bằng
`./gradlew.bat :app:assembleDebug` và chụp lại launcher + header + login trên AVD.

## Nguồn gốc

Kit do chủ đồ án cung cấp (`stylo_logo_kit/`), không kèm file license hay brand guideline. Chỉ
dùng trong phạm vi đồ án; nếu phát hành công khai phải xác nhận lại quyền sử dụng.
