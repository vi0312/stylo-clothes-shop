# Mobile CLI

How an agent drives the local Android target for exploratory work, authoring and triage of the
Kaspresso journeys, and visual evidence. Assertions live in the Kaspresso suite in
[`testing.md`](testing.md); this CLI never decides pass/fail. The CLI is
[mobile-next/mobilecli](https://github.com/mobile-next/mobilecli): one Go binary plus a small daemon
that owns the device connection and exposes taps, swipes, text input, screenshots, the accessibility
tree, app management and logs as subcommands. Every call prints JSON with `status` and `data`, so a
shell or a script reads the same result the agent reads.

There is no MCP server in this repo. Ticket 40 records the migration and
[ADR-0012](adr/0012-mobilecli-over-mobile-mcp.md) the decision; `.omp/mcp.json` was deleted with the
`mobile-mcp` server, so no session mounts `mobile_*` tools. [ADR-0013](adr/0013-android-e2e-workflow.md)
defines the working loop: mobilecli explores a screen and reads its tags, the journey is written
against the same tags, and a failed run is replayed here. `android/e2e.cmd` stops the daemon before
Gradle because instrumentation needs the device's single `UiAutomation` connection.

## Prerequisites

| Need | This machine |
|---|---|
| Node.js 20+ (npm distribution of the CLI) | Node 24 |
| `adb` on `PATH` | `C:\Users\ThanhDat\AppData\Local\Android\Sdk\platform-tools\adb.exe` |
| adb server port | 5359 on this workstation; Windows reserves 4942–5041, so 5037 is unusable |
| A running target | AVD `stylo_api35` (Android 15, display 0) |

## Install and pin

```bash
npm install -g mobilecli@1.0.22
mobilecli --version
```

The version is pinned by this command and bumped deliberately, then re-smoked. From this repo's
shell the shim resolves directly (`mobilecli`, 0.56 s per call); `npx --yes mobilecli@1.0.22` also
works but costs 7–8 s per invocation, so it is only a fallback on a machine without the global
install.

The upstream agent skill — `npx skills add https://github.com/mobile-next/mobilecli` — is installed
machine-locally under `.agents/skills/mobilecli/` (gitignored). It documents the full command
surface; this file documents the Stylo setup and the traps found on this workstation.

## Device selection

`mobilecli devices` lists one entry for the AVD:

```json
{"id": "stylo_api35", "name": "stylo api35", "platform": "android",
 "type": "emulator", "version": "15", "state": "online"}
```

With a single online device the CLI selects it automatically. Pass `--device stylo_api35` (or export
`MOBILECLI_DEVICE=stylo_api35`) in any command that must be explicit. Discovery works with the adb
server on 5359 without setting `ANDROID_ADB_SERVER_PORT`; raw `adb` calls still need
`-P 5359`/the env var.

## Command reference

```bash
# Screen tree with @eN refs; JSON by default, `snapshot` prints the same as text
mobilecli dump ui --device stylo_api35
mobilecli snapshot --device stylo_api35 --full      # include the on-screen keyboard

# Act through the refs from the latest dump (they survive between invocations)
mobilecli io tap --device stylo_api35 @e27
mobilecli io fill --device stylo_api35 "customer01@stylo.local"   # replaces the focused field
mobilecli io text --device stylo_api35 "sends text to the focused field"
mobilecli io keys --device stylo_api35 "ctrl+v"
mobilecli io swipe --device stylo_api35 540,1500,540,600
mobilecli io button --device stylo_api35 BACK

# Screenshots for the ticket assets
mobilecli screenshot --device stylo_api35 -o .scratch/stylo-app/assets/40/home.png
mobilecli screenshot --device stylo_api35 -o shot.jpg -f jpeg -q 85 --max-size 800

# App lifecycle
mobilecli apps launch --device stylo_api35 com.stylo.shop
mobilecli apps foreground --device stylo_api35
mobilecli apps clear --device stylo_api35 com.stylo.shop     # wipes app data, keeps the APK
mobilecli apps terminate --device stylo_api35 com.stylo.shop

# Debugging
mobilecli device logs --device stylo_api35
mobilecli daemon status
mobilecli daemon stop
```

`io fill` was verified against a Compose `TextField` on this AVD: a 10-character string arrived
whole, where `adb shell input text` had truncated typed credentials. That is why the smoke recipe
prefers `fill` over the deprecated adb input path.

## Daemon and the UiAutomation conflict

The daemon keeps the Android side's single `UiAutomation` connection while it is up. Consequences:

- `adb -P 5359 shell uiautomator dump …` is **killed (exit 137)** and produces no file. It works
  again after `mobilecli daemon stop`. The old adb-smoke instructions are therefore retired: drive
  the UI with `mobilecli` only.
- Stop the daemon before instrumentation runs (`./gradlew :app:connectedDebugAndroidTest`), because
  the Kaspresso suite uses UiAutomator inside the app process and must own that connection.
- The daemon is a singleton per machine (`~/.mobilecli/daemon.sock`); a command starts it on demand,
  so a fresh shell needs no setup step.

## AVD setup

The AVD is created once per machine and reused; commands are recorded in
[ticket 02](../.scratch/stylo-app/issues/02-dung-toolchain-android.md).

```bash
sdkmanager "emulator" "system-images;android-35;google_apis;x86_64"
echo no | avdmanager create avd -n stylo_api35 \
  -k "system-images;android-35;google_apis;x86_64" -d pixel_6
```

Set the AVD to the same 360x640dp frame as the design in
`~/.android/avd/stylo_api35.avd/config.ini`:

```ini
hw.lcd.width=1080
hw.lcd.height=1920
hw.lcd.density=480
hw.gpu.enabled=yes
hw.gpu.mode=swiftshader_indirect
```

Boot it with the adb server port in the emulator's environment, so raw `adb` and the Kaspresso run
reach the same server:

```bash
ANDROID_ADB_SERVER_PORT=5359 emulator -avd stylo_api35
adb -P 5359 wait-for-device
adb -P 5359 shell getprop sys.boot_completed   # wait for 1
adb -P 5359 reverse tcp:8787 tcp:8787          # repeat after every emulator reboot
```

## Selector vocabulary

The app root sets `Modifier.semantics { testTagsAsResourceId = true }`, so every Compose `testTag`
from `UiTags` reaches uiautomator as a resource id, which `dump ui` reports in the `identifier`
field. Read a new screen's tags there, then write the journey against those names:

```json
{"ref": "@e40", "identifier": "profile_logout", "rect": {"x": 60, "y": 1656, "width": 960, "height": 144}}
```

Content inside dialogs, popups and modal sheets composes in its own window; that root sets the same
flag, so tags work there too. Snackbar actions are the exception (the Material host cannot take a
tag) and are matched by their text. List rows share one tag by design: match the row's visible text
or use the per-node `@eN` ref.

## Journey loop

1. Explore the screen here and note the `UiTags` values from `dump ui`.
2. Add or extend the journey under `android/app/src/androidTest/java/com/stylo/shop/e2e/`, one file
   per flow, using the same tags through the `E2e*Screen` objects.
3. Run `android\e2e.cmd -Class OrdersJourneyTest` from the repo root. It preflights adb, the API and
   the daemon; it does not start the server or the AVD.
4. On failure, rerun with `-LeaveApks`, replay the same steps here, and screenshot the stuck state
   into `.scratch/stylo-app/assets/<ticket>/`.

## Smoke loop

```bash
mobilecli apps clear --device stylo_api35 com.stylo.shop
mobilecli apps launch --device stylo_api35 com.stylo.shop
mobilecli dump ui --device stylo_api35          # read refs and labels
mobilecli io tap --device stylo_api35 @eN       # fill the login form the same way
mobilecli io fill --device stylo_api35 "<email>"
mobilecli screenshot --device stylo_api35 -o .scratch/stylo-app/assets/<ticket>/login.png
```

Dump before every tap that depends on layout: refs are numbered per dump, and a scroll or an IME
opening renumbers them. Match elements on `identifier` (a `UiTags` value), text or label, never on
coordinates estimated from a screenshot.

A ref taps the node's own `rect`, so a row below the fold (a `verticalScroll` column still reports
its off-screen children) gets an off-screen tap that silently misses. Scroll first, dump again, then
tap the fresh ref.
