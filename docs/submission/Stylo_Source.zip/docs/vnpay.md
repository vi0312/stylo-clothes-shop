# Thông Tin Cấu Hình Tích Hợp VNPAY (Môi Trường Sandbox)

> **Lưu ý quan trọng cho Agent / Developer:** 
> - Đây là thông tin môi trường **Sandbox (Test)**, chỉ dùng để kiểm thử hệ thống, tuyệt đối không sử dụng cho môi trường Production (thanh toán thật).
> - Hệ thống cần xây dựng một **IPN URL (Instant Payment Notification)** hoạt động theo cơ chế *server-to-server* để nhận cập nhật trạng thái giao dịch từ VNPAY.

---

## 1. Thông số cấu hình API (API Credentials)

| Tham số | Tên biến chuẩn | Giá trị | Mô tả |
| :--- | :--- | :--- | :--- |
| **Terminal ID** | `vnp_TmnCode` | `0Y4K2R1L` | Mã định danh Website / Merchant |
| **Secret Key** | `vnp_HashSecret` | `QADDVVZKDMHAJLMRNNMSNBWZZWRDLWBA` | Chuỗi bí mật dùng để tạo và kiểm tra chữ ký (checksum) |
| **Payment URL** | `vnp_Url` | `https://sandbox.vnpayment.vn/paymentv2/vpcpay.html` | Endpoint khởi tạo thanh toán môi trường TEST |

### Gợi ý cấu hình `.env` (Dành cho Coding Agent):
```env
VNP_TMN_CODE="0Y4K2R1L"
VNP_HASH_SECRET="QADDVVZKDMHAJLMRNNMSNBWZZWRDLWBA"
VNP_URL="https://sandbox.vnpayment.vn/paymentv2/vpcpay.html"
```

---

## 2. Thông tin thẻ Test (Dùng để giả lập thanh toán)

* **Ngân hàng:** `NCB`
* **Số thẻ:** `9704198526191432198`
* **Tên chủ thẻ:** `NGUYEN VAN A`
* **Ngày phát hành (MM/YY):** `07/15`
* **Mật khẩu OTP:** `123456`

---

## 3. Hệ thống Quản trị & Kiểm thử (Portals)

### Quản lý giao dịch (Merchant Admin)
* **URL:** https://sandbox.vnpayment.vn/merchantv2/
* **Tên đăng nhập:** `dat3kclonev1@nguyenvantruong.io.vn`
* **Mật khẩu:** *(Mật khẩu đã tạo khi đăng ký tài khoản Merchant TEST)*

### Kiểm thử kịch bản SIT & IPN URL
* **URL:** https://sandbox.vnpayment.vn/vnpaygw-sit-testing/user/login
* **Tên đăng nhập:** `dat3kclonev1@nguyenvantruong.io.vn`
* **Mật khẩu:** *(Mật khẩu đã tạo khi đăng ký tài khoản Merchant TEST)*

---

## 4. Tài liệu & Tài nguyên tham khảo

* **Tài liệu hướng dẫn tích hợp:** https://sandbox.vnpayment.vn/apis/docs/thanh-toan-pay/pay.html
* **Code demo tích hợp:** https://sandbox.vnpayment.vn/apis/vnpay-demo/code-demo-tích-hợp
* **Trải nghiệm Demo VNPAYQR:** https://sandbox.vnpayment.vn/apis/vnpay-demo/

---

## 5. Thông tin liên hệ hỗ trợ (VNPAY Support)

* **Email:** support.vnpayment@vnpay.vn
* **Hotline:** `1900 55 55 77`