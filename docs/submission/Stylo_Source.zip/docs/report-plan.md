# Report and submission plan

Decided at [ticket 08](../.scratch/stylo-app/issues/08-chot-ho-so-do-an.md), 2026-11-07. This file is the
working plan for the coursework dossier: what gets submitted, in what shape, in what order. It is English
because it is a technical plan; the report itself is Vietnamese.

The faculty published no template and no schedule (confirmed with the student on 2026-11-07). Everything
below is the standing rule until one appears. **A faculty template wins over the format section, and a
faculty deadline wins over the timeline.**

## Artifacts

| # | Artifact | Format | Built from | Frozen at |
|---|---|---|---|---|
| 1 | Main report, `BaoCao_Stylo.pdf` (+ `.docx` source) | PDF, Vietnamese | outline below, chapters sourced from `docs/*.md` | freeze |
| 2 | Defense slides, 15 min | PPTX + PDF | report chapters 2, 3, 4, 5 | freeze |
| 3 | Source code | zip of the repo, no `node_modules`/`build`/`.gradle`, no `.env` | working tree | freeze |
| 4 | Database dump, `stylo-db.sql` | `mysqldump --databases stylo` after `db:reset` on seed data | seeded MySQL container | freeze |
| 5 | ERD, A3 | PDF, one page, legible at A3 | `docs/erd.md` Mermaid diagram | freeze |
| 6 | Demo video, 5–10 min | MP4, screen recording of the AVD | demo script below | freeze |

No progress log or work-split sheet: solo project.

## Format

Nothing is imposed, so the report uses: A4; Times New Roman 13; line spacing 1.5; margins top 3, bottom 2,
left 3, right 2 cm; body 45–70 pages excluding appendices; chapters numbered `1..6`; figures and tables
numbered per chapter (`Hình 3.2`, `Bảng 2.1`); page numbers bottom centre; references after chapter 6,
appendices after references.

Cover page (faculty template absent): school name, faculty, major, subject, topic
("Ứng dụng bán quần áo"), instructor, student name, student id, class, year — each on its own line,
centred.

## Outline

| Chapter | Pages | Content | Source of truth |
|---|---|---|---|
| 1. Giới thiệu | 5 | problem, objectives, actors, scope in/out, tech stack | `docs/PROJECT.md`, [ticket 01](../.scratch/stylo-app/issues/01-chot-pham-vi-chuc-nang.md) |
| 2. Phân tích yêu cầu và chức năng | 10 | the 12 functions with actor and acceptance criteria, use cases, business rules, order lifecycle | [ticket 01](../.scratch/stylo-app/issues/01-chot-pham-vi-chuc-nang.md), `GLOSSARY.md` |
| 3. Thiết kế cơ sở dữ liệu | 12 | ERD (16 tables), value conventions, stock ledger, transactions, delete rules, the 4 domain ADRs | `docs/erd.md`, ADR 0001–0004 |
| 4. Thiết kế giao diện | 12 | design system (colour, type, spacing, components), navigation by role, customer screens, admin screens, shared states | `docs/ui.md`, `.scratch/stylo-app/assets/*.png` |
| 5. Cài đặt và kiểm thử | 15 | architecture, API contract, Android client, payment flow, test strategy and results, demo data | `docs/architecture.md`, `docs/api.md`, `docs/testing.md`, ADR 0005–0011 |
| 6. Kết luận và hướng phát triển | 5 | requirement coverage, limitations, known limitations from `erd.md`, future work | map's Out of scope section |
| Phụ lục A | — | endpoint table grouped by module | `docs/api.md` |
| Phụ lục B | — | demo script and environment setup | this file |
| Phụ lục C | — | how to run: Docker, `db:reset`, `adb reverse`, accounts | `docs/architecture.md`, `docs/testing.md` |

Chapter 2 leads with the 12-row function matrix, not prose. Chapter 3's ERD is the A3 page, reproduced
full-page. Chapter 4 uses real AVD screenshots, never mockups. Chapter 5 quotes test counts from an actual
run at freeze time.

## Timeline

Assumed: report due **2026-12-19**, defense in the week of **2026-12-21**. Both are placeholders until the
faculty publishes the real dates.

| Date | Milestone | Done when |
|---|---|---|
| 2026-11-20 | Outline + chapters 1–2 drafted | every function in ch. 2 traces to ticket 01 |
| 2026-11-28 | Chapter 3 | ERD exported at A3, tables enumerate all 16 |
| 2026-12-05 | Chapter 4 | needs UI tickets 29, 32, 35 closed; screenshots from the final build |
| 2026-12-09 | Chapter 5 | needs tickets 33, 34 closed for test numbers and payment figures |
| 2026-12-12 | Full draft v1 to the student | all chapters present, open questions listed |
| 2026-12-16 | v2 after review | review comments closed |
| 2026-12-17 | Freeze | artifacts 1–6 built and checked per the checklist below |
| 2026-12-19 | Submit | — |
| 2026-12-22 | Defense | slide and demo rehearsed twice |

## Demo script

15 minutes, live on the AVD against the local server. Mock gateway is the payment path (ticket 03: VNPay
IPN cannot reach a local server); the VNPay sandbox adapter is shown only if its credentials have arrived.

| Time | Action |
|---|---|
| 0:00 | guest: home, search by keyword without diacritics, filter colour/size/price, product detail with variant stock |
| 3:00 | register and log in, edit profile, add an address and set it default |
| 5:00 | add to cart, change quantity past stock to show the guard, checkout with COD, order appears in history |
| 8:00 | admin: create a product with variants and images, hide it, confirm it disappears from the storefront |
| 10:00 | admin: move an order through valid transitions, show a rejected transition; create an inventory receipt and show stock increase |
| 12:00 | admin: dashboard and the 5 reports with a date range; lock a customer and show the login rejection |
| 14:00 | close with the test summary |

Pre-demo checklist: `docker start stylo-mysql`, API up on 8787, `adb -P 5359 reverse tcp:8787 tcp:8787`,
`npm run db:reset`, `pm clear` the app, `PAYMENT_PROVIDER=mock`, emulator at 100% battery and silent,
video already recorded as backup.

## Writing rules

- Terminology from `GLOSSARY.md`: Vietnamese term at first mention, code name in parentheses.
- Money integer VND with dot separators: `1.250.000 ₫`. Sizes in cm, screens in dp.
- Screenshots cropped to the 360×640 dp content area; captions `Hình <chapter>.<n>`.
- No fabricated numbers. Test counts, table counts and page counts are copied from a real run or a real
  file at freeze time.
- Appendices may repeat; body chapters must not restate each other.

## Risks

- No official format: a template may land late. Reformatting is mechanical; content is not. Write content
  first, restyle once.
- Screenshots and figures depend on build tickets 27, 29, 32, 33, 35. Freeze screenshots only after 33.
- VNPay credentials may never arrive. Then the report describes the adapter as implemented and the demo
  runs mock only — no claim of a live sandbox transaction.
- Timeline is assumed. If the real deadline is earlier than 2026-12-19, cut appendices and chapter 4's
  admin section first, never chapter 5's test evidence.

## Checklist before submit

- [ ] PDF opens, fonts embedded, body page count between 45 and 70
- [ ] ERD A3 legible without zoom
- [ ] `stylo-db.sql` imports into an empty schema and the app runs against it
- [ ] video plays end to end, no personal data or notifications on screen
- [ ] zip excludes `node_modules`, `.gradle`, `build`, `.env`, `.scratch` screenshots (report uses copies)
- [ ] slide runs under 15 minutes when read aloud
- [ ] spelling pass on Vietnamese diacritics
