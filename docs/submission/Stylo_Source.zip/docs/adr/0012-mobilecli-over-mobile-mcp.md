# Manual AVD driving: mobilecli replaces the mobile-mcp server

The manual AVD smoke was driven by `@mobilenext/mobile-mcp@1.0.16`, a project-scoped MCP server in
`.omp/mcp.json`. That surface had costs the project no longer needs: the tools exist only while the
harness mounts the server, every action is a schemaless tool call the agent cannot script, pipe or
compose with `adb`/`curl`, and its device discovery silently returned an empty list when the adb
server did not sit on the default port — the exact failure recorded in ticket 21. Decision: drop the
MCP server and drive the AVD with [`mobilecli`](https://github.com/mobile-next/mobilecli) 1.0.22, the
same vendor's Go CLI, installed globally and invoked from the shell. `mobilecli` keeps a small daemon
that owns the device connection: `dump ui` returns elements with stable `@eN` refs and
`io tap @eN`/`io fill` act on them across separate process invocations, `snapshot` prints the tree as
text, and screenshots, app launch/terminate/clear, logs and webview inspection are subcommands.
On this workstation it measured 0.56 s per call from the global install versus 7–8 s through
`npx`, and `io fill` delivered all 10 characters of a test string into a Compose text field where
`adb shell input text` had truncated input. `adb` remains only for transport-level work: starting the
server on port 5359, `reverse tcp:8787 tcp:8787`, APK install and `getprop`. The daemon holds the
device's single UiAutomation connection on Android — with it running, `adb shell uiautomator dump`
is killed (exit 137) and returns as soon as `mobilecli daemon stop` runs — so every
`uiautomator`-based path is retired from the project's instructions and the daemon is stopped before
instrumentation runs.

## Considered Options

- **Keep mobile-mcp**: zero migration, but keeps a second runtime, no shell composability, and the
  adb-port fragility that already cost a debugging session; the vendor now ships the CLI first.
- **Run mobilecli behind its own `server start` JSON-RPC mode and keep an MCP shim**: restores tool
  calls, but adds a shim the project must own and maintain for a workflow the shell already handles.
- **Pin `npx mobilecli@1.0.22` per call**: no machine-wide install, but 7–8 s per command turns a
  15-command smoke into minutes of waiting and re-resolves the package on every call.
- **Repository wrapper script**: centralises the device id and version, but it is one more file to
  keep in sync with a CLI that already defaults to the single online device and reads
  `MOBILECLI_DEVICE`.
- **Keep `uiautomator dump` as a fallback next to mobilecli**: no dependency on the daemon, but the
  two cannot run at the same time, so the fallback only works after an explicit daemon stop — a trap
  rather than a safety net.

## Consequences

- `.omp/mcp.json` is gone with the server; the `mobile_*` tools disappear from agent sessions after
  a restart, and every instruction points at `mobilecli` instead.
- `docs/mobile-cli.md` replaces `docs/mobile-mcp.md` and carries the install pin, the command set,
  the daemon/UiAutomation conflict and the AVD setup.
- The two adb-smoke skills collapse into one mobilecli skill; the dev-stack restore check uses
  `mobilecli snapshot` instead of `uiautomator dump`.
- The version is pinned by the documented install command, not by a lockfile: bump it deliberately
  and re-run the smoke.
- The Kaspresso suite is unaffected in what it tests, but it runs with the mobilecli daemon stopped.
