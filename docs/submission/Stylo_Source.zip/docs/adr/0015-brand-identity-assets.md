# Brand identity: kit symbol on system surfaces, monochrome marks inside the app

Decision: the logo kit (`stylo_logo_kit/`, curated into [`docs/brand/`](../brand/)) is the source of
truth for the Stylo logo. The launcher icon is the kit's orange tile (`#E04F26`) with the cream/ink
glyph; every in-app mark is a **monochrome** vector tinted by `MaterialTheme.colorScheme.primary`.
The UI palette from [ticket 07](../../.scratch/stylo-app/issues/07-thiet-ke-ui.md) — ink `#1E1C18`,
ivory `#F6F1E8`, terracotta `#A6512B` — is unchanged.

## Considered Options

- **Ship the colour lockup in-app**: visually the "real" logo, but the kit orange `#E04F26` would sit
  next to the app terracotta `#A6512B`, and the header/login would need a brand colour token, which
  breaks the `docs/ui.md` rule that screens take every colour from `StyloTheme`.
- **Recolour the launcher to terracotta `#A6512B`**: one palette everywhere, but the icon no longer
  matches the kit's own PNGs used in the report, and the brand's published colour is the orange.
- **Adopt the kit palette app-wide** (`secondary` `#E04F26`, ink `#141210`, background `#F4EFE6`):
  most coherent with the logo file, but it reopens the ticket-07 decision, invalidates every stored
  screenshot, and drops white-on-orange text contrast to 3.70:1 (terracotta is 5.13:1) — below AA for
  body text.
- **Keep the typographic `Text("STYLO")` wordmark**: no asset import, but the header would mix the
  kit symbol with a system-font wordmark, which is not the brand.

## Consequences

- The kit ships 15 SVGs; the app consumes four generated VectorDrawables (launcher foreground,
  monochrome layer, horizontal lockup, stacked lockup). The design files live in `docs/brand/svg/`
  and are never copied into `res/`.
- The kit has no stacked monochrome lockup, so the stacked mark reuses the kit's stacked geometry
  with every fill set to ink; it is the same artwork, not new artwork.
- Web icons (`favicon*`, `site.webmanifest`, `head-snippet.html`, Apple/192/64 px PNGs) are dropped:
  the repo has no web frontend. Two PNGs (512, 1024) stay for the report and a future store listing.
- The launcher glyph is 58% of the 108dp canvas so it survives the 66dp safe zone and launcher
  masks; `png/android-chrome-512x512.png` is a full-bleed tile and cannot be used as a foreground.
- A future brand change starts from `docs/brand/svg/` and requires regenerating the four drawables
  plus re-checking launcher, header and login on the AVD.
- The kit declares no licence; the assets are coursework-only until ownership is confirmed.
