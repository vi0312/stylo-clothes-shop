# Checkout idempotency with clientOrderId

A mobile checkout can time out after the server committed; the customer taps "Đặt hàng" again and
a naive retry creates a second order, deducts stock twice and opens a second payment attempt.
Decision: every `POST /orders` carries a required client-generated UUID `clientOrderId`; the
`order` table stores it and `UNIQUE (user_id, client_order_id)` makes a retry return the existing
order with HTTP `200` instead of writing anything.

## Considered Options

- **`Idempotency-Key` header backed by a dedicated table**: reusable for any POST, but adds a
  table, a retention policy and a second lookup for the one endpoint that needs it.
- **A unique `order.code` supplied by the client**: the client would have to generate a display
  code whose format the server owns, and a collision becomes a user-visible failure.
- **No idempotency**: a retried checkout duplicates the order and reserves stock twice; the
  project has no automatic refund or stock repair.

## Consequences

- `order.client_order_id` is `NOT NULL`; seed scripts must generate a UUID per order.
- The duplicate path returns `200` (not `201`) and does not re-read the cart, stock or payment
  state; for an online order it returns the current `PENDING` attempt with a rebuilt URL.
- The Android client must keep the UUID for the whole checkout attempt, including retries after a
  transport error, and generate a new one only for a new order.
- The uniqueness scope is the user, not the system: two customers can send the same UUID without
  ever seeing each other's order.
