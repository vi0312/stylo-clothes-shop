# ADR 0016 — Chuẩn hoá UI theo Material 3 sau audit toàn bộ màn hình

- Ngày: 2026-11-08
- Trạng thái: Accepted
- Liên quan: [docs/ui.md](../ui.md), [GLOSSARY.md](../../GLOSSARY.md), ticket 07, 21 màn Compose

## Bối cảnh

Audit 21 màn trên AVD (kèm 12 ảnh chụp + dump `uiautomator`) đối chiếu `docs/ui.md` và Material 3
cho thấy UI đẹp nhưng **thiếu lớp component dùng chung**: cùng một control được dựng lại 3–6 lần
với quy cách khác nhau (4 kiểu chip đang chọn, 3 kiểu badge, skeleton chỉ có ở admin, 5 màn tự thêm
border cho card). Hệ quả là các lỗi a11y và spec lặp lại ở nhiều màn.

Báo cáo đầy đủ: [`.scratch/stylo-app/ui-audit-2026-11-08.md`](../../.scratch/stylo-app/ui-audit-2026-11-08.md).

## Quyết định

### 1. Card phẳng, phân tách bằng bề mặt trắng

`docs/ui.md` §Spacing đã chốt "card không shadow, không viền". Nhưng cặp token cũ cho card
(`surface #FBF8F1`) trên nền (`background #F6F1E8`) chỉ **1.06:1** — card tan vào nền, nên 5 màn
tự thêm `BorderStroke(1.dp, outlineVariant)` và vi phạm spec.

Chốt: **card dùng `surfaceContainerLowest` (#FFFFFF) trên nền `background` (#F6F1E8) = 1.13:1**;
`surface` giữ cho bottom bar/sheet/row. Không đổi `background` vì làm đậm nền sẽ kéo
`surfaceVariant` (#EDE5D8) xuống còn ~1.02:1 với nền, phá luôn chip và search field.

Skeleton dùng `#E8DFD1` (1.32:1 trên card) thay `surfaceVariant` (1.18:1 → không thấy).

Đo lại: chip fill trên card 1.25:1, chữ phụ trên card 5.97:1, `outline` trên card 3.85:1.

### 2. Lớp component `core/ui/components/`

Mọi control lặp được đóng gói một lần: `StyloCard`, `StyloFilterChip`, `StyloSelectableSwatch`,
`StyloQtyStepper`, `StyloStatusBadge`, `StyloListSkeleton`, `StyloStickyCta`, `StyloBusyButton`,
`StyloErrorState`. Screen chỉ còn bố cục + state, không tự set màu/shape của control.

### 3. Navigation admin dùng drawer

Admin có 7 destination; `NavigationBar` M3 chứa tối đa 5. Chốt: bottom bar giữ 4 tab vận hành
(Tổng quan, Đơn hàng, Sản phẩm, Kho), `ModalNavigationDrawer` chứa Danh mục, Người dùng, Báo cáo,
Đăng xuất. Đăng xuất có dialog xác nhận như phía customer; tab switch giữ state
(`saveState`/`restoreState`); `AdminGraph` chỉ mount khi `role == ADMIN`.

### 4. Không thêm `soldCount` vào API

`docs/ui.md` §Chi tiết từng yêu cầu "Đã bán N" nhưng không endpoint nào tổng hợp số bán theo sản
phẩm, và đồ án không cần số liệu đó để demo luồng mua. Chốt: **bỏ "Đã bán N" khỏi spec**, ghi lý
do tại đây. Muốn có lại thì cần aggregate trên `OrderItem` của đơn đã thanh toán.

Ngược lại, delta KPI **được giữ** vì chỉ là phép trừ hai khoảng đã có trong
`GET /admin/dashboard` — không cần bảng mới.

### 5. Variant mặc định có tên trong CTA

Spec cũ bắt khách chọn đủ màu + size rồi mới cho thêm giỏ. Thực tế app auto chọn variant đầu còn
hàng, nên CTA luôn bật dù khách chưa chủ động chọn → rủi ro đặt nhầm size.

Chốt: giữ auto-select, nhưng **CTA phải nêu variant đang mua** ("Thêm S vào giỏ" — chỉ nêu giá
 trị kích cỡ, không thêm chữ "size"); khi khách
đổi size/màu, label đổi theo. Không còn trạng thái "Chọn size" disabled.

### 6. Thuật ngữ UI thuần Việt

Cùng một khái niệm đang hiển thị hai kiểu: "Kích cỡ" (PDP) và "Size S" (giỏ); "Variant tồn thấp"
(dashboard). Chốt: **UI hiển thị tiếng Việt** — `ProductVariant` → "Biến thể", `size` → "Kích cỡ",
`color` → "Màu sắc"; `Variant`/`Size` chỉ tồn tại trong code, API, schema. Danh sách chuẩn ghi ở
`GLOSSARY.md` §Thuật ngữ UI.

Ghi chú: quyết định ghi thành **section riêng** trong GLOSSARY thay vì thêm cột thứ 5 vào bảng
40 dòng — cùng một thẩm quyền, không tạo 40 ô trống.

### 7. Sửa spec chỗ spec sai

- Hồ sơ: `docs/ui.md` đòi "loading/error + retry" nhưng màn đọc từ session cache, không có request
  nào để hiện hai trạng thái đó. Bỏ yêu cầu khỏi spec; giữ "Lưu chỉ bật khi form khác bản gốc".
- Checkout: "tóm tắt đơn" đã có nhưng nằm **sau** ô ghi chú; spec không nói thứ tự nên ghi rõ:
  địa chỉ → sản phẩm → phương thức thanh toán → ghi chú.

### 8. Sửa hai lỗi spec phát hiện khi thi công

- `SearchField` spec là pill 48dp, fill `surfaceVariant`, viền `outline`; code đang là
  `OutlinedTextField` 12dp, nền trong suốt, viền `outlineVariant` (1.24:1).
- `docs/ui.md` cấm gradient trừ placeholder ảnh, nhưng `HeroBanner` đang dùng
  `Brush.linearGradient(primary, secondary)`.

Cả hai sửa theo spec, không sửa spec.

## Hệ quả

- Screen không còn import `FilterChipDefaults`, `BorderStroke` cho card, hay tự vẽ progress trong
  button; mọi thay đổi quy cách control chỉ sửa một file trong `core/ui/components/`.
- Mọi list có skeleton; mọi control có accessible name (kiểm bằng TalkBack trên AVD).
- Nghiệm thu: TalkBack + fontScale 0.85/1.0/1.3/2.0 không cắt số tiền hay nhãn.
