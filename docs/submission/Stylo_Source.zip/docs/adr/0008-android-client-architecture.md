# Android client: sealed results, network-first state and one role-aware NavHost

The client is one Compose app (`android/`, module `:app`, namespace `com.stylo.shop`) for customers and administrators, packaged by feature. Repository calls never throw across their boundary: they return `ApiResult<T>` with a typed `ApiError`. ViewModels expose one immutable `UiState` over `StateFlow` and one-off `UiEffect` values through a `Channel`. The client keeps no local database or offline queue, paginates manually, stores tokens in Preferences DataStore and uses one OkHttp `Authenticator` for single-flight refresh. Navigation is one type-safe `NavHost` with nested `auth`, `customer` and `admin` graphs whose start destination follows the session.

## Considered Options

- **Kotlin `Result` and thrown exceptions**: `Result` carries only a `Throwable`, so the UI would map transport exceptions and server messages instead of stable API error codes. Rejected.
- **Paging 3**: the catalog is small, and `page/limit` with append avoids a second state machine and its testing surface.
- **Room cache and offline queue**: offline browsing is out of scope; a cache adds invalidation and reconciliation work with no demo requirement.
- **EncryptedSharedPreferences**: `androidx.security.crypto` is deprecated and adds keystore failure modes for a local demo; the app sandbox is the boundary.
- **Multiple activities or a role-agnostic graph**: two roles would share back-stack edge cases; separate nested graphs make the role boundary explicit.

## Consequences

- Every screen follows the same pattern: call repository, fold `ApiResult` into `UiState`, send navigation or messages as effects. This is repetitive but predictable and unit-testable.
- The server's English `message` is never displayed. `ApiError.code` maps to a Vietnamese string in one table, with a generic fallback for unknown codes.
- An empty list is `Content(emptyList())`; screens render the empty view themselves. There is no fourth UI state.
- Refresh is correct under concurrency: an expired access token triggers one refresh, concurrent requests wait, the rotated refresh token is persisted atomically, and the original request is retried once. A failed refresh clears the session and navigates to login.
- Launch calls `GET /me` before the first screen, so role and `DISABLED` state are decided by the server, not by a cached claim.
- `DISABLED` takes effect on the next request because the server checks the user row; the client treats `ACCOUNT_DISABLED` as session termination.
- Payment opens outside the app in a Custom Tab. There is no deep link; the order is refreshed when the app returns to the foreground.
- Offline use shows an explicit network error. That is accepted for the demo.
- Cleartext HTTP is allowed only in the debug build through a network security config, because the demo reaches the API at `127.0.0.1` through `adb reverse`.
