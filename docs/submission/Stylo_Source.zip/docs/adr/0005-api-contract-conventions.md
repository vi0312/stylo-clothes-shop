# API conventions: bare resources, stable error codes, offset pagination

The Express API and the Compose client are written in parallel without shared types, so the wire
contract is the only interface between them. Decision: `/api/v1`, camelCase JSON, the resource
itself on success (`{ items, page, limit, total }` for paginated lists), one error envelope
`{ error: { code, message, details? } }` with stable `SCREAMING_SNAKE_CASE` codes mapped to HTTP
statuses, English developer messages (the client renders Vietnamese from the code), ISO-8601 UTC
timestamps, `Asia/Ho_Chi_Minh` calendar-day filters, and `page`/`limit` pagination capped at 100.
Request bodies are strict; unknown query parameters are ignored.

## Considered Options

- **A `{ data, error }` envelope for successes**: uniform unwrapping, but every DTO gains a level
  and the Android serializers need a generic wrapper for no capability.
- **Cursor pagination**: stable under inserts and better for feeds, but admin tables need a total
  count and the catalogue is a few hundred rows, so an offset `COUNT(*)` is cheap.
- **Vietnamese messages from the server**: one less mapping, but it couples backend copy to UI copy
  and makes wording part of the contract.
- **Snake_case JSON**: matches the database, but fights Kotlin property names and Prisma output.

## Consequences

- `message` is never parsed; adding or renaming a code is a breaking contract change and lands in
  `docs/api.md`.
- Every list endpoint pays a `COUNT(*)`; accepted at this scale.
- Query dates are Vietnamese calendar days. The service converts them to UTC boundaries, and
  report SQL shifts UTC timestamps by +7 hours because rows are stored in UTC.
- Android owns the error-code → Vietnamese string table; a missing code must fall back to a generic
  message rather than crash.
