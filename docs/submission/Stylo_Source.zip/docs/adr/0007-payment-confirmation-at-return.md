# Payment result is confirmed at return and IPN through one idempotent service

The demo server runs locally without a public HTTPS endpoint, while VNPay's protocol expects a
server-to-server IPN for the authoritative result. Decision: one confirm service handles the
VNPay return URL, the VNPay IPN and the mock provider's completion. Each entry point verifies the
signature (and amount) before mutating, sets `Payment.status = SUCCEEDED` and `paid_at` exactly
once, and moves a `PENDING` order to `CONFIRMED`. The return URL renders a Vietnamese HTML page;
the IPN returns VNPay's `{ RspCode, Message }` JSON. The mock page exists only when
`PAYMENT_PROVIDER=MOCK` and the attempt's `provider` is `MOCK`.

## Considered Options

- **IPN only**: correct in production, impossible without a public tunnel in the local demo, so a
  sandbox payment would never settle the order.
- **Return only**: misses retried IPNs, breaks the gateway's reconciliation contract, and still
  needs the signature check because a customer can open the return URL directly.
- **Separate implementations per entry point**: three chances to disagree about amount checks,
  `paid_at` and order transitions.

## Consequences

- A return without an IPN still settles the order; a later IPN is idempotent and only acknowledges.
- A `SUCCEEDED` attempt is terminal. A `FAILED` attempt may still become `SUCCEEDED` from a genuine
  gateway callback, because the money moved.
- A genuine success after the order was cancelled still records `paid_at` on the cancelled order;
  with no refund flow, the admin resolves it by hand.
- The mock routes must return `404` under `PAYMENT_PROVIDER=VNPAY`, and every browser-facing URL
  must use `PUBLIC_BASE_URL` (LAN IP), never `localhost`, or the emulator cannot reach it.
