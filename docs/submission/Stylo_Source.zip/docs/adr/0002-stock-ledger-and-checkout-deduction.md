# Stock: a `stock` column plus an append-only `StockMovement` ledger, deducted at checkout

Reading current stock is required to block overselling, replaying history is required to reconcile receipts against orders, and two concurrent checkouts must not sell the same last unit. Decision: `ProductVariant.stock` is the read and guard value; every change writes an append-only `StockMovement` in the **same** transaction; stock is deducted when the order is created, for COD and online alike (a failed online attempt keeps the reservation for the retry); overselling is prevented by `SELECT ... FOR UPDATE` on the variant rows **ordered by ascending `id`** inside the checkout transaction; stock is restored only when an order reaches `CANCELLED`.

## Considered Options

- **Derive stock from the ledger** (`SUM(delta)`): no single row to lock, every read aggregates the whole movement table, and `FOR UPDATE` on a fact row cannot guard availability.
- **Optimistic `version` column with retry**: correct under high contention, but adds a retry loop and conflict handling for a single-node, single-user-traffic project.
- **Deduct on payment success**: does not hold inventory while the customer pays, so payment can succeed with nothing left to ship.
- **Column only, no ledger**: reconciling receipts against stock then depends entirely on trusting the column.

## Consequences

- `stock` can drift if someone `UPDATE`s it by hand; `docs/erd.md` carries a reconciliation query usable in seed and tests.
- An abandoned online order holds stock until the admin cancels it; there is no expiry sweeper (known limitation, out of scope).
- `StockMovement.ref_id` has no FK because it is polymorphic (`RECEIPT` / `ORDER`); the invariant lives in the service and in `ref_type`.
