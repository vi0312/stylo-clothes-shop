# Money is an integer VND amount in an `INT` column

The project uses VND only, with no fractional part, and every money calculation happens on the server. Decision: every money column is `INT` (ceiling 2,147,483,647 per value), mapping straight to Prisma `Int` and a JS `number`; no `DECIMAL`, no `BIGINT`; an order snapshots `subtotal`, `shipping_fee` and `total` instead of recomputing them on read.

## Considered Options

- **`BIGINT`**: a ceiling far beyond what is needed, in exchange for Prisma returning `BigInt` and every JSON boundary requiring a conversion, plus Android having to parse strings instead of numbers.
- **`DECIMAL(12,0)`**: literally "money", but Prisma returns a `Decimal` object, every sum goes through a library and every JSON response carries a string.
- **Store minor units (xu)**: VND payments have no fractional unit in practice, so this only adds a multiplication everywhere.

## Consequences

- Zod must validate the ceiling on every money input; exceeding it is `VALIDATION_FAILED`, never an overflow.
- Raising the ceiling later means migrating the columns and the client, which is why this is recorded.
- `vnp_Amount` sent to the gateway is `total * 100`; that multiplication exists in exactly one place.
