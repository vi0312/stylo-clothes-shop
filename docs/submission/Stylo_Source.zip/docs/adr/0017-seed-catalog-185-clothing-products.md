# Seed catalog is 185 clothing products from the same snapshot pipeline

Decision: expand the committed seed snapshot to 185 clothing products and remove footwear. The 100-product snapshot from ADR 0014 mixed 85 clothing products with 15 shoes; this revision drops the shoes and adds exactly 100 more clothing products from the same Fashion Product Images subset and generator. Categories are `Áo` (95), `Quần` (60) and `Áo khoác` (30). `Giày` leaves the seed categories, generator mappings and filter contract. Everything else from ADR 0014 still holds: committed snapshot, offline seed, deterministic demo values, Myntra image licence caveat.

## Considered Options

- **Keep 15 shoes and add 100 clothing (200 total)**: smallest change, but keeps a category, shoe size tables and filter surface the demo no longer needs.
- **Remove shoes and add 115 clothing (200 total)**: round total, but changes the requested +100 scope.
- **Remove shoes and add 100 clothing (185 total)**: chosen; matches "clothing only" and "+100 products".

## Consequences

- Snapshot: 185 products, 546 variants, 185 images (600x800 JPEG q82, about 6.9 MB). 162 `ACTIVE`, 23 `INACTIVE`, 151 sellable; prices 150,000-1,290,000 VND.
- `Giày` is gone from seed categories, catalog filters and the generator (article mappings, shoe sizes, descriptions, GI prefix). The seed creates 4 categories: 3 active plus inactive `Phụ kiện`.
- Orders, receipts and stock reconciliation are unchanged: still 140 deterministic orders and 3 receipts; final stock equals each variant's `targetStock`.
- Regenerating rewrites SKU allocation and product order, so an existing dev database needs `npm run db:reset`. The seed stays idempotent for a fixed snapshot.
- The generator writes `catalog.json` with LF on every OS, so a regeneration no longer produces a line-ending-only diff.
- Images grow from about 3.6 MB to 6.9 MB. The ADR 0014 licence caveat still applies.
- The pinned `Áo thun basic` keeps `STY-AO-001-*` and the seed still creates it last.
