# Android E2E: Kaspresso on the AVD for implemented customer flows

ADR-0010 stopped Android testing at the JVM and verified the UI by hand on the AVD. That trade-off
no longer holds: the manual smoke is agent-driven, leaves no regression signal, and every Android
ticket changes the auth, catalog or profile/address screens. Decision: add one Kaspresso 1.6.1
instrumentation suite under `android/app/src/androidTest`, running against the real Express server on
`127.0.0.1:8787` through `adb reverse` on the existing `stylo_api35` AVD. The first suite follows a
fresh customer through register → home → search/filter/sort → product detail → profile → address
create/edit/default → logout/login; cart, checkout and orders join when tickets 22, 25 and 27 land.
Selectors use Compose semantics and stable `Modifier.testTag` values, each run registers a new
customer instead of resetting the database, and the suite is a milestone and pre-demo gate, plus
the check for an Android ticket that touches a covered flow, rather than an every-ticket gate.
`Kaspresso.Builder.withComposeSupport()` keeps it to JUnit/Gradle reports and logcat—no
screenshot-on-failure, no Allure. This supersedes the UI-test clause of ADR-0010; the backend, JVM,
seed and no-CI decisions stand.

## Considered Options

- **Keep the manual AVD smoke**: no new dependency, but the same flow is re-driven by an agent every
  time, defects surface only when someone looks, and the evidence is screenshots rather than a
  pass/fail signal.
- **Compose test rule without Kaspresso**: fewer libraries, but loses Kaspresso's flaky-safety
  retries, step logging, device helpers and the Kakao Compose screen DSL that make a long journey
  readable.
- **Maestro or mobile-mcp for the scripted flow**: device-level and language-agnostic, but adds a
  second runtime, cannot call test code, and mobile-mcp is already the manual tool.
- **Wait for cart, checkout and orders (tickets 22-27)**: would test the intended golden path in one
  pass, but leaves the toolchain unvalidated and the three shipped UI areas without regression cover
  for the rest of the build.
- **Reset the demo database before each run**: deterministic catalog and empty carts, but destroys
  runtime data and still needs a server restart; a uniquely named customer gives the same isolation
  for the v1 flow with no reset.
- **Screenshot-on-failure and Allure**: better failure evidence for the report, but Kaspresso 1.6.1
  writes screenshots to public Documents, which API 35 scoped storage blocks, and its optional adb
  desktop server would need its own port next to the 5359 workaround. Revisit if failures become
  hard to diagnose.
- **Gradle Managed Devices**: reproducible and CI-ready, but downloads another system image and
  duplicates the AVD already used for manual checks; there is no CI to justify it.
- **Run on every Android ticket**: catches regressions earlier, but instrumentation takes minutes and
  carries flake risk; this ADR accepts it only at milestones and before demos.

## Consequences

- `:app` gains an `androidTest` source set, an `AndroidJUnitRunner`, Kaspresso,
  `kaspresso-compose-support`, Compose `ui-test-junit4` and a `UiTags` object; no production
  behaviour changes.
- Gradle and the emulator must use adb port 5359 on this workstation (`ANDROID_ADB_SERVER_PORT`);
  each run needs the server up and `adb reverse tcp:8787 tcp:8787`.
- Tests read the seeded catalog because the app under test is the demo app. Backend and JVM tests
  still never read seed data; test customers are registered per run, so the seeded customers from
  ticket 33 are not a test dependency.
- Only implemented flows are covered. Each UI ticket after 22 extends the suite; admin flows join
  when tickets 29, 30, 32 and 35 land.
- The suite does not replace JVM ViewModel/mapper tests and does not gate every ticket.
