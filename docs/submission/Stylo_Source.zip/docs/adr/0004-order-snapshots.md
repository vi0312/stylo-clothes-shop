# Orders snapshot product data, cost and delivery address

Product names, prices, size/colour and the delivery address can all be edited or deleted after an order is placed, while the order must still read back exactly as purchased for reports and reconciliation. Decision: `OrderItem` copies `product_name`, `variant_sku`, `size`, `color`, `unit_price`, `unit_cost`; `Order` copies `recipient_name`, `recipient_phone`, `shipping_address`; the `product_id` / `variant_id` FKs stay for reporting, but nothing joins back to read a current price or name; `Order` has no FK to `Address`.

## Considered Options

- **Join back to `product` / `address`**: old orders change when prices change (wrong reports), and deleting an address breaks its orders.
- **One JSON snapshot column per order line**: adds a layer that cannot be filtered, sorted or aggregated by variant.

## Consequences

- Renaming a product does not rewrite history; deleting an address does not affect placed orders.
- `unit_cost` can be null (a variant never received into stock), so the gross-profit report must handle null rather than treat it as 0.
- `OrderItem.product_id` / `variant_id` are `ON DELETE RESTRICT`, so a sold product cannot be deleted. That is the intent: hide it with `INACTIVE`.
