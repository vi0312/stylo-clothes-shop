# Testing: invariant-level integration, pure-function units, manual UI smoke

> Superseded in part by [ADR-0011](0011-android-e2e-kaspresso.md) for the UI-test clause. The
> backend, JVM, seed and no-CI decisions stand.

Stylo is built by one person in 6–8 weeks, with no CI. The risky areas are money, stock and order
state, not HTTP plumbing. Decision: backend integration tests run the real Express app against a
real MySQL `stylo_test` schema for eight invariant groups (auth and users, profile and addresses,
cart, catalog and admin products, checkout and transitions, payments, inventory receipts,
reports); Vitest unit tests cover only pure functions (totals, state machine, stock guards,
VNPay signature, date buckets, code formats); Android tests stop at JVM ViewModel, mapper and
decoder tests; UI behaviour is verified manually on the AVD with screenshots. Tests use factories,
never the demo seed. No coverage percentage, no Compose UI tests, no MockWebServer, no CI.
Details: [`docs/testing.md`](../testing.md). Ticket:
[09](../../.scratch/stylo-app/issues/09-chien-luoc-kiem-thu.md).

## Considered Options

- **Full route matrix**: every endpoint × happy path, validation, auth and error. It produces
  hundreds of near-identical cases and steady maintenance while the route layer is a thin Zod
  shell.
- **Service tests with mocked Prisma**: fast, but they assert query shapes rather than database
  behaviour and duplicate what integration already proves. Transactions, locks and constraints
  cannot be verified through a mock.
- **Testcontainers per run**: stronger isolation, but adds a dependency, 10–20 s startup and
  Docker Desktop quirks on this machine. One dedicated schema plus truncation is enough for a
  solo project.
- **Transaction rollback per test**: fast, but Supertest requests use pooled connections, so the
  test transaction is not the request transaction. The workarounds are fragile.
- **Compose UI tests or Maestro**: catches rendering regressions, but instrumentation on the AVD is
  slow and flaky, and the same flows are exercised by the demo script anyway.
- **A numeric coverage gate**: easy to satisfy with shallow assertions and does not map to the
  invariants that matter.

## Consequences

- `npm test` requires the MySQL container and the `stylo_test` schema; `npm run test:unit` stays
  usable without Docker.
- Integration files run sequentially and truncate all tables before each file. Tests must create
  their own data and must not depend on order or on the seed.
- The suite targets under 60 seconds. If it grows past that, split files but keep the invariant
  groups.
- The eight groups are a maintained checklist: a new money, stock or state rule must land with a
  case in the owning group. The matrix in `docs/testing.md` maps the eleven required functions to
  their levels.
- `TokenAuthenticator` single-flight refresh and Compose rendering have no automated test. The
  manual script covers them, and the gap is recorded instead of being hidden behind a flaky test.
- The VNPay adapter is not exercised over the network. The mock gateway is the automated and demo
  path; a real sandbox payment is optional manual evidence.
- Ticket 10 adds the weighted-average cost unit test and the inventory-cost report assertions;
  the response shape does not change.
- Tests, factories and helpers live under `tests/`, outside `src/`; no test helper is imported by
  production code.
