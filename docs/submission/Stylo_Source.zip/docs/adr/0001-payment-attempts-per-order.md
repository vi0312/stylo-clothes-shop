# Payments: one Payment row per attempt, method split from provider

VNPay can fail and the customer can retry, IPN can be retried, and COD produces no gateway transaction at all. Folding all three into `PaymentProvider = cod | vnpay | mock` (the first glossary draft) cannot express "the customer chose online payment while the demo runs mock", and cannot tell whether an order is paid when the latest attempt failed. Decision: `Order.payment_method` (`COD` | `ONLINE`) is the customer's choice; `Payment` records **one payment attempt** with `provider` (`MOCK` | `VNPAY`), `status` (`PENDING` | `SUCCEEDED` | `FAILED`) and a unique `txn_ref` sent to the gateway; "paid" is read only from `Order.paid_at`, set exactly once (online when the gateway confirms, COD when the order reaches `DELIVERED`); the order-level `payment_status` (`UNPAID` | `PAID` | `FAILED`) is derived and never stored.

## Considered Options

- **One `Payment` row per order, mutated in place** (the original glossary definition): simpler, but a retry overwrites the previous transaction reference, losing the reconciliation trail, and a late IPN can overwrite a newer result.
- **`paid BOOLEAN` on `Order`**: loses the payment timestamp, which revenue reports group by.
- **Provider as the payment method**: `PAYMENT_PROVIDER=mock` would look like something the customer chose, and the customer's "online" intent would not be recorded.

## Consequences

- Return/IPN look a `Payment` up by `txn_ref`, so repeated delivery is idempotent: an already `SUCCEEDED` attempt only gets an ack, the order is untouched.
- Cancelling an order with `paid_at` set is rejected, because the project scope has no refund flow; the admin UI must show the error instead of silently taking money and cancelling.
- Revenue reports filter `order.paid_at IS NOT NULL` and do not depend on order status.
- A failed `ONLINE` attempt does **not** cancel the order: stock stays reserved for the retry, and an abandoned order is cancelled by the admin by hand.
