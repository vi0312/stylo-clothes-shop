# Android E2E: per-ticket Kaspresso files with a mobilecli authoring loop

ADR-0011 made Kaspresso a milestone and pre-demo gate, with a manual AVD smoke after every Android
ticket; ADR-0012 kept mobilecli as the manual driver. That split left each ticket's regression signal
to a human, and the two tools had no shared vocabulary: Compose `testTag` values were invisible to
uiautomator, so mobilecli could only match visible copy. Decision: every Android ticket that changes
a covered customer flow adds or updates a Kaspresso journey under `android/app/src/androidTest` and
runs that class through `android/e2e.cmd -Class <name>`; the full suite runs at milestones and
before a demo. `Modifier.semantics { testTagsAsResourceId = true }` on the app root exposes every
`UiTags` value as a resource id, so mobilecli's `dump ui` and the Kaspresso selectors name the same
nodes; every node a journey addresses carries a tag, and text is used only where the copy is the
specification (plus snackbar actions, whose host cannot take a tag). mobilecli is the authoring and
triage tool: explore a new screen, read its tags from `dump ui`, then write the test; after a failure,
rerun with `-LeaveApks`, replay the flow, and screenshot into `.scratch/stylo-app/assets/<ticket>/`.
The daemon owns the device's `UiAutomation` connection, so it is stopped before Gradle (`e2e.cmd`
does that) and is never invoked from inside a test. ONLINE checkout is covered deterministically:
Espresso-Intents stubs the `ACTION_VIEW` hand-off, the test completes
`/payments/mock/:txnRef/complete`, and the order detail must show PAID; driving the real Chrome
Custom Tab stays in the manual smoke. This supersedes the gate and artifact clauses of ADR-0011 and
extends ADR-0012's tool boundary; the Kaspresso adoption, real-server/data decisions and no-CI
decision stand.

## Considered Options

- **Keep the milestone gate**: fewer minutes per ticket, but the regression net still depends on
  someone running the suite, and a broken covered flow ships silently.
- **Run the full suite on every ticket**: maximum signal, but every ticket pays the install plus all
  journeys and inherits their combined flake; a targeted class keeps the feedback tight.
- **Match by visible text in mobilecli instead of exposing tags**: no production semantics change,
  but copy edits silently break the exploration and triage path, and the two tools drift.
- **Drive Chrome with UiAutomator in Kaspresso**: exercises the real hand-off, but Chrome's UI,
  first-run prompts and locale make it the flakiest test in the repo; the stub covers the app's
  responsibility (issue the URL, handle the return) while the browser stays manual.
- **Kaspresso screenshot-on-failure**: no extra tooling, but API 35 scoped storage blocks the
  public-Documents write in Kaspresso 1.6.1, so leave-apks plus mobilecli replay is the workable
  artifact path.

## Consequences

- `UiTags` is now an accessibility-visible contract; renaming a tag changes what mobilecli and any
  other uiautomator client sees. Dialogs compose in their own window and would lose the root flag,
  so their content root takes `Modifier.e2eTagsAsResourceId()`; snackbar actions remain text-only
  because the Material host cannot take a tag.
- The suite gains `OrdersJourneyTest` and `OnlinePaymentJourneyTest`; admin journeys join with
  tickets 29, 30, 32 and 35.
