# Seed catalog is a committed snapshot of a public real-product dataset

Decision: the development seed catalog is a committed snapshot of 100 real products taken from the public Fashion Product Images dataset (Kaggle `paramaggarwal`, read through the Hugging Face mirror `mecha2019/fashion-product-images-small`), normalized to the Stylo category and brand model and translated into Vietnamese by a one-off generator. `prisma/seed.ts` reads `seed-assets/catalog/catalog.json` and the committed 600x800 JPEG images; it never calls the network. Prices, sizes, stock, orders, receipts and payments are deterministic demo values because the dataset contains no commerce fields.

> Amended by [ADR 0017](0017-seed-catalog-185-clothing-products.md) (2026-11-09): the snapshot grew to 185 clothing products and dropped footwear. The source, licence and offline-seed decisions below still apply.

## Considered Options

- **Scrape Vietnamese fashion sites**: authentic local names and prices, but the probed sites are SPA/Cloudflare protected or expose no stable JSON endpoint, the terms of service are unclear, and the result would break whenever a site changes.
- **Generate everything with a free AI API**: clean license and natural Vietnamese, but it is not a real source and adds a key, quota and non-deterministic output to a seed that tests call directly.
- **Fetch the dataset while seeding**: always current, but every `db:reset` and every integration test would depend on the network and produce different rows.
- **Keep the six flat-colour placeholders**: zero license risk, but the catalog no longer demonstrates real names, colours and photographs.

## Consequences

- The mirror declares no license and its images originate from Myntra. The snapshot is coursework/demo data only; a public release must replace the images with licensed or owned photos and keep the JSON shape.
- The repository grows by about 3.6 MB of images. The snapshot and the generator script are committed so a fresh clone can seed offline and the normalization is reproducible.
- The generator owns translation and selection: `server/scripts/build-catalog-seed.py` fetches a fixed sample, maps `articleType`/`baseColour`/`gender`/`usage`, assigns one of four house brands, and writes stable SKUs. Running it again rewrites the JSON and images; the database must then be reset.
- `Áo thun basic` (`STY-AO-001-*`) stays pinned with fixed variants and stock because the catalog integration test and five Kaspresso journeys search for it. The seed creates it last so the newest-first public list still exposes it first.
- Orders, receipts and stock movements are derived deterministically from the snapshot; the stock ledger remains the source of truth and reconciles to zero mismatches after seeding.
