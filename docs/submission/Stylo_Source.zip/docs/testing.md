# Testing and demo data

How Stylo is verified. Decision records: [ADR-0010](adr/0010-testing-strategy.md),
[ADR-0011](adr/0011-android-e2e-kaspresso.md) and
[ADR-0013](adr/0013-android-e2e-workflow.md). Tickets:
[09](../.scratch/stylo-app/issues/09-chien-luoc-kiem-thu.md),
[36](../.scratch/stylo-app/issues/36-kaspresso-e2e.md),
[41](../.scratch/stylo-app/issues/41-android-e2e-workflow.md). Contract: [api.md](api.md).
Schema: [erd.md](erd.md). Layout: [architecture.md](architecture.md).

There is no CI and no coverage percentage. The test matrix below is the checklist that closes a
build ticket.

---

## Principles

1. Test invariants where a bug costs money or corrupts stock, not every route.
2. Backend integration tests use the real MySQL schema and the real Express stack. Prisma is
   never mocked.
3. Pure logic is unit tested; wiring is exercised end to end.
4. Android logic stops at the JVM; implemented UI flows are exercised by the Kaspresso suite on
   the AVD, one journey file that grows with the flow it covers. Visual design is still checked with
   screenshots.
5. Backend and JVM tests never read seed data; factories are for tests. The Android E2E suite runs
   against the seeded catalog because it drives the app exactly as the demo does.
6. A bug fix starts with a regression test that fails before the fix.

## Levels

| Level | Tool | Scope | Target runtime |
|---|---|---|---|
| Backend unit | Vitest 5.1, no database | Pure functions: money, order state, dates, VNPay signature | < 5 s |
| Backend integration | Vitest 5.1 + Supertest 7.3 + MySQL 8.4 | HTTP routes, services, transactions, SQL, ledger | < 60 s |
| Android JVM | JUnit4, `kotlinx-coroutines-test`, Turbine | ViewModel state/effects, mappers, DTO decoding, error messages | < 30 s |
| Android E2E | Kaspresso 1.6.1 + Compose support, real server | Register/login, catalog, profile, addresses, cart, COD checkout, ONLINE payment return, orders list/detail/cancel on `stylo_api35`; admin journeys as tickets 29, 30, 32 and 35 land | < 5 min |
| Manual AVD | App on `stylo_api35` (Android 15, 360×640dp) | Visual design, animations, checkout browser hand-off, flows not yet in the E2E suite | per ticket |

Kaspresso and its Compose support are the only added test dependencies. Standalone Compose UI
tests, MockWebServer, MockK and screenshot testing remain deliberately absent.

---

## Backend

### Commands and layout

```bash
cd server
npm run test:unit          # no Docker
npm run test:integration   # MySQL with the stylo_test schema
npm test                   # unit, then integration; the gate
npm run typecheck
```

```text
server/
├── vitest.unit.config.ts
├── vitest.integration.config.ts
├── tests/
│   ├── unit/                 mirrors src/ pure modules
│   ├── integration/          one file per invariant group
│   ├── factories/            user, address, product, variant, order, payment, receipt
│   └── helpers/              app request, auth, resetDb, time
└── src/
```

`src/app.ts` is imported by Supertest; tests never call `listen()` and never use the network.
`vitest.integration.config.ts` sets `fileParallelism: false`, a global setup and a 30 s timeout.

### Test database isolation

- `server/.env.test` holds `NODE_ENV=test` and a `DATABASE_URL` whose path is `/stylo_test`.
  `PAYMENT_PROVIDER=MOCK`, `UPLOAD_DIR` points at a temporary directory, and the JWT secrets are
  test-only values.
- The integration global setup aborts unless the database name is exactly `stylo_test`, then runs
  `prisma migrate deploy` once with that URL. No test ever touches the development schema.
- `resetDb()` runs before each integration file: `SET FOREIGN_KEY_CHECKS = 0`, truncate every
  base table returned by `information_schema` for the current schema, then re-enable checks. No
  transaction rollback: Supertest requests use pooled connections.
- Files run sequentially. Tests inside a file run sequentially. Each test creates its own rows
  through factories with unique emails, SKUs and codes; no fixed IDs and no execution-order
  dependency.
- The MySQL container must expose a `stylo_test` schema. Create it once with the `docker exec`
  command in [architecture.md](architecture.md#mysql); tests never create or drop the schema.
- Never sleep in a test. Unit tests use `vi.setSystemTime`. Integration tests update
  `created_at`, `expires_at` and `paid_at` directly to simulate expiry and report windows.
- Upload fixtures are tiny valid JPEG/PNG/WebP files plus a text file with an image extension.
  The temporary upload directory is removed after the run.

### Integration groups

One or more files per group. Each case asserts status, error code and persisted state. A group
may split into two files when it grows, but the invariant stays one group.

**I1. Auth, session and users** (`auth.test.ts`)

- Register: normalized email, `201`, password hash never returned; duplicate email `409
  EMAIL_TAKEN`.
- Login: wrong email and wrong password both return `401 INVALID_CREDENTIALS`; a `DISABLED`
  account returns `403 ACCOUNT_DISABLED` on login and on the next authenticated request.
- Refresh rotates: the old token is `401 INVALID_TOKEN` after use; logout revokes; `/me` returns
  the current user.
- Admin route with a customer token is `403 FORBIDDEN`; missing token is `401 UNAUTHORIZED`.
- Admin users: search by email/name/phone, status filter, disable revokes refresh tokens,
  self-disable is `409 CANNOT_DISABLE_SELF`.

**I2. Profile and addresses** (`profile.test.ts`)

- `PATCH /me` updates the allowed fields only; `GET /me` reflects them.
- The first address is default; `isDefault: true` clears the previous default in one transaction;
  `isDefault: false` is `400 VALIDATION_FAILED`.
- Deleting the default promotes the oldest remaining address.
- Another customer's address id is `404 NOT_FOUND` for read, update and delete.

**I3. Cart** (`cart.test.ts`)

- Add sums quantities; patch and delete return the whole cart; clear returns the empty shape.
- Adding beyond stock is `409 OUT_OF_STOCK` with `details[].sku`, never a silent clamp.
- An inactive product's line stays visible with `available: false` and is excluded from
  `subtotal`; checkout rejects it with `409 ITEM_UNAVAILABLE`.
- Another customer's cart item id is `404 NOT_FOUND`.

**I4. Catalog, admin products and uploads** (`catalog.test.ts`, `admin-catalog.test.ts`,
`admin-images.test.ts`)

- Storefront search: accent-insensitive `q` over product, brand and category names; category,
  brand, color, size and price range; a product matches when one variant satisfies every
  variant-level filter and has stock; pagination and the allowed sorts; products without a
  sellable variant are absent.
- Product detail returns `minPrice`/`maxPrice` over in-stock variants (`null` when none), keeps
  zero-stock variants in `variants`, returns `404 NOT_FOUND` for an inactive product on the
  storefront, and keeps `position` order for images.
- Admin product CRUD: duplicate `sku` is `409 SKU_TAKEN`, duplicate `(size, color)` is `409
  VARIANT_EXISTS`, and `stock` in a variant body is `400 VALIDATION_FAILED`.
- Products and variants referenced by orders, receipts or movements cannot be deleted (`409
  IN_USE`).
- Uploads: the sixth image is `400 VALIDATION_FAILED`, over 5 MB is `413 FILE_TOO_LARGE`, bytes
  that are not JPEG/PNG/WebP are rejected even with an image `Content-Type`, and deleting an
  image frees its position.

**I5. Checkout and order transitions** (`orders.test.ts`)

- Checkout reads the cart and recomputes. Client-sent `items`, price or total fields are `400
  VALIDATION_FAILED`.
- Success writes order item snapshots (name, SKU, size, color, unit price, unit cost), the
  address snapshot, `SALE` movements, decremented stock and a cleared cart in one transaction.
- Repeating the same `clientOrderId` for the same user returns `200` with the same order and no
  second stock deduction; the same UUID for another user is a separate order.
- Empty cart `409 CART_EMPTY`; insufficient stock `409 OUT_OF_STOCK` with no partial writes.
- Two concurrent checkouts for the last unit produce one `201` and one `409 OUT_OF_STOCK`, with
  stock 0 and exactly one `SALE` movement.
- Cancel restores stock and appends `CANCEL_RESTOCK`; cancel is rejected when `paid_at` is set or
  the order is `SHIPPING`.
- The transition matrix is exercised in both directions: every valid admin transition, every
  invalid one (`409 INVALID_ORDER_STATE` with `details.current` and `details.target`), COD paid
  at delivery, and `DELIVERED`/`CANCELLED` terminal.

**I6. Payments, mock gateway and VNPay callbacks** (`payments.test.ts`,
`payments-vnpay.test.ts`)

- An `ONLINE` checkout creates one `PENDING` attempt with `amount = order.total`; `COD` creates
  none.
- Mock return, IPN and complete are one confirm service: the first call sets `SUCCEEDED` and
  `paid_at`; repeated calls acknowledge without changing either. Concurrent repeats change state
  once.
- Amount mismatch marks the attempt `FAILED` with `AMOUNT_MISMATCH` and leaves the order unpaid.
- A `PENDING` attempt older than 15 minutes becomes `FAILED` with `EXPIRED` and a new attempt is
  created; a double tap within the window returns the same attempt.
- `FAILED` then a successful retry: latest attempt `SUCCEEDED`, order paid once.
- Invalid signature on return changes nothing; every failure keeps the order retryable.
- VNPay return and IPN (`payments-vnpay.test.ts`): a signed callback settles the attempt and
  moves `PENDING → CONFIRMED`, a replay is acknowledged without rewriting `paid_at`, a bad
  signature changes nothing, amount mismatch and a declined response code fail the attempt, and
  a VNPay callback never settles a `MOCK` attempt.

**I7. Inventory receipts** (`inventory.test.ts`)

- Creating a receipt inserts header and items, increments stock and appends `RECEIPT` movements
  with the receipt as `ref` in one transaction; `totalCost` sums lines.
- The same variant may appear on two lines at different costs; `stock` reflects both.
- List and detail match the contract; `PATCH` and `DELETE` do not exist (`404`).
- After checkout, cancel and receipt cases, the ledger reconciliation query in `erd.md` returns
  no rows.

**I8. Reports** (`reports.test.ts`)

- Revenue groups by `paid_at`, includes every period in the range with zeroes, and handles both
  `day` and `month`; unpaid and cancelled-unpaid orders are excluded, COD delivered is included.
- Day boundaries are `Asia/Ho_Chi_Minh`, not UTC.
- Top products sort by quantity then revenue, use the item snapshot price, and clamp `limit`.
- Orders by status count orders created in the range, with all five statuses present.
- Low stock filters `ACTIVE` products and respects the threshold.
- Inventory cost and gross profit use the `unit_cost` snapshot defined in [erd.md](erd.md);
  [ticket 10](../.scratch/stylo-app/issues/10-cong-thuc-gia-von.md) supplies the report SQL, null
  policy and assertions. The response shape is fixed.

Cross-cutting cases run inside the owning file: the error envelope shape, `VALIDATION_FAILED`
details, `404` instead of `403` for another customer's resources, pagination bounds, invalid
sort fields and unknown body fields.

### Unit scope

Vitest against exported pure functions, no database and no mocked Prisma:

- Order totals: line total, subtotal, flat shipping fee, total.
- Order state machine: valid transitions, actor permission, cancel guard on `paid_at`.
- Stock guards: requested quantity against available stock.
- VNPay: checksum/signature, amount conversion, response-code mapping.
- Date ranges: inclusive day boundaries in `Asia/Ho_Chi_Minh`, month buckets, zero fill.
- Code formats: order code and `txnRef` shape, SKU and receipt code validation.
- Weighted-average unit cost from receipt lines ([erd.md](erd.md)).

No service test with a mocked Prisma client: it duplicates integration coverage and hard-codes
query shapes.

### Deliberately not tested

- Every route × every validation and role combination. Zod schemas and the shared middleware
  cover that mechanically; representative cases are in the integration groups.
- The real VNPay sandbox over the network. If credentials arrive, one manual sandbox payment is
  evidence; the mock remains the demo path.
- Logging, static file caching and process shutdown.
- MySQL deadlock behaviour beyond the two concurrency cases above.

---

## Android

### Commands and layout

```bash
cd android
./gradlew :app:testDebugUnitTest
./gradlew assembleDebug
./gradlew :app:connectedDebugAndroidTest   # Kaspresso E2E, needs the AVD and server
```

JVM tests live in `app/src/test/java/com/stylo/shop/`, mirroring the feature packages. Handwritten
fakes live in `.../testing/fakes/`. E2E tests live in
`app/src/androidTest/java/com/stylo/shop/e2e/`, with one screen object per screen. The
`androidTest` source set and its `AndroidJUnitRunner` exist only for the Kaspresso suite.

### Scope

- ViewModels, for every screen that has one: auth, catalog, product detail, cart, checkout,
  orders, order detail, profile, addresses, and the admin products, orders, users, inventory and
  reports screens. Assert `UiState` transitions, one-off effects, retry and empty collections.
- DTO decoding with fixtures copied from `api.md`: every success payload and the error envelope,
  unknown JSON keys ignored, unknown enum values mapped to a safe fallback.
- Mappers and formatters: VND grouping, UTC to `Asia/Ho_Chi_Minh`, phone/address display.
- `ErrorMessages`: every server code to its Vietnamese string; `VALIDATION_FAILED` details to
  field errors; unknown code to the generic message.
- `SessionManager` against a fake `TokenStore`: login, restore, refresh persistence, logout.
- Repositories are not tested against HTTP. Their mapping logic is covered through decoders and
  ViewModel fakes.

Deliberately absent: standalone Compose UI tests, screenshot tests, MockWebServer and MockK.

Known gap: `TokenAuthenticator` single-flight refresh is not unit tested because it needs a real
HTTP client. It is verified manually by shortening `ACCESS_TOKEN_TTL_SECONDS` and exercising two
concurrent screens on the AVD, then checking the server log for one refresh call.

### UI E2E (Kaspresso)

One instrumentation suite covers the implemented customer flows end to end on `stylo_api35`,
against the real Express server and MySQL. It is the regression gate for the flows a ticket has
already shipped, not a screen-by-screen rendering test.

**Scope.** One file per journey. `CustomerJourneyTest`: register a new customer → home → search,
filter and sort → product detail → profile → create, edit and set a default address → logout → log
in again. `GuestBrowseJourneyTest`: guest Home without a session → each guarded tab (Orders, Profile,
Cart) opens Login → signing in returns to the tab that asked for it → back from a pushed screen keeps
its root tab selected. `CheckoutJourneyTest`: add a product → cart → checkout → add the address from
the empty state → COD order → order detail. `OrdersJourneyTest`: place a COD order → orders list →
detail → cancel → CANCELLED filter. `OnlinePaymentJourneyTest`: ONLINE order → stubbed browser
hand-off → the mock gateway call the page would post → order detail shows PAID. Admin journeys join
with tickets 29, 30, 32 and 35. Visual design, animations and the real Chrome Custom Tab stay in the
manual smoke.

**Data.** Each run registers its own customer with a unique email and adds its own address. The
guest journey is the exception: it signs in as seeded `customer01@stylo.local` and only reads, which
is what proves the guarded-tab return for an account the test did not create. The suite does not
reset the database and otherwise does not depend on the seeded customers from ticket 33; it does
read the seeded catalog, because the catalog the demo uses is the one under test. Test users and
orders accumulate until the next `db:reset`; reset before a demo, not before every run. The checkout
journeys consume one unit of the first in-stock "Áo thun basic" variant per run; the pinned product
keeps S/M/L at 12/13/3, so reset before a long series rather than after it runs dry.

**Isolation.** Journeys run in one instrumentation process that shares the app's process, so
`pm clear` would kill the runner. Instead every journey opens with a step that logs the app out
through the UI when a session is left over, which keeps the journeys order-independent.

**Selectors.** One vocabulary for both tools: `UiTags` values are applied with `Modifier.testTag`
and exposed to uiautomator by `Modifier.semantics { testTagsAsResourceId = true }` on the app root,
so `mobilecli dump ui` (field `identifier`) and the Compose test rules address the same names. A
dialog, popup or modal sheet hosts its own window, so its content root takes
`Modifier.e2eTagsAsResourceId()`. Every node a journey addresses carries a tag; text is asserted
where the copy is the specification, and snackbar actions are matched by text because the Material
host cannot take a tag. Lists reuse one tag per row; the journey scrolls to or matches the row by
its visible text.

**Artifacts.** `Kaspresso.Builder.withComposeSupport()`: JUnit/Gradle reports and logcat.
Screenshot-on-failure and Allure are not enabled: Kaspresso 1.6.1 writes screenshots to public
Documents, which API 35 scoped storage blocks. Failures are triaged from the Gradle report and
logcat; `-LeaveApks` keeps the app installed after the run so mobilecli can replay the flow and save
a screenshot.

**Run.** One entrypoint, `android/e2e.cmd`: checks the adb server on 5359, a single device,
`GET /health` on the API and the reverse tunnel, stops the mobilecli daemon (it owns UiAutomation),
then calls Gradle. It never starts the server or the AVD.

```bat
android\e2e.cmd                              rem full suite
android\e2e.cmd -Class OrdersJourneyTest     rem one journey (short or full class name)
android\e2e.cmd -LeaveApks                   rem keep APKs for mobilecli triage
```

Prerequisites: MySQL and the server on `127.0.0.1:8787`; the AVD booted with
`ANDROID_ADB_SERVER_PORT=5359`. On this workstation Windows reserves 4942–5041, so the default 5037
is unusable. Under the hood the script runs the verified variant:

```bash
ANDROID_ADB_SERVER_PORT=5359 cmd.exe /c "gradlew.bat :app:connectedDebugAndroidTest --no-daemon"
```

Each journey logs out through the UI when a session survives from a previous run, and creates its
own user, so it needs neither `pm clear` nor a seeded account.

**Gate.** An Android ticket that changes a covered flow adds or updates its journey and runs that
class before the ticket closes. The full suite is green before an API milestone and before a demo.
Manual smoke is no longer the gate for covered flows.

### Manual AVD smoke

Run after an Android ticket that changes a screen, for what the suite does not assert: visual
design, animations, the real Chrome Custom Tab hand-off, and flows without a journey. Save
screenshots under `.scratch/stylo-app/assets/<ticket>/` and link them from the ticket. The agent
drives the AVD with mobilecli: `dump ui` shows the same `UiTags` the test uses, then replay the flow
and screenshot it. Stop the daemon before any instrumentation (`e2e.cmd` does it) and never call
mobilecli from inside a test. Setup, the command set and the daemon/UiAutomation conflict are in
[`docs/mobile-cli.md`](mobile-cli.md).

Customer script: relaunch and stay logged in, open a product and pick a variant, change cart
quantity, checkout ONLINE through the real mock page in Chrome and confirm the app shows PAID after
returning, then walk every screen for visual regressions.

Admin script: create a product with two variants and an image, create a receipt for both
variants, confirm and ship an order, mark it delivered, disable a customer, open every report.

---

## Seed and demo data

Seed is deterministic and idempotent. `npm run db:reset` drops the schema, applies migrations and
runs it; the demo always starts from the same state. Only the catalog integration test calls `seed()`
(the other backend tests build their own rows), and the Android E2E suite reads the seeded catalog
because it drives the same catalog the demo does. The full seed described below is
implemented in `server/prisma/seed.ts` (ticket 33, catalog refreshed in ticket 44); it is idempotent,
so `npm run db:seed` after a reset does not duplicate rows.

| Entity | Count | Required edge cases |
|---|---|---|
| Users | 1 admin + 12 customers | admin from env; one customer with no cart or orders; one disabled |
| Categories | 4 | at least one with no active product |
| Brands | 4 | |
| Products | 185 | clothing only; 23 `INACTIVE`; 11 with every variant out of stock; 24 low stock; real names and photos from the committed catalog snapshot |
| Variants | 546 | 151 products sellable; every product has 2-4 variants; prices span 150,000-1,290,000 VND |
| Addresses | 2 per active customer | one default each |
| Orders | 140 | all five statuses; COD and ONLINE; paid, unpaid and failed payment states; dates spread over the last 90 days |
| Payments | per online order | at least one `FAILED` retry that later succeeds, one `PENDING` |
| Inventory receipts | 3 | different unit costs for the same variant to make the weighted average non-trivial |
| Stock movements | every stock change | reconciliation query returns no rows after reset |

Rules:

- Stable names, emails, SKUs and codes. No randomness that changes between resets.
- Orders are dated relative to reset time (today, yesterday, then across 90 days) so revenue by
  day and month is non-empty and the zero-fill periods are visible.
- Seeded accounts are documented in the report and in `server/README.md`: admin from
  `SEED_ADMIN_*`, customers `customer01@stylo.local` to `customer12@stylo.local` with the
  development-only password `Customer@12345`.
- Images are committed under `server/seed-assets/catalog/images/`, one 600x800 JPEG per product,
  about 3.5 MB total. Source and licence are recorded in `server/seed-assets/README.md` and
  ADR-0014. Seed never downloads at runtime, so the demo works offline.
- One customer owns a `DELIVERED` COD order and a paid ONLINE order so the report has data
  without a live checkout.

---

## Gates and cadence

| When | Required evidence |
|---|---|
| Backend ticket | `npm run typecheck`, `npm test`, and a curl/HTTP smoke of the new endpoint; result summary in the ticket |
| Android ticket | `./gradlew :app:testDebugUnitTest`, `assembleDebug`, then `android\e2e.cmd -Class <Name>`: a ticket that touches a covered flow adds or updates that journey and runs it; otherwise install on the AVD and smoke the changed screen. Screenshot in the ticket |
| API milestone | Full integration suite green, Kaspresso E2E green for implemented flows, app served locally, manual customer script end to end |
| Admin milestone | Admin script on the AVD against the seeded database |
| Pre-demo | `npm run db:reset`, Kaspresso E2E green, full customer and admin scripts, payment mock, report screens |

- No coverage percentage gate. The matrix is the checklist; a row marked done means its cases
  exist and pass, or the ticket states why a level is skipped.
- No CI pipeline. Commands run locally and the output is pasted into the ticket.
- A bug found after a ticket closes gets its regression test before the fix.

---

## Test matrix

`I` is the integration group above, `U` the unit area, `J` the Android JVM area, `K` the Kaspresso
E2E suite and `M` manual AVD. Every row also inherits I1 (auth) and the error-envelope cases where
relevant.

| Function | Backend integration | Backend unit | Android JVM | E2E | AVD | Critical assertions |
|---|---|---|---|---|---|---|
| Registration and login | I1 | — | AuthViewModel, SessionManager, decoders | K | M | Token rotation, disabled account, role guard |
| Profile and addresses | I2 | — | Profile/Address ViewModels, formatters | K | M | Ownership, exactly one default |
| Cart | I3 | Totals | CartViewModel, decoders | K | M | Stock limit, inactive line, ownership |
| Product management | I4 | Code formats | Admin product ViewModel, upload state | — | M | SKU uniqueness, image rules, delete blocked |
| Order management | I5 | State machine, stock guard | Orders/AdminOrders ViewModels | K | M | Snapshot, transitions, restock |
| User management | I1 | — | Admin users ViewModel | — | M | Disable revokes refresh, self-disable blocked |
| Product search | I4 | — | CatalogViewModel, filter state | K | M | Accent-insensitive filters, pagination |
| Product detail | I4 | — | DetailViewModel, decoders | K | M | Price range, inactive `404`, image order |
| Payment | I6 | VNPay signature, amount | Checkout/Payment ViewModels | K | M | Replay idempotency, amount mismatch, expiry |
| Reports | I8 | Date ranges, buckets | ReportsViewModel, chart mapping | — | M | `paid_at` basis, zero fill, boundaries |
| Inventory receipts | I7 | Cost per [erd.md](erd.md) | Receipt ViewModel | — | M | Stock + ledger + total cost in one transaction |

`K` marks the v1 journey. A dash in that column means the flow is not in the suite yet: the customer
journeys cover cart, checkout, ONLINE payment return and orders since ticket 41; admin flows join
with tickets 29, 30, 32 and 35.

Targets: about 60–80 integration cases, 25–40 unit cases and 30–50 Android JVM cases, plus one E2E
journey per implemented customer area. If a group grows past roughly 15 cases, split the file, not
the invariant.

## Open dependencies

- [Ticket 10](../.scratch/stylo-app/issues/10-cong-thuc-gia-von.md) supplies the weighted-average
  cost rule, then adds the cost unit test and the inventory-cost integration assertions.
- [Ticket 07](../.scratch/stylo-app/issues/07-thiet-ke-ui.md) may add ViewModel tests per screen;
  it does not change the decision to keep standalone Compose UI tests out; E2E is ADR-0011.
- [Ticket 41](../.scratch/stylo-app/issues/41-android-e2e-workflow.md) added the orders and ONLINE
  payment journeys plus the `e2e.cmd` runner; [ticket 33](../.scratch/stylo-app/issues/33-seed-e2e.md)
  fills the demo seed and E2E v1 registers its own customer, so it does not wait for it.
- A VNPay sandbox credential adds one manual payment as evidence, never an automated network
  test.
