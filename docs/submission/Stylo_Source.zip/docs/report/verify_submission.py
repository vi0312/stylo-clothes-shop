"""Check the submission artefacts against the plan's pre-submit checklist.

Everything here reads the files in docs/submission, not the sources, so a stale export fails the
check instead of passing silently.

Usage: python verify_submission.py
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path

import pymupdf
from pptx import Presentation

REPO = Path(__file__).resolve().parents[2]
OUT = REPO / "docs" / "submission"
FAILURES: list[str] = []


def check(name: str, condition: bool, detail: str) -> None:
    print(f"{'PASS' if condition else 'FAIL'}  {name}: {detail}")
    if not condition:
        FAILURES.append(name)


def report() -> None:
    pdf = OUT / "BaoCao_Stylo.pdf"
    document = pymupdf.open(pdf)
    pages = len(document)
    text_pages = [page.get_text() for page in document]

    # The contents pages repeat every heading, so both anchors must be searched after page 3 and in order.
    body_start = next((i for i, text in enumerate(text_pages) if i >= 3 and "1. GIỚI THIỆU" in text), None)
    references = next(
        (i for i, text in enumerate(text_pages) if body_start is not None and i > body_start
         and "TÀI LIỆU THAM KHẢO" in text),
        None,
    )
    body_pages = (references - body_start) if body_start is not None and references is not None else 0
    check("report body pages 45-70", 45 <= body_pages <= 70, f"{body_pages} body pages, {pages} total")
    docx_size = (OUT / "BaoCao_Stylo.docx").stat().st_size
    check("docx source shipped", docx_size > 1_000_000, f"{docx_size // 1024} KiB")

    fonts = set()
    for page in document:
        for font in page.get_fonts():
            fonts.add((font[3], font[2]))
    embedded = [name for name, kind in fonts if "TrueType" in kind or "Type0" in kind]
    check("report fonts embedded", bool(embedded), f"{len(fonts)} font faces, subset prefixes present")

    check("report has contents with page numbers", "." in text_pages[1] and any(
        part.strip().isdigit() for part in text_pages[1].split()[-5:]
    ), "contents page carries page numbers")

    body = " ".join(text_pages)
    figures = {
        chapter: len(re.findall(rf"Hình {chapter}\.\d+\.", body))
        for chapter in range(1, 7)
    }
    check("report figures present", sum(figures.values()) == 26 and all(figures[c] for c in (3, 4, 5)),
          f"{sum(figures.values())} figure captions by chapter {figures}")
    tables = len(re.findall(r"Bảng [A-C0-9]\.\d+\.", body))
    check("report tables present", tables == 40, f"{tables} table captions incl. appendices")


def erd() -> None:
    document = pymupdf.open(OUT / "ERD_Stylo_A3.pdf")
    page = document[0]
    width_mm = page.rect.width * 25.4 / 72
    height_mm = page.rect.height * 25.4 / 72
    sizes = sorted({round(span["size"], 1) for block in page.get_text("dict")["blocks"]
                    for line in block.get("lines", []) for span in line["spans"]})
    check("ERD is one A3 page", len(document) == 1 and width_mm > 400 and height_mm > 290,
          f"{len(document)} page, {width_mm:.0f}x{height_mm:.0f} mm")
    check("ERD text legible at A3", sizes and min(sizes) >= 6.5, f"font sizes {sizes}")


def slides() -> None:
    deck = Presentation(OUT / "Slide_BaoVe.pptx")
    words = 0
    for slide in deck.slides:
        for shape in slide.shapes:
            if shape.has_text_frame:
                words += len(shape.text_frame.text.split())
            if shape.has_table:
                for row in shape.table.rows:
                    for cell in row.cells:
                        words += len(cell.text.split())
    minutes = words / 130
    check("slides fit 15 minutes", minutes < 15, f"{len(deck.slides)} slides, {words} words ≈ {minutes:.1f} min")
    check("slides pdf exists", (OUT / "Slide_BaoVe.pdf").exists(), "Slide_BaoVe.pdf")


def source_zip() -> None:
    archive = zipfile.ZipFile(OUT / "Stylo_Source.zip")
    names = archive.namelist()
    bad = [name for name in names if "node_modules" in name or "/build/" in name
           or name.endswith("/.env") or name == "server/.env" or "/.gradle/" in name
           or name.startswith(".scratch/")]
    check("zip excludes build output and secrets", not bad, f"{len(names)} entries, {len(bad)} forbidden")
    check("zip carries both builds", any(n.startswith("android/") for n in names)
          and any(n.startswith("server/") for n in names), "android/ and server/ present")


def video() -> None:
    path = OUT / "Demo_Stylo.mp4"
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=width,height",
         "-of", "json", str(path)],
        capture_output=True, text=True, check=True,
    )
    data = json.loads(probe.stdout)
    duration = float(data["format"]["duration"]) / 60
    stream = data["streams"][0]
    check("video length 5-10 minutes", 5 <= duration <= 10, f"{duration:.1f} minutes")
    check("video is a full device frame", stream["width"] == 1080 and stream["height"] == 1792,
          f"{stream['width']}x{stream['height']}")
    decode = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(path), "-f", "null", "-"],
        capture_output=True, text=True,
    )
    check("video decodes end to end", not decode.stderr.strip(), decode.stderr.strip()[:200] or "no decode errors")


def database() -> None:
    dump = OUT / "stylo-db.sql"
    text = dump.read_text(encoding="utf-8", errors="replace")
    check("dump is a full database dump", "CREATE DATABASE" in text and text.count("INSERT INTO") >= 10,
          f"{dump.stat().st_size} bytes, {text.count('INSERT INTO')} INSERT statements")
    check("dump uses LF endings", "\r\n" not in text, "no CRLF")


def main() -> None:
    report()
    erd()
    slides()
    source_zip()
    video()
    database()
    if FAILURES:
        print(f"\n{len(FAILURES)} failing checks: {FAILURES}")
        sys.exit(1)
    print("\nall checks passed")


if __name__ == "__main__":
    main()
