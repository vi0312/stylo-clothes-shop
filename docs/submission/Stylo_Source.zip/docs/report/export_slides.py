"""Export the deck to PDF through PowerPoint and report the text volume per slide.

The fifteen-minute budget is checked from the word count rather than guessed: a slide a minute is
the planning rule, and reading speed in Vietnamese is roughly 130 words per minute.

Usage: python export_slides.py [input.pptx] [output.pdf]
"""

from __future__ import annotations

import sys
from pathlib import Path

import win32com.client as win32
from pptx import Presentation

REPO = Path(__file__).resolve().parents[2]
DEFAULT = REPO / "docs" / "submission" / "Slide_BaoVe.pptx"


def words(pptx: Path) -> list[int]:
    deck = Presentation(pptx)
    counts = []
    for slide in deck.slides:
        total = 0
        for shape in slide.shapes:
            if shape.has_text_frame:
                total += len(shape.text_frame.text.split())
            if shape.has_table:
                for row in shape.table.rows:
                    for cell in row.cells:
                        total += len(cell.text.split())
        counts.append(total)
    return counts


def main() -> None:
    pptx = (Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT).resolve()
    pdf = (Path(sys.argv[2]) if len(sys.argv) > 2 else pptx.with_suffix(".pdf")).resolve()

    counts = words(pptx)
    print(f"slides: {len(counts)}, words: {sum(counts)}")
    print("per slide:", counts)
    print(f"at 130 words/min: {sum(counts) / 130:.1f} minutes of speech")

    powerpoint = win32.gencache.EnsureDispatch("PowerPoint.Application")
    presentation = powerpoint.Presentations.Open(str(pptx), WithWindow=False)
    try:
        presentation.SaveAs(str(pdf), 32)  # ppSaveAsPDF
    finally:
        presentation.Close()
        powerpoint.Quit()
    print(f"wrote {pdf} ({pdf.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
