"""Build the report, measure its pagination, then rebuild with real contents-page numbers.

Two passes are enough because the contents page keeps the same number of lines in both passes, so
adding the numbers cannot shift the body. The printed page numbers restart at 1 on chapter 1; the
contents page lists those printed numbers, not the physical PDF pages.

Usage: python make_pdf.py [--check]
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

import pymupdf

REPO = Path(__file__).resolve().parents[2]
REPORT = REPO / "docs" / "report"
DOCX = REPO / "docs" / "submission" / "BaoCao_Stylo.docx"
PDF = REPO / "docs" / "submission" / "BaoCao_Stylo.pdf"
PAGES = REPORT / "toc-pages.json"


def run(script: str, *args: str) -> None:
    subprocess.run([sys.executable, str(REPORT / script), *args], check=True, cwd=REPO)


def export() -> None:
    run("export_pdf.py", str(DOCX), str(PDF))


def find_pages(pdf: Path, headings: list[tuple[str, str]]) -> tuple[dict[str, int], int]:
    document = pymupdf.open(pdf)
    located: dict[str, int] = {}
    cursor = 0
    for heading, snippet in headings:
        found = None
        for needle in (snippet, heading):
            if not needle:
                continue
            for index in range(cursor, len(document)):
                if document[index].search_for(needle, quads=False):
                    found = index + 1
                    break
            if found:
                break
        if found:
            located[heading] = found
            cursor = found - 1
    first_body = located.get(headings[0][0]) if headings else None
    return located, first_body or 1


def headings_from_sources() -> list[tuple[str, str]]:
    """Return each heading with a snippet of the paragraph that follows it.

    The heading text alone also appears on the contents page, so the page search uses the snippet
    to find where the chapter actually starts. Directives (@figure, @table) and table rows are
    skipped: only real prose is a safe anchor.
    """
    headings: list[tuple[str, str]] = []
    for path in sorted((REPORT / "content").glob("*.md")):
        if path.name.startswith("00-"):
            continue
        lines = path.read_text(encoding="utf-8").splitlines()
        for index, line in enumerate(lines):
            for marker in ("### ", "## ", "# "):
                if line.startswith(marker):
                    title = line[len(marker):].strip()
                    snippet = ""
                    for candidate in lines[index + 1:]:
                        text = candidate.strip()
                        if not text or text.startswith(("@", "|", "#", "-", ">")):
                            continue
                        snippet = text[:70]
                        break
                    headings.append((title, snippet))
                    break
    return headings


def printed_pages(pdf: Path) -> tuple[dict[str, int], int, int]:
    headings = headings_from_sources()
    located, first_body = find_pages(pdf, headings)
    document = pymupdf.open(pdf)
    references = located.get("TÀI LIỆU THAM KHẢO", len(document) + 1)
    printed = {text: page - first_body + 1 for text, page in located.items()}
    return printed, first_body, references


def main() -> None:
    if "--check" in sys.argv:
        printed, first_body, references = printed_pages(PDF)
        print(f"first body page in PDF: {first_body}, references start: {references}")
        print(f"body pages: {references - first_body}")
        return

    run("build_report.py")
    export()
    printed, first_body, references = printed_pages(PDF)
    if not printed:
        raise SystemExit("no headings found in the exported PDF")

    PAGES.write_text(json.dumps(printed, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    run("build_report.py")
    export()

    printed_after, first_body_after, references_after = printed_pages(PDF)
    body_pages = references_after - first_body_after
    print(f"body pages: {body_pages} (first body page {first_body_after}, references {references_after})")
    drift = {k: (printed[k], printed_after[k]) for k in printed if printed.get(k) != printed_after.get(k)}
    if drift:
        PAGES.write_text(
            json.dumps(printed_after, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        run("build_report.py")
        export()
        print("contents page re-synced after drift")
    else:
        print("contents page numbers stable")


if __name__ == "__main__":
    main()
