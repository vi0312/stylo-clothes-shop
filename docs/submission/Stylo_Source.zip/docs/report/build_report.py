"""Build BaoCao_Stylo.docx from the chapter sources in docs/report/content.

A deliberately small Markdown subset: headings, paragraphs, bullets, pipe tables, and the
directives below. Everything the report needs (numbering, captions, margins, TOC) is applied here
so the sources stay readable prose instead of XML.

Directives
    # 3. Thiết kế cơ sở dữ liệu     chapter heading, starts a new page, sets the caption prefix
    ## 3.1 Quy ước dữ liệu           section
    ### 3.1.1 Kiểu và ràng buộc      subsection
    @figure <path>|<caption>         centred figure with "Hình <ch>.<n>. <caption>"
    @table <caption>                 must sit on the line before a pipe table
    @toc                             table of contents field
    @pagebreak                       hard page break

Usage: python build_report.py [-o output.docx]
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Emu, Pt, RGBColor

REPO = Path(__file__).resolve().parents[2]
REPORT = REPO / "docs" / "report"
CONTENT = REPORT / "content"
ASSETS = REPORT / "assets"
OUT = REPO / "docs" / "submission" / "BaoCao_Stylo.docx"

BODY_FONT = "Times New Roman"
BODY_SIZE = Pt(13)
TEXT_WIDTH_CM = 16.0  # A4 21cm - 3cm left - 2cm right

COVER_LINES = [
    ("TRƯỜNG ....................................................", 14, True),
    ("KHOA ......................................................", 14, True),
    ("NGÀNH ....................................................", 14, True),
    ("", 13, False),
    ("", 13, False),
    ("BÁO CÁO ĐỒ ÁN", 20, True),
    ("ỨNG DỤNG BÁN QUẦN ÁO", 22, True),
    ("", 13, False),
    ("", 13, False),
    ("MÔN HỌC: ..................................................", 14, False),
    ("Giảng viên hướng dẫn: ....................................", 14, False),
    ("Sinh viên thực hiện: ......................................", 14, False),
    ("MSSV: ....................  Lớp: .........................", 14, False),
    ("", 13, False),
    ("Năm học 2026", 14, True),
]


def set_font(run, size: Pt | None = None, bold: bool = False, italic: bool = False) -> None:
    run.font.name = BODY_FONT
    run.font.size = size or BODY_SIZE
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = RGBColor(0, 0, 0)
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(attr), BODY_FONT)


def add_field(paragraph, instruction: str, placeholder: str = "") -> None:
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = instruction
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = placeholder
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.append(begin)
    run._r.append(instr)
    run._r.append(separate)
    run._r.append(text)
    run._r.append(end)
    set_font(run, Pt(12))


def shade(cell, hex_fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    tc_pr.append(shd)


def inline(paragraph, text: str, size: Pt | None = None, bold: bool = False) -> None:
    """Apply **bold**, *italic* and `code` inside one paragraph."""
    tokens = re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)", text)
    for token in tokens:
        if not token:
            continue
        if token.startswith("**") and token.endswith("**"):
            run = paragraph.add_run(token[2:-2])
            set_font(run, size, bold=True)
        elif token.startswith("`") and token.endswith("`"):
            run = paragraph.add_run(token[1:-1])
            set_font(run, size or Pt(12), bold=bold)
            run.font.name = "Consolas"
        elif token.startswith("*") and token.endswith("*"):
            run = paragraph.add_run(token[1:-1])
            set_font(run, size, italic=True, bold=bold)
        else:
            run = paragraph.add_run(token)
            set_font(run, size, bold=bold)


def scan_headings(paths: list[Path]) -> list[tuple[int, str]]:
    """Collect the heading tree in document order, so the contents page can be written as real
    paragraphs with dot leaders instead of a field Word would have to update."""
    headings: list[tuple[int, str]] = []
    for path in paths:
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.startswith("### "):
                headings.append((3, line[4:].strip()))
            elif line.startswith("## "):
                headings.append((2, line[3:].strip()))
            elif line.startswith("# "):
                headings.append((1, line[2:].strip()))
    return headings


def load_pages(path: Path) -> dict[str, int]:
    if not path.exists():
        return {}
    return {key: int(value) for key, value in json.loads(path.read_text(encoding="utf-8")).items()}


class Report:
    def __init__(self, headings: list[tuple[int, str]] | None = None, pages: dict[str, int] | None = None) -> None:
        self.headings = headings or []
        self.pages = pages or {}
        self.doc = Document()
        self.chapter = "0"
        self.figure_no = 0
        self.table_no = 0
        self._setup_styles()
        self._setup_sections()

    # -- setup -------------------------------------------------------------------------------
    def _setup_styles(self) -> None:
        styles = self.doc.styles
        normal = styles["Normal"]
        normal.font.name = BODY_FONT
        normal.font.size = BODY_SIZE
        normal.element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
        pf = normal.paragraph_format
        pf.line_spacing = 1.5
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)
        pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        pf.first_line_indent = Cm(1.0)

        for name, size, italic, before, after in (
            ("Heading 1", 16, False, 0, 18),
            ("Heading 2", 14, False, 12, 6),
            ("Heading 3", 13, True, 10, 4),
        ):
            style = styles[name]
            style.font.name = BODY_FONT
            style.font.size = Pt(size)
            style.font.bold = True
            style.font.italic = italic
            style.font.color.rgb = RGBColor(0, 0, 0)
            style.paragraph_format.space_before = Pt(before)
            style.paragraph_format.space_after = Pt(after)
            style.paragraph_format.line_spacing = 1.5
            style.paragraph_format.keep_with_next = True
            rpr = style.element.get_or_add_rPr()
            rfonts = rpr.find(qn("w:rFonts"))
            if rfonts is None:
                rfonts = OxmlElement("w:rFonts")
                rpr.append(rfonts)
            for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
                rfonts.set(qn(attr), BODY_FONT)

        styles["Heading 1"].paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        styles["Heading 1"].paragraph_format.first_line_indent = Cm(0)
        for name in ("Heading 2", "Heading 3"):
            styles[name].paragraph_format.first_line_indent = Cm(0)

        for name in ("List Bullet", "List Number"):
            style = styles[name]
            style.font.name = BODY_FONT
            style.font.size = BODY_SIZE
            style.paragraph_format.line_spacing = 1.5
            style.paragraph_format.space_after = Pt(0)

    def _setup_sections(self) -> None:
        section = self.doc.sections[0]
        section.page_width = Cm(21)
        section.page_height = Cm(29.7)
        section.top_margin = Cm(3)
        section.bottom_margin = Cm(2)
        section.left_margin = Cm(3)
        section.right_margin = Cm(2)
        section.header_distance = Cm(1.2)
        section.footer_distance = Cm(1.0)
        self.first_section = section

    def new_section(self, page_numbers: bool) -> None:
        section = self.doc.add_section(WD_SECTION.NEW_PAGE)
        section.page_width = Cm(21)
        section.page_height = Cm(29.7)
        section.top_margin = Cm(3)
        section.bottom_margin = Cm(2)
        section.left_margin = Cm(3)
        section.right_margin = Cm(2)
        section.header_distance = Cm(1.2)
        section.footer_distance = Cm(1.0)
        section.footer.is_linked_to_previous = False
        paragraph = section.footer.paragraphs[0]
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.paragraph_format.first_line_indent = Cm(0)
        if page_numbers:
            add_field(paragraph, "PAGE", "1")
            section.start_page_number = 1
        self.doc.sections[0].footer.is_linked_to_previous = False

    # -- blocks ------------------------------------------------------------------------------
    def cover(self) -> None:
        for _ in range(3):
            self.doc.add_paragraph()
        for text, size, bold in COVER_LINES:
            paragraph = self.doc.add_paragraph()
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            paragraph.paragraph_format.first_line_indent = Cm(0)
            paragraph.paragraph_format.space_after = Pt(6)
            if text:
                run = paragraph.add_run(text)
                set_font(run, Pt(size), bold=bold)

    def toc(self) -> None:
        heading = self.doc.add_paragraph()
        heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
        heading.paragraph_format.first_line_indent = Cm(0)
        heading.paragraph_format.space_after = Pt(18)
        run = heading.add_run("MỤC LỤC")
        set_font(run, Pt(16), bold=True)
        for level, text in self.headings:
            paragraph = self.doc.add_paragraph()
            paragraph.paragraph_format.first_line_indent = Cm(0)
            paragraph.paragraph_format.left_indent = Cm(0.8 * (level - 1))
            paragraph.paragraph_format.line_spacing = 1.3
            paragraph.paragraph_format.tab_stops.add_tab_stop(
                Cm(TEXT_WIDTH_CM - 0.8 * (level - 1)), WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS
            )
            page = self.pages.get(text)
            run = paragraph.add_run(text + "\t" + (str(page) if page else ""))
            set_font(run, Pt(12), bold=(level == 1))

    def h1(self, text: str) -> None:
        paragraph = self.doc.add_paragraph(style="Heading 1")
        match = re.match(r"^(?:Chương\s+|Phụ lục\s+)?([0-9]+|[A-Z])[.)]?\s", text)
        self.chapter = match.group(1) if match else self.chapter
        self.figure_no = 0
        self.table_no = 0
        run = paragraph.add_run(text)
        set_font(run, Pt(16), bold=True)

    def h2(self, text: str) -> None:
        paragraph = self.doc.add_paragraph(style="Heading 2")
        run = paragraph.add_run(text)
        set_font(run, Pt(14), bold=True)

    def h3(self, text: str) -> None:
        paragraph = self.doc.add_paragraph(style="Heading 3")
        run = paragraph.add_run(text)
        set_font(run, Pt(13), bold=True, italic=True)

    def para(self, text: str) -> None:
        paragraph = self.doc.add_paragraph()
        inline(paragraph, text)

    def bullet(self, text: str) -> None:
        paragraph = self.doc.add_paragraph(style="List Bullet")
        paragraph.paragraph_format.first_line_indent = Cm(0)
        paragraph.paragraph_format.left_indent = Cm(1.0)
        inline(paragraph, text)

    def quote(self, text: str) -> None:
        paragraph = self.doc.add_paragraph()
        paragraph.paragraph_format.left_indent = Cm(1.0)
        paragraph.paragraph_format.first_line_indent = Cm(0)
        paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        inline(paragraph, text)

    def figure(self, path: Path, caption: str, max_height_cm: float = 15.0) -> None:
        if not path.exists():
            if os.environ.get("REPORT_ALLOW_MISSING"):
                print(f"warning: missing figure {path}")
                return
            raise FileNotFoundError(f"missing figure: {path}")
        self.figure_no += 1
        paragraph = self.doc.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.paragraph_format.first_line_indent = Cm(0)
        paragraph.paragraph_format.space_before = Pt(6)
        paragraph.paragraph_format.space_after = Pt(2)
        paragraph.paragraph_format.keep_with_next = True
        run = paragraph.add_run()
        width = Cm(TEXT_WIDTH_CM * 0.82)
        run.add_picture(str(path), width=width)
        # Keep tall phone screenshots inside the text block.
        shape = run._r[0]
        inline_extent = shape.find(".//" + qn("wp:extent"))
        cx = int(inline_extent.get("cx"))
        cy = int(inline_extent.get("cy"))
        max_cy = Emu(int(Cm(max_height_cm)))
        if cy > max_cy:
            ratio = max_cy / cy
            inline_extent.set("cx", str(int(cx * ratio)))
            inline_extent.set("cy", str(int(cy * ratio)))
        self.caption(f"Hình {self.chapter}.{self.figure_no}. {caption}")

    def caption(self, text: str) -> None:
        paragraph = self.doc.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.paragraph_format.first_line_indent = Cm(0)
        paragraph.paragraph_format.space_before = Pt(2)
        paragraph.paragraph_format.space_after = Pt(10)
        inline(paragraph, text, size=Pt(12))

    def table(self, header: list[str], rows: list[list[str]], caption: str | None) -> None:
        if caption:
            self.table_no += 1
            paragraph = self.doc.add_paragraph()
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            paragraph.paragraph_format.first_line_indent = Cm(0)
            paragraph.paragraph_format.space_before = Pt(10)
            paragraph.paragraph_format.space_after = Pt(4)
            paragraph.paragraph_format.keep_with_next = True
            inline(paragraph, f"Bảng {self.chapter}.{self.table_no}. {caption}", size=Pt(12))

        table = self.doc.add_table(rows=1, cols=len(header))
        table.style = "Table Grid"
        # A long table must keep its header on every page and must not break a row in half.
        header_row = table.rows[0]._tr
        header_props = header_row.get_or_add_trPr()
        repeat = OxmlElement("w:tblHeader")
        repeat.set(qn("w:val"), "true")
        header_props.append(repeat)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.autofit = True
        for index, text in enumerate(header):
            cell = table.rows[0].cells[index]
            cell.text = ""
            paragraph = cell.paragraphs[0]
            paragraph.paragraph_format.first_line_indent = Cm(0)
            paragraph.paragraph_format.line_spacing = 1.0
            paragraph.paragraph_format.space_after = Pt(2)
            paragraph.paragraph_format.space_before = Pt(2)
            paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
            run = paragraph.add_run(text)
            set_font(run, Pt(11), bold=True)
            shade(cell, "F2F2F2")
        for row in rows:
            added = table.add_row()
            no_split = OxmlElement("w:cantSplit")
            added._tr.get_or_add_trPr().append(no_split)
            cells = added.cells
            for index, text in enumerate(row):
                paragraph = cells[index].paragraphs[0]
                paragraph.paragraph_format.first_line_indent = Cm(0)
                paragraph.paragraph_format.line_spacing = 1.0
                paragraph.paragraph_format.space_after = Pt(2)
                paragraph.paragraph_format.space_before = Pt(2)
                paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
                inline(paragraph, text, size=Pt(11))
        self.doc.add_paragraph().paragraph_format.space_after = Pt(0)

    def pagebreak(self) -> None:
        paragraph = self.doc.add_paragraph()
        paragraph.add_run().add_break(WD_BREAK.PAGE)

    # -- markdown ----------------------------------------------------------------------------
    def render(self, text: str) -> None:
        lines = text.splitlines()
        index = 0
        while index < len(lines):
            raw = lines[index]
            line = raw.rstrip()
            if not line.strip():
                index += 1
                continue
            if line.startswith("# "):
                self.h1(line[2:].strip())
                index += 1
            elif line.startswith("## "):
                self.h2(line[3:].strip())
                index += 1
            elif line.startswith("### "):
                self.h3(line[4:].strip())
                index += 1
            elif line.startswith("@toc"):
                self.toc()
                index += 1
            elif line.startswith("@pagebreak"):
                self.pagebreak()
                index += 1
            elif line.startswith("@figure "):
                path_part, _, caption = line[len("@figure "):].partition("|")
                path = (REPO / path_part.strip()) if path_part.strip().startswith("docs/") else (ASSETS / path_part.strip())
                self.figure(path, caption.strip())
                index += 1
            elif line.startswith("@table "):
                caption = line[len("@table "):].strip()
                index += 1
                while index < len(lines) and not lines[index].strip():
                    index += 1
                header: list[str] = []
                rows: list[list[str]] = []
                while index < len(lines) and lines[index].strip().startswith("|"):
                    cells = [cell.strip() for cell in lines[index].strip().strip("|").split("|")]
                    if all(set(cell) <= set("-: ") for cell in cells):
                        index += 1
                        continue
                    if not header:
                        header = cells
                    else:
                        rows.append(cells)
                    index += 1
                self.table(header, rows, caption)
            elif line.startswith("| "):
                header = [cell.strip() for cell in line.strip().strip("|").split("|")]
                rows = []
                index += 1
                while index < len(lines) and lines[index].strip().startswith("|"):
                    cells = [cell.strip() for cell in lines[index].strip().strip("|").split("|")]
                    if not all(set(cell) <= set("-: ") for cell in cells):
                        rows.append(cells)
                    index += 1
                self.table(header, rows, None)
            elif re.match(r"^[-*] ", line):
                self.bullet(line[2:].strip())
                index += 1
            elif line.startswith("> "):
                self.quote(line[2:].strip())
                index += 1
            else:
                buffer = [line.strip()]
                index += 1
                while index < len(lines) and lines[index].strip() and not re.match(
                    r"^(#|@|\||[-*] |> )", lines[index]
                ):
                    buffer.append(lines[index].strip())
                    index += 1
                self.para(" ".join(buffer))

    def save(self, out: Path) -> None:
        self.doc.save(out)


def main() -> None:
    out = OUT
    if "-o" in sys.argv:
        out = Path(sys.argv[sys.argv.index("-o") + 1])

    chapters = [p for p in sorted(CONTENT.glob("*.md")) if not p.name.startswith("00-")]
    report = Report(scan_headings(chapters), load_pages(REPORT / "toc-pages.json"))
    report.cover()
    report.new_section(page_numbers=False)
    report.toc()

    body = sorted(CONTENT.glob("*.md"))
    if not body:
        raise SystemExit(f"no chapter sources in {CONTENT}")
    first = True
    for path in body:
        if path.name.startswith("00-"):
            continue
        if first:
            report.new_section(page_numbers=True)
            first = False
        else:
            report.pagebreak()
        report.render(path.read_text(encoding="utf-8"))

    out.parent.mkdir(parents=True, exist_ok=True)
    report.save(out)
    print(f"wrote {out} ({out.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
