"""Build Slide_BaoVe.pptx: the fifteen-minute defence deck.

Content mirrors the report chapters; every number comes from the same frozen run. Layout is fixed
by a few helpers so the deck stays consistent without a template.

Usage: python build_slides.py [-o output.pptx]
"""

from __future__ import annotations

import sys
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.util import Emu, Inches, Pt

REPO = Path(__file__).resolve().parents[2]
FIGS = REPO / "docs" / "report" / "assets" / "figures"
OUT = REPO / "docs" / "submission" / "Slide_BaoVe.pptx"

INK = RGBColor(0x1E, 0x1C, 0x18)
CREAM = RGBColor(0xF6, 0xF1, 0xE8)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
CLAY = RGBColor(0xA6, 0x51, 0x2B)
MUTED = RGBColor(0x6C, 0x62, 0x55)
LINE = RGBColor(0x8F, 0x80, 0x69)
SERIF = "Times New Roman"
SANS = "Segoe UI"


class Deck:
    def __init__(self) -> None:
        self.prs = Presentation()
        self.prs.slide_width = Inches(13.333)
        self.prs.slide_height = Inches(7.5)
        self.blank = self.prs.slide_layouts[6]

    # -- primitives --------------------------------------------------------------------------
    def slide(self):
        slide = self.prs.slides.add_slide(self.blank)
        background = slide.background.fill
        background.solid()
        background.fore_color.rgb = CREAM
        return slide

    def text(self, slide, left, top, width, height, value, size=18, bold=False, color=INK,
             font=SANS, align=PP_ALIGN.LEFT, italic=False):
        box = slide.shapes.add_textbox(left, top, width, height)
        frame = box.text_frame
        frame.word_wrap = True
        frame.margin_left = 0
        frame.margin_right = 0
        frame.margin_top = 0
        paragraph = frame.paragraphs[0]
        paragraph.alignment = align
        run = paragraph.add_run()
        run.text = value
        run.font.size = Pt(size)
        run.font.bold = bold
        run.font.italic = italic
        run.font.color.rgb = color
        run.font.name = font
        return box

    def bullets(self, slide, left, top, width, height, items, size=18, gap=8):
        box = slide.shapes.add_textbox(left, top, width, height)
        frame = box.text_frame
        frame.word_wrap = True
        frame.margin_left = 0
        frame.margin_top = 0
        first = True
        for item in items:
            paragraph = frame.paragraphs[0] if first else frame.add_paragraph()
            first = False
            paragraph.space_after = Pt(gap)
            run = paragraph.add_run()
            run.text = "— " + item
            run.font.size = Pt(size)
            run.font.color.rgb = INK
            run.font.name = SANS
        return box

    def rule(self, slide, top, left=Inches(0.8), width=None, color=LINE):
        line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top,
                                      width or (self.prs.slide_width - 2 * left), Emu(9525 * 1.5))
        line.fill.solid()
        line.fill.fore_color.rgb = color
        line.line.fill.background()
        return line

    def header(self, slide, kicker, title):
        self.text(slide, Inches(0.8), Inches(0.55), Inches(11.7), Inches(0.35), kicker.upper(),
                  size=12, bold=True, color=CLAY)
        self.text(slide, Inches(0.8), Inches(0.95), Inches(11.7), Inches(0.8), title,
                  size=32, bold=True, font=SERIF)
        self.rule(slide, Inches(1.85))

    def footer(self, slide, page):
        self.text(slide, Inches(0.8), Inches(6.95), Inches(6), Inches(0.3),
                  "Ứng dụng bán quần áo — Stylo", size=11, color=MUTED)
        self.text(slide, Inches(11.8), Inches(6.95), Inches(0.7), Inches(0.3), str(page),
                  size=11, color=MUTED, align=PP_ALIGN.RIGHT)

    def picture(self, slide, path, left, top, height=None, width=None):
        if not path.exists():
            raise SystemExit(f"missing figure: {path}")
        if width:
            return slide.shapes.add_picture(str(path), left, top, width=width)
        return slide.shapes.add_picture(str(path), left, top, height=height)

    # -- slides ------------------------------------------------------------------------------
    def cover(self):
        slide = self.slide()
        self.text(slide, Inches(0.9), Inches(1.4), Inches(11.5), Inches(0.4), "BÁO CÁO ĐỒ ÁN",
                  size=18, bold=True, color=CLAY, align=PP_ALIGN.CENTER)
        self.text(slide, Inches(0.9), Inches(2.0), Inches(11.5), Inches(1.0), "ỨNG DỤNG BÁN QUẦN ÁO",
                  size=48, bold=True, font=SERIF, align=PP_ALIGN.CENTER)
        self.text(slide, Inches(0.9), Inches(3.2), Inches(11.5), Inches(0.5),
                  "Kotlin · Jetpack Compose — Node.js · Express — MySQL 8", size=18, color=MUTED,
                  align=PP_ALIGN.CENTER)
        self.rule(slide, Inches(4.0), left=Inches(3.4), width=Inches(6.5))
        for index, line in enumerate(["Sinh viên thực hiện: ......................................",
                                      "MSSV: ....................  Lớp: .........................",
                                      "Năm học 2026"]):
            self.text(slide, Inches(0.9), Inches(4.4 + index * 0.5), Inches(11.5), Inches(0.4), line,
                      size=18, align=PP_ALIGN.CENTER)

    def why(self, page):
        slide = self.slide()
        self.header(slide, "Đặt vấn đề", "Bán quần áo trên điện thoại, quản trị trên cùng hệ thống")
        self.bullets(slide, Inches(0.8), Inches(2.2), Inches(5.9), Inches(4.2), [
            "Tồn kho theo biến thể: size × màu, mỗi tổ hợp một SKU",
            "Đơn COD chỉ là doanh thu khi đã giao",
            "Giá vốn bình quân phải chốt tại thời điểm bán",
            "Hai vai trò, một ứng dụng: khách và quản trị",
        ], size=19)
        box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(7.0), Inches(2.2),
                                     Inches(5.4), Inches(3.6))
        box.fill.solid()
        box.fill.fore_color.rgb = WHITE
        box.line.fill.background()
        frame = box.text_frame
        frame.word_wrap = True
        frame.margin_left = Inches(0.4)
        frame.margin_top = Inches(0.35)
        self.text(slide, Inches(7.4), Inches(2.55), Inches(4.6), Inches(0.4), "CÂU HỎI TRUNG TÂM",
                  size=12, bold=True, color=CLAY)
        self.text(slide, Inches(7.4), Inches(3.0), Inches(4.6), Inches(2.5),
                  "Làm sao để con số tồn kho và doanh thu trên màn hình "
                  "luôn bằng con số trong cơ sở dữ liệu?",
                  size=22, font=SERIF, bold=True)
        self.footer(slide, page)

    def scope(self, page):
        slide = self.slide()
        self.header(slide, "Phạm vi", "Mười một chức năng đề bài, mười hai nhóm chức năng")
        rows = [
            ("Khách", "Tìm kiếm, lọc, chi tiết, giỏ, đặt hàng COD/online, đơn của tôi, hồ sơ, địa chỉ"),
            ("Quản trị", "Sản phẩm, biến thể, ảnh, danh mục, thương hiệu, đơn, kho, người dùng, báo cáo"),
            ("Dùng chung", "Đăng ký, đăng nhập, JWT 15 phút + refresh 30 ngày, phân quyền theo vai trò"),
        ]
        top = Inches(2.2)
        for name, value in rows:
            card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top,
                                          Inches(11.7), Inches(1.15))
            card.fill.solid()
            card.fill.fore_color.rgb = WHITE
            card.line.fill.background()
            self.text(slide, Inches(1.1), top + Inches(0.35), Inches(1.6), Inches(0.4), name,
                      size=17, bold=True, color=CLAY)
            self.text(slide, Inches(2.9), top + Inches(0.3), Inches(9.3), Inches(0.7), value, size=16)
            top += Inches(1.38)
        self.text(slide, Inches(0.8), Inches(6.3), Inches(11.7), Inches(0.4),
                  "Ngoài phạm vi: khuyến mãi, đánh giá, đổi trả, giỏ cho khách vãng lai, đa tiền tệ",
                  size=14, italic=True, color=MUTED)
        self.footer(slide, page)

    def architecture(self, page):
        slide = self.slide()
        self.header(slide, "Kiến trúc", "Hai build độc lập, một hợp đồng API")
        boxes = [
            (Inches(0.8), "Ứng dụng Android", "Compose · MVVM · Repository\nHilt · Retrofit · DataStore"),
            (Inches(4.9), "API Node.js", "Express 5 · Zod\nroute → service → repository"),
            (Inches(9.0), "MySQL 8.4", "Prisma 7 · 16 bảng\nsổ cái tồn kho"),
        ]
        for left, title, subtitle in boxes:
            box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, Inches(2.5),
                                         Inches(3.4), Inches(2.0))
            box.fill.solid()
            box.fill.fore_color.rgb = WHITE
            box.line.fill.background()
            self.text(slide, left + Inches(0.3), Inches(2.75), Inches(2.8), Inches(0.4), title,
                      size=19, bold=True, font=SERIF)
            self.text(slide, left + Inches(0.3), Inches(3.25), Inches(2.9), Inches(1.0), subtitle,
                      size=14, color=MUTED)
        for left in (Inches(4.25), Inches(8.35)):
            arrow = slide.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, left, Inches(3.35),
                                           Inches(0.55), Inches(0.3))
            arrow.fill.solid()
            arrow.fill.fore_color.rgb = CLAY
            arrow.line.fill.background()
        self.bullets(slide, Inches(0.8), Inches(5.0), Inches(11.7), Inches(1.6), [
            "Backend không mock Prisma trong kiểm thử tích hợp: mọi ca chạy trên MySQL thật",
            "Android bản debug gọi 127.0.0.1:8787 qua adb reverse",
            "Cùng một hợp đồng API cho cả hai phía; mã lỗi ổn định, thông điệp tiếng Anh ở server",
        ], size=15)
        self.footer(slide, page)

    def erd(self, page):
        slide = self.slide()
        self.header(slide, "Cơ sở dữ liệu", "Mười sáu bảng, sinh thẳng từ lược đồ Prisma")
        self.picture(slide, REPO / "docs" / "report" / "assets" / "erd.png",
                     Inches(0.7), Inches(2.05), height=Inches(4.7))
        self.footer(slide, page)

    def decisions(self, page):
        slide = self.slide()
        self.header(slide, "Quyết định miền", "Bốn lựa chọn chi phối toàn bộ hệ thống")
        items = [
            ("ADR-0001", "Một đơn có nhiều lần thử thanh toán", "Thử lại không ghi đè lịch sử"),
            ("ADR-0002", "Tồn kho là sổ cái, trừ ngay khi đặt", "Không bán quá tồn"),
            ("ADR-0003", "Tiền là số nguyên VND", "Không sai số làm tròn"),
            ("ADR-0004", "Đơn hàng lưu ảnh chụp dữ liệu", "Hoá đơn không đổi khi giá đổi"),
        ]
        top = Inches(2.15)
        for code, title, reason in items:
            card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top,
                                          Inches(11.7), Inches(1.05))
            card.fill.solid()
            card.fill.fore_color.rgb = WHITE
            card.line.fill.background()
            self.text(slide, Inches(1.1), top + Inches(0.3), Inches(1.4), Inches(0.4), code,
                      size=14, bold=True, color=CLAY)
            self.text(slide, Inches(2.5), top + Inches(0.3), Inches(6.2), Inches(0.4), title, size=17)
            self.text(slide, Inches(9.0), top + Inches(0.3), Inches(3.2), Inches(0.4), reason,
                      size=14, color=MUTED)
            top += Inches(1.22)
        self.footer(slide, page)

    def design_system(self, page):
        slide = self.slide()
        self.header(slide, "Giao diện", "Hệ thống thiết kế thay cho mười hai kiểu chip")
        swatches = [("#F6F1E8", "background"), ("#1E1C18", "primary"), ("#A6512B", "secondary"),
                    ("#4F5E3F", "tertiary"), ("#B3261E", "error"), ("#FFFFFF", "card")]
        for index, (hex_value, name) in enumerate(swatches):
            left = Inches(0.8 + index * 1.35)
            chip = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, Inches(2.2),
                                          Inches(1.15), Inches(0.9))
            chip.fill.solid()
            chip.fill.fore_color.rgb = RGBColor.from_string(hex_value.lstrip("#"))
            chip.line.color.rgb = LINE
            self.text(slide, left, Inches(3.2), Inches(1.2), Inches(0.3), name, size=11, color=MUTED)
        self.bullets(slide, Inches(0.8), Inches(3.8), Inches(5.6), Inches(2.8), [
            "Thẻ trắng trên nền ivory: 1.13:1, không viền, không đổ bóng",
            "Chữ: serif cho tiêu đề, sans cho thân; thang chữ cố định",
            "Lưới 4dp, lề 20dp, bo góc theo thang 4–24",
        ], size=15)
        self.bullets(slide, Inches(6.9), Inches(3.8), Inches(5.6), Inches(2.8), [
            "Mười bốn thành phần dùng chung trong core/ui/components",
            "Bốn trạng thái dữ liệu: tải, rỗng, lỗi, lỗi cục bộ",
            "Không chỉ dựa vào màu: chip chọn có icon, trạng thái có nhãn chữ",
        ], size=15)
        self.footer(slide, page)

    def screens(self, page, kicker, title, names, caption=None):
        slide = self.slide()
        self.header(slide, kicker, title)
        count = len(names)
        width = Inches(2.55)
        gap = Inches(0.32)
        total = count * width + (count - 1) * gap
        left = Emu(int((self.prs.slide_width - total) / 2))
        for index, name in enumerate(names):
            self.picture(slide, FIGS / f"{name}.png", Emu(int(left + index * (width + gap))),
                         Inches(2.2), height=Inches(4.3))
        if caption:
            self.text(slide, Inches(0.8), Inches(6.62), Inches(11.7), Inches(0.35), caption,
                      size=12, italic=True, color=MUTED, align=PP_ALIGN.CENTER)
        self.footer(slide, page)

    def table(self, page, kicker, title, header, rows, note=None):
        slide = self.slide()
        self.header(slide, kicker, title)
        shape = slide.shapes.add_table(len(rows) + 1, len(header), Inches(0.8), Inches(2.3),
                                       Inches(11.7), Inches(0.4 * (len(rows) + 1)))
        table = shape.table
        for column, text in enumerate(header):
            cell = table.cell(0, column)
            cell.fill.solid()
            cell.fill.fore_color.rgb = INK
            paragraph = cell.text_frame.paragraphs[0]
            run = paragraph.add_run()
            run.text = text
            run.font.size = Pt(14)
            run.font.bold = True
            run.font.color.rgb = WHITE
            run.font.name = SANS
        for row_index, row in enumerate(rows, start=1):
            for column, value in enumerate(row):
                cell = table.cell(row_index, column)
                cell.fill.solid()
                cell.fill.fore_color.rgb = WHITE
                paragraph = cell.text_frame.paragraphs[0]
                run = paragraph.add_run()
                run.text = value
                run.font.size = Pt(14)
                run.font.color.rgb = INK
                run.font.name = SANS
        if note:
            self.text(slide, Inches(0.8), Inches(6.5), Inches(11.7), Inches(0.4), note,
                      size=13, italic=True, color=MUTED)
        self.footer(slide, page)

    def closing(self, page):
        slide = self.slide()
        self.text(slide, Inches(0.9), Inches(2.4), Inches(11.5), Inches(0.6),
                  "Cảm ơn thầy cô và các bạn đã lắng nghe", size=40, bold=True, font=SERIF,
                  align=PP_ALIGN.CENTER)
        self.text(slide, Inches(0.9), Inches(3.5), Inches(11.5), Inches(0.5),
                  "Câu hỏi và góp ý", size=22, color=MUTED, align=PP_ALIGN.CENTER)
        self.rule(slide, Inches(4.3), left=Inches(4.0), width=Inches(5.3))
        self.text(slide, Inches(0.9), Inches(4.6), Inches(11.5), Inches(1.2),
                  "Mã nguồn, báo cáo, slide, ERD A3, tệp dump và video demo nằm trong hồ sơ nộp kèm.",
                  size=16, color=MUTED, align=PP_ALIGN.CENTER)
        self.footer(slide, page)

    def save(self, out: Path) -> None:
        out.parent.mkdir(parents=True, exist_ok=True)
        self.prs.save(out)
        print(f"wrote {out} ({out.stat().st_size} bytes, {len(self.prs.slides)} slides)")


def main() -> None:
    out = OUT
    if "-o" in sys.argv:
        out = Path(sys.argv[sys.argv.index("-o") + 1])

    deck = Deck()
    deck.cover()
    deck.why(2)
    deck.scope(3)
    deck.architecture(4)
    deck.erd(5)
    deck.decisions(6)
    deck.design_system(7)
    deck.screens(8, "Giao diện khách", "Duyệt, chọn biến thể, mua",
                 ["01-home", "03-catalog", "09-detail-variants"],
                 caption="Trang chủ · Tìm kiếm · Chọn màu và kích cỡ")
    deck.screens(9, "Giao diện khách", "Giỏ hàng, thanh toán, đơn hàng",
                 ["18-cart", "20-checkout", "22-orders-list"],
                 caption="Chặn quá tồn · COD hoặc online · Theo dõi đơn")
    deck.screens(10, "Giao diện quản trị", "Một ứng dụng, hai vai trò",
                 ["23-admin-dashboard", "28-admin-products", "24-admin-orders"],
                 caption="Tổng quan · Sản phẩm · Hàng đợi đơn")
    deck.table(11, "Kiểm thử", "Bốn tầng, số liệu của lần chạy cuối",
               ["Bộ kiểm thử", "Số ca", "Kết quả", "Thời gian"],
               [["Đơn vị backend", "57", "57 đạt", "1,28 giây"],
                ["Tích hợp backend", "197", "197 đạt", "356 giây"],
                ["JVM Android", "190", "190 đạt", "39 giây"],
                ["Giao diện (Kaspresso)", "5", "5 đạt", "trên máy ảo stylo_api35"]],
               note="Phát hiện và sửa một lỗi thật: ca seed vượt hạn mức 30 giây sau khi danh mục lên 185 sản phẩm")
    deck.table(12, "Hợp đồng API", "Hai cơ chế chống lỗi đắt tiền",
               ["Cơ chế", "Chặn điều gì"],
               [["clientOrderId duy nhất theo người dùng", "Đơn trùng khi mạng chập chờn"],
                ["Kiểm chữ ký + số tiền khi cổng gọi về", "Xác nhận thanh toán giả từ URL"],
                ["SELECT … FOR UPDATE theo thứ tự id", "Bán quá tồn và deadlock giữa hai đơn"],
                ["Mã lỗi ổn định, client dịch sang tiếng Việt", "Giao diện phụ thuộc câu chữ server"]],
               note="Lỗi driver MariaDB (ER_DUP_ENTRY, ER_ROW_IS_REFERENCED_2) được map cùng nhóm Prisma")
    deck.screens(13, "Quản trị", "Báo cáo theo kỳ, có bảng số liệu",
                 ["31-report-revenue", "33-report-low-stock", "30-admin-inventory"],
                 caption="Doanh thu · Tồn thấp · Phiếu nhập và tồn kho")
    deck.table(14, "Kết luận", "Đã làm, chưa làm, làm tiếp",
               ["Hạng mục", "Trạng thái"],
               [["Mười một chức năng đề bài", "Đã cài đặt, có kiểm chứng ở bốn tầng"],
                ["Đổi trả và hoàn tiền", "Chưa làm — đơn đã thanh toán không huỷ được"],
                ["IPN VNPay trên máy nội bộ", "Không chạy được — xác nhận bằng chữ ký khi quay về"],
                ["Bước tiếp theo", "Đổi trả có đối soát, CI bốn tầng, tìm kiếm có xếp hạng"]],
               note="Sổ cái tồn kho trên dữ liệu seed: 1.478 dòng, lệch 0")
    deck.closing(15)
    deck.save(out)


if __name__ == "__main__":
    main()
