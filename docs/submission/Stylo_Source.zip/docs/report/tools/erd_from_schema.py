"""Render the physical ERD from server/prisma/schema.prisma into Mermaid source.

The report's A3 ERD must match the schema that runs, not a hand-drawn copy, so the diagram is
generated here and rendered with Mermaid CLI by scripts/export-erd.ps1.

Usage: python erd_from_schema.py [schema.prisma] > erd.mmd
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
DEFAULT_SCHEMA = REPO / "server" / "prisma" / "schema.prisma"

# Mermaid requires a type word on every attribute. Short words above keep all 16 boxes narrow
# enough to stay legible on one A3 page; chapter 3's data dictionary carries the full types.
SCALAR_TYPES = {
    "Int": "int",
    "BigInt": "long",
    "String": "str",
    "Boolean": "bool",
    "DateTime": "dt",
    "Float": "flt",
    "Decimal": "dec",
    "Json": "json",
}


@dataclass
class Field:
    name: str
    raw_type: str  # String, Int, Role, User?, User[]
    attrs: str
    line: str

    @property
    def is_list(self) -> bool:
        return self.raw_type.endswith("[]")

    @property
    def optional(self) -> bool:
        return self.raw_type.endswith("?")

    @property
    def base_type(self) -> str:
        return self.raw_type.rstrip("[]?")

    @property
    def is_relation(self) -> bool:
        return "@relation" in self.attrs

    @property
    def fk_fields(self) -> list[str]:
        match = re.search(r"fields:\s*\[([^\]]*)\]", self.attrs)
        if not match:
            return []
        return [part.strip() for part in match.group(1).split(",") if part.strip()]

    @property
    def is_pk(self) -> bool:
        return "@id" in self.attrs

    @property
    def is_unique(self) -> bool:
        return "@unique" in self.attrs


@dataclass
class Model:
    name: str
    table: str
    fields: list[Field] = field(default_factory=list)


def parse(schema_path: Path) -> tuple[list[Model], list[tuple[str, list[str]]]]:
    text = schema_path.read_text(encoding="utf-8")
    models: list[Model] = []
    enums: list[tuple[str, list[str]]] = []

    for block in re.finditer(r"^(model|enum)\s+(\w+)\s*\{(.*?)^\}", text, re.S | re.M):
        kind, name, body = block.group(1), block.group(2), block.group(3)
        if kind == "enum":
            enums.append((name, [line.strip() for line in body.splitlines() if line.strip()]))
            continue

        mapped = re.search(r'@@map\("([^"]+)"\)', body)
        model = Model(name=name, table=mapped.group(1) if mapped else name)
        for raw in body.splitlines():
            line = raw.strip()
            if not line or line.startswith("//") or line.startswith("@@"):
                continue
            parts = line.split(None, 2)
            if len(parts) < 2:
                continue
            model.fields.append(
                Field(name=parts[0], raw_type=parts[1], attrs=parts[2] if len(parts) > 2 else "", line=line)
            )
        models.append(model)

    return models, enums


def mermaid_type(f: Field, known_models: set[str], enums: set[str]) -> str:
    if f.base_type in SCALAR_TYPES:
        return SCALAR_TYPES[f.base_type]
    if f.base_type in enums:
        return "enum"
    if f.base_type in known_models:
        return "ref"
    return "string"


# Columns the ERD keeps per table when it is drawn for one A3 page: keys plus the business columns
# a reader needs to follow chapter 3. Every name here is checked against the schema, so a rename
# breaks the export instead of leaving a stale diagram.
CURATED: dict[str, list[str]] = {
    "User": ["id", "email", "fullName", "role", "status"],
    "RefreshToken": ["id", "userId", "tokenHash", "expiresAt"],
    "Address": ["id", "userId", "recipientName", "phone", "isDefault"],
    "Category": ["id", "name", "status"],
    "Brand": ["id", "name", "status"],
    "Product": ["id", "name", "categoryId", "brandId", "status"],
    "ProductVariant": ["id", "productId", "sku", "size", "color", "price", "stock"],
    "ProductImage": ["id", "productId", "position", "url"],
    "Cart": ["id", "userId"],
    "CartItem": ["id", "cartId", "variantId", "quantity"],
    "Order": ["id", "code", "userId", "status", "paymentMethod", "total", "paidAt"],
    "OrderItem": ["id", "orderId", "variantId", "quantity", "unitPrice", "unitCost"],
    "Payment": ["id", "orderId", "provider", "status", "amount", "txnRef"],
    "InventoryReceipt": ["id", "code", "supplier", "totalCost", "createdAt"],
    "InventoryReceiptItem": ["id", "receiptId", "variantId", "quantity", "unitCost"],
    "StockMovement": ["id", "variantId", "delta", "reason", "refType", "refId"],
}


def render(
    models: list[Model],
    enums: list[tuple[str, list[str]]],
    keys_only: bool = False,
    columns_only: bool = False,
) -> str:
    known_models = {m.name for m in models}
    enum_names = {name for name, _ in enums}
    lines = ["erDiagram"]

    for model in models:
        attributes = []
        wanted = None if not columns_only else set(CURATED.get(model.name, []))
        if columns_only:
            known = {f.name for f in model.fields}
            missing = wanted - known
            if missing:
                raise SystemExit(f"{model.name}: curated columns missing from the schema: {sorted(missing)}")
        for f in model.fields:
            if f.is_list:
                continue
            attrs = ""
            if f.is_pk:
                attrs = " PK"
            elif f.fk_fields:
                attrs = " FK"
            elif f.is_unique:
                attrs = " UK"
            mtype = mermaid_type(f, known_models, enum_names)
            if mtype == "ref":
                continue
            # keys_only keeps the A3 page legible: every box is a key list, and the data dictionary
            # in chapter 3 carries the business columns.
            if keys_only and not attrs:
                continue
            if columns_only and f.name not in wanted and not attrs:
                continue
            comment = ""
            if f.base_type in enum_names and not attrs:
                comment = f' "{f.base_type}"'
            attributes.append(f"        {mtype} {f.name}{attrs}{comment}")
        lines.append(f"    {model.name.upper()} {{")
        lines.extend(attributes)
        lines.append("    }")

    seen: set[tuple[str, str]] = set()
    for model in models:
        for f in model.fields:
            if not f.is_relation or not f.fk_fields:
                continue
            parent = f.base_type
            child = model.name
            if (parent, child) in seen:
                continue
            seen.add((parent, child))
            child_side = "o|" if f.is_unique else "o{"
            parent_side = "|o" if f.optional else "||"
            lines.append(f'    {parent.upper()} {parent_side}--{child_side} {child.upper()} : "has"')

    return "\n".join(lines) + "\n"


def main() -> None:
    flags = {"--keys-only", "--columns"}
    args = [a for a in sys.argv[1:] if a not in flags]
    schema_path = Path(args[0]) if args else DEFAULT_SCHEMA
    models, enums = parse(schema_path)
    sys.stdout.write(
        render(models, enums, keys_only="--keys-only" in sys.argv, columns_only="--columns" in sys.argv)
    )


if __name__ == "__main__":
    main()
