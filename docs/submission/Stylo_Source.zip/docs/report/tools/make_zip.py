"""Pack the source tree for submission, leaving out build output, secrets and machine state.

The submission zip must not carry node_modules, Gradle output, .env files or recorded screenshots;
the report keeps its own copies of the figures it needs.

Usage: python make_zip.py
"""

from __future__ import annotations

import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
STAGE = REPO / ".scratch" / "stylo-app" / "probe" / "zip-staging"
OUT = REPO / "docs" / "submission" / "Stylo_Source.zip"

EXCLUDE_DIRS = {
    ".git", ".agents", ".claude", ".gradle", ".kotlin", "node_modules", "build", "dist",
    "generated", "uploads", "test-uploads", ".scratch", "submission", "devices", "mobilecli@latest",
    "__pycache__", ".idea", ".vscode",
}
EXCLUDE_FILES = {".env", "local.properties", "skills-lock.json", "AGENTS.md", "CLAUDE.md"}
EXCLUDE_SUFFIXES = {".log", ".mp4", ".zip", ".pdf", ".docx", ".pptx"}


def keep(path: Path) -> bool:
    if path.name in EXCLUDE_FILES or path.suffix in EXCLUDE_SUFFIXES:
        return False
    return not any(part in EXCLUDE_DIRS for part in path.parts)


def main() -> None:
    if STAGE.exists():
        shutil.rmtree(STAGE)
    STAGE.mkdir(parents=True)

    copied = 0
    for source in REPO.rglob("*"):
        relative = source.relative_to(REPO)
        if not source.is_file() or not keep(relative):
            continue
        target = STAGE / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        copied += 1
    print(f"staged {copied} files")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(STAGE.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(STAGE).as_posix())

    size = OUT.stat().st_size / 1_048_576
    print(f"wrote {OUT} ({size:.1f} MB)")
    with zipfile.ZipFile(OUT) as archive:
        names = archive.namelist()
        problems = [
            name for name in names
            if "node_modules" in name or "/build/" in name or name.endswith(".env") or "/.gradle/" in name
        ]
        print(f"entries: {len(names)}; forbidden entries: {len(problems)}")
        if problems:
            print(problems[:5])
            sys.exit(1)


if __name__ == "__main__":
    main()
