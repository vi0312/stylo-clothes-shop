"""Export BaoCao_Stylo.docx to PDF through Word and report the page layout.

Word is the renderer because the report's table of contents is a Word field: the script updates the
fields first, saves the .docx back (so the TOC keeps its page numbers), then exports with fonts
embedded. Printing from Word also guarantees the pagination the reader sees matches the PDF.

Usage: python export_pdf.py [input.docx] [output.pdf]
"""

from __future__ import annotations

import sys
from pathlib import Path

import win32com.client as win32

REPO = Path(__file__).resolve().parents[2]
DEFAULT_DOCX = REPO / "docs" / "submission" / "BaoCao_Stylo.docx"


def export(docx: Path, pdf: Path) -> tuple[int, list[tuple[str, int]]]:
    word = win32.gencache.EnsureDispatch("Word.Application")
    word.Visible = False
    word.DisplayAlerts = 0
    document = word.Documents.Open(
        str(docx), ConfirmConversions=False, ReadOnly=False, AddToRecentFiles=False
    )
    try:
        # The contents page is built as real paragraphs (see build_report.py), so there is no TOC
        # field to update here; updating fields is what used to block Word behind a modal dialog.
        document.EmbedTrueTypeFonts = True
        document.SaveAs2(str(pdf), FileFormat=17)  # wdFormatPDF
        document.Save()

        pages = document.ComputeStatistics(2)  # wdStatisticPages
        headings: list[tuple[str, int]] = []
        for paragraph in document.Paragraphs:
            style = paragraph.Style.NameLocal
            if style.lower().startswith("heading 1"):
                text = paragraph.Range.Text.strip()
                page = paragraph.Range.Information(3)  # wdActiveEndPageNumber
                headings.append((text, int(page)))
        return int(pages), headings
    finally:
        document.Close(SaveChanges=0)
        word.Quit()


def main() -> None:
    # Word resolves relative paths against its own working directory, so qualify both.
    docx = (Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_DOCX).resolve()
    pdf = (Path(sys.argv[2]) if len(sys.argv) > 2 else docx.with_suffix(".pdf")).resolve()
    pages, headings = export(docx, pdf)
    print(f"{pdf.name}: {pages} pages, {pdf.stat().st_size} bytes")
    for text, page in headings:
        print(f"  page {page:>3}  {text}")


if __name__ == "__main__":
    main()
