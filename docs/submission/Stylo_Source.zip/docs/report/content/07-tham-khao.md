# TÀI LIỆU THAM KHẢO

Các tài liệu dưới đây là nguồn được đọc và dùng trực tiếp trong quá trình làm đồ án. Tài liệu nội bộ
nằm trong chính kho mã nguồn, ở thư mục `docs/`.

**Tài liệu kỹ thuật**

1. Prisma, *Prisma ORM documentation* — lược đồ, migration, giao dịch tương tác và driver adapter.
2. Express, *Express 5.x documentation* — định tuyến, middleware và xử lý lỗi bất đồng bộ.
3. Android Developers, *Compose documentation* — trạng thái, hiệu ứng một lần, `LazyColumn`, điều hướng.
4. Material Design 3, *Design tokens and components* — vai trò màu, thang chữ, thang hình dạng.
5. W3C, *Web Content Accessibility Guidelines 2.2* — tiêu chí 1.4.3 về tương phản và 1.4.11 về tương
   phản của thành phần giao diện.
6. Square, *OkHttp documentation* — interceptor và authenticator cho việc làm mới token.
7. VNPay, *Đặc tả tích hợp cổng thanh toán sandbox* — tham số, thứ tự sắp xếp và thuật toán ký.

**Tài liệu nội bộ**

8. `docs/PROJECT.md` — đề bài và môi trường phát triển.
9. `docs/erd.md` — lược đồ, quy ước dữ liệu, vòng đời đơn và bốn giao dịch then chốt.
10. `docs/api.md` — hợp đồng API, mô hình lỗi và danh mục mã lỗi.
11. `docs/ui.md` — hệ thống thiết kế, token và đặc tả từng màn hình.
12. `docs/architecture.md` — cấu trúc kho mã, luật module và cấu hình chạy.
13. `docs/testing.md` — chiến lược kiểm thử, ma trận bốn tầng và dữ liệu demo.
14. `docs/reports.md` — định nghĩa năm báo cáo, cột ngày và công thức.
15. `docs/adr/0001`–`0017` — mười bảy quyết định kiến trúc kèm bối cảnh và hệ quả.
16. `GLOSSARY.md` — bảng thuật ngữ dùng thống nhất trong mã, API và giao diện.
