# 2. PHÂN TÍCH YÊU CẦU VÀ CHỨC NĂNG

## 2.1. Yêu cầu của đề bài

Đề bài yêu cầu phân tích chức năng, thiết kế cơ sở dữ liệu, thiết kế giao diện và xây dựng một ứng
dụng bán quần áo có các chức năng: đăng ký/đăng nhập; quản lý thông tin cá nhân; quản lý giỏ hàng
(thêm, sửa, xoá); quản lý sản phẩm (thêm, sửa, xoá); quản lý đơn hàng; quản lý người dùng; tìm kiếm
sản phẩm theo danh mục, tên, màu sắc, giá và thương hiệu; chi tiết sản phẩm; thanh toán; báo cáo và
thống kê; phiếu giá nhập kho sản phẩm. Môi trường được chỉ định: Kotlin cho Android, Node.js cho
backend, MySQL cho cơ sở dữ liệu.

Mười một mục trên là yêu cầu tối thiểu. Khi phân tích, hai điểm cần làm rõ trước khi viết mã:

- **Ranh giới giữa khách vãng lai và khách hàng.** Đề bài không nói ai được xem sản phẩm. Nếu bắt đăng
  nhập mới xem được hàng thì ứng dụng bán lẻ mất đi lợi thế lớn nhất của nó; nếu cho thêm giỏ hàng khi
  chưa đăng nhập thì phải giải quyết bài toán gộp giỏ giữa các thiết bị — một việc không thuộc phạm vi
  đồ án. Ranh giới được chốt: xem và tìm kiếm không cần tài khoản, giỏ hàng và đơn hàng thì cần.
- **Quản trị đặt ở đâu.** Đề bài yêu cầu năm chức năng quản trị. Một website quản trị riêng sẽ nhân đôi
  khối lượng giao diện và không có thời gian làm đúng. Quản trị được đặt trong cùng ứng dụng Android,
  chỉ mở khi tài khoản có vai trò `ADMIN`, dùng chung tầng mạng và tầng dữ liệu với phía khách.

## 2.2. Ma trận chức năng

Mười hai nhóm chức năng dưới đây là bản chốt phạm vi của đồ án; mỗi dòng nêu tác nhân, mức hoàn thiện
và tiêu chí nghiệm thu. Cột "Màn hình" chỉ nơi chức năng xuất hiện trong ứng dụng.

@table Ma trận mười hai nhóm chức năng và tiêu chí nghiệm thu
| # | Chức năng | Tác nhân | Tiêu chí nghiệm thu | Màn hình |
| 1 | Đăng ký, đăng nhập | Khách hàng | Email + mật khẩu; access token 15 phút, refresh 30 ngày; sai mật khẩu trả một lỗi chung; không xác thực email, không quên mật khẩu | Đăng nhập / Đăng ký |
| 2 | Hồ sơ và địa chỉ | Khách hàng | Sửa họ tên, số điện thoại; thêm, sửa, xoá địa chỉ; đúng một địa chỉ mặc định; không có ảnh đại diện | Tôi, Địa chỉ giao hàng |
| 3 | Giỏ hàng | Khách hàng | Chỉ khi đã đăng nhập; thêm, sửa số lượng, xoá dòng, xoá tất cả; số lượng không vượt tồn; tổng tiền tính ở server | Giỏ hàng |
| 4 | Quản lý sản phẩm | Quản trị | Tạo, sửa, ẩn sản phẩm; biến thể size × màu có SKU riêng; tối đa 5 ảnh upload; ẩn thay vì xoá khi đã phát sinh đơn | Sản phẩm (quản trị) |
| 5 | Quản lý đơn hàng | Khách hàng, Quản trị | Khách xem danh sách, chi tiết, huỷ khi đơn còn `PENDING` hoặc `CONFIRMED`; quản trị chỉ chuyển theo bảng chuyển trạng thái hợp lệ; huỷ đơn hoàn tồn | Đơn hàng, Chi tiết đơn |
| 6 | Quản lý người dùng | Quản trị | Danh sách, tìm theo tên hoặc email, khoá và mở khoá; không đổi vai trò trong ứng dụng; tài khoản quản trị tạo bằng seed | Người dùng |
| 7 | Tìm kiếm sản phẩm | Khách vãng lai, Khách hàng | Từ khoá không dấu vẫn khớp; lọc kết hợp danh mục, thương hiệu, màu, kích cỡ, khoảng giá; sắp xếp theo giá hoặc mới nhất; phân trang | Tìm kiếm |
| 8 | Chi tiết sản phẩm | Khách vãng lai, Khách hàng | Ảnh, mô tả, chọn biến thể kèm tồn và giá theo biến thể; thêm vào giỏ đúng biến thể đã chọn | Chi tiết sản phẩm |
| 9 | Thanh toán | Khách hàng | COD hoặc thanh toán online qua VNPay sandbox, có cổng mock cho môi trường phát triển; giao dịch có trạng thái `PENDING`, `SUCCEEDED`, `FAILED`; `paid_at` là nguồn sự thật duy nhất | Thanh toán, Kết quả thanh toán |
| 10 | Báo cáo và thống kê | Quản trị | Năm báo cáo: doanh thu, sản phẩm bán chạy, đơn theo trạng thái, tồn thấp, chi phí và lãi gộp; lọc theo khoảng ngày; không xuất tệp | Báo cáo |
| 11 | Phiếu nhập kho | Quản trị | Tạo phiếu nhiều dòng (biến thể, số lượng, đơn giá nhập); cộng tồn trong cùng giao dịch; phiếu bất biến sau khi lưu | Kho |
| 12 | Danh mục và thương hiệu | Quản trị | Tạo, sửa, ẩn danh mục và thương hiệu; không xoá danh mục còn sản phẩm | Danh mục & thương hiệu |

Ba ranh giới nghiệp vụ trong bảng trên đáng được nêu riêng vì chúng quyết định phần lớn thiết kế:

Thứ nhất, **tồn kho gắn với biến thể, không gắn với sản phẩm**. Một chiếc áo có ba kích cỡ và hai màu
là sáu đơn vị bán độc lập, mỗi đơn vị một SKU, một giá và một số lượng tồn. Nếu tồn kho đặt ở mức sản
phẩm thì không thể trả lời câu hỏi thực tế nhất của cửa hàng: còn chiếc size M màu trắng hay không.

Thứ hai, **sản phẩm đã phát sinh đơn không bị xoá**. Xoá cứng sẽ làm đơn cũ mất tham chiếu tới mặt
hàng; vì vậy trạng thái hiển thị là một cột (`ACTIVE`/`INACTIVE`), và xoá cứng chỉ xảy ra khi chưa có
dòng nào tham chiếu tới sản phẩm.

Thứ ba, **huỷ đơn phải hoàn tồn trong cùng giao dịch**. Đây là chỗ dễ sinh sai lệch nhất giữa số liệu
bán hàng và số liệu kho, nên nó được thiết kế ở tầng cơ sở dữ liệu (chương 3) và kiểm thử ở tầng tích
hợp (chương 5).

## 2.3. Tác nhân và use case

Ba tác nhân và tập use case chính được liệt kê ở bảng dưới. Các use case quản trị đều yêu cầu vai trò
`ADMIN`; các use case mua hàng yêu cầu vai trò `CUSTOMER`; hai use case xem và tìm kiếm không yêu cầu
đăng nhập.

@table Danh sách use case theo tác nhân
| Tác nhân | Use case |
| Khách vãng lai | Xem trang chủ; tìm kiếm theo từ khoá; lọc và sắp xếp; xem chi tiết sản phẩm; mở màn hình đăng nhập khi cần |
| Khách hàng | Đăng ký; đăng nhập; đăng xuất; sửa hồ sơ; quản lý địa chỉ; thêm vào giỏ; sửa số lượng; xoá dòng; đặt hàng COD; đặt hàng và thanh toán online; xem danh sách đơn; xem chi tiết đơn; huỷ đơn |
| Quản trị | Xem tổng quan; tạo và sửa sản phẩm; quản lý biến thể; tải ảnh sản phẩm; ẩn/hiện sản phẩm; quản lý danh mục và thương hiệu; xử lý đơn theo vòng đời; tạo phiếu nhập kho; quản lý người dùng; xem năm báo cáo |

Luồng chuẩn của khách hàng, dùng làm kịch bản demo ở phụ lục B, gồm: tìm sản phẩm bằng từ khoá không
dấu, lọc theo thương hiệu, mở chi tiết, chọn màu và kích cỡ, thêm vào giỏ, đặt hàng COD với địa chỉ mặc
định, rồi theo dõi đơn ở màn hình Đơn hàng. Luồng quản trị gồm: xem tổng quan, xác nhận một đơn đang
chờ, tạo sản phẩm mới, tạo phiếu nhập kho và đọc báo cáo tháng.

## 2.4. Quy tắc nghiệp vụ

Các quy tắc dưới đây được kiểm thử trực tiếp ở tầng service và tầng cơ sở dữ liệu, không chỉ được mô
tả trong tài liệu.

@table Quy tắc nghiệp vụ bắt buộc
| Nhóm | Quy tắc | Hệ quả khi vi phạm |
| Tài khoản | Một tài khoản có đúng một vai trò; tài khoản quản trị chỉ sinh ra từ seed | Đăng nhập bị từ chối, không có đường tự nâng quyền |
| Tài khoản | Tài khoản bị khoá không đăng nhập được, kể cả khi token cũ còn hạn | Request trả `ACCOUNT_DISABLED` |
| Địa chỉ | Mỗi khách có đúng một địa chỉ mặc định; địa chỉ đầu tiên tự thành mặc định | Service đặt lại cờ trong cùng giao dịch |
| Giỏ hàng | Số lượng một dòng không vượt tồn hiện tại của biến thể | Thêm hoặc sửa vượt tồn trả `OUT_OF_STOCK` |
| Giỏ hàng | Tổng tiền luôn do server tính từ giá hiện hành của biến thể | Client không gửi giá lên khi đặt hàng |
| Đặt hàng | Một biến thể chỉ được bán khi sản phẩm đang `ACTIVE` và biến thể còn hàng | `ITEM_UNAVAILABLE` hoặc `OUT_OF_STOCK` |
| Đặt hàng | Mỗi lần bấm đặt hàng mang một `clientOrderId`; gửi lại cùng mã trả về đơn đã tạo | Không tạo đơn trùng khi mạng chập chờn |
| Tồn kho | Mọi thay đổi tồn đi kèm một dòng sổ cái `StockMovement` trong cùng giao dịch | Tồn và sổ cái luôn khớp |
| Đơn hàng | Chỉ chuyển trạng thái theo bảng ở mục 2.5; trạng thái cuối là `DELIVERED` và `CANCELLED` | `INVALID_ORDER_STATE` |
| Đơn hàng | Huỷ đơn chỉ khi đơn chưa thanh toán (`paid_at` rỗng) | Không có luồng hoàn tiền |
| Thanh toán | Đơn COD được đánh dấu đã thanh toán khi chuyển sang `DELIVERED`; đơn online khi cổng xác nhận | Doanh thu chỉ ghi nhận trên đơn đã thanh toán |
| Thanh toán | Một đơn có nhiều lần thử thanh toán, mỗi lần một bản ghi `Payment` riêng | Lần thử hỏng không xoá lần thử trước |
| Sản phẩm | Ảnh sản phẩm tải lên kiểm tra magic byte, tối đa 5 ảnh mỗi sản phẩm | Tệp sai định dạng bị từ chối |
| Danh mục | Không xoá danh mục hoặc thương hiệu còn sản phẩm tham chiếu | Khoá ngoại `RESTRICT` chặn ở tầng dữ liệu |
| Phiếu nhập | Phiếu đã lưu là bất biến; sai sót xử lý bằng phiếu mới | Không có endpoint sửa hoặc xoá phiếu |

## 2.5. Vòng đời đơn hàng

Đơn hàng có năm trạng thái. `PENDING` là trạng thái sau khi đặt; `CONFIRMED` là đã được cửa hàng xác
nhận; `SHIPPING` là đang giao; `DELIVERED` và `CANCELLED` là hai trạng thái kết thúc. Mỗi chuyển trạng
thái đi qua một hàm service duy nhất, hàm này kiểm tra cặp trạng thái, người thực hiện và điều kiện
thanh toán trước khi ghi.

@table Các chuyển trạng thái hợp lệ của đơn hàng
| Từ | Sang | Ai được làm | Tác dụng phụ |
| `PENDING` | `CONFIRMED` | Quản trị, hoặc cổng thanh toán khi thanh toán thành công | Đơn online: ghi `paid_at` |
| `PENDING` | `CANCELLED` | Khách sở hữu đơn, quản trị | Hoàn tồn, ghi sổ cái |
| `CONFIRMED` | `SHIPPING` | Quản trị | Không |
| `CONFIRMED` | `CANCELLED` | Khách sở hữu đơn, quản trị | Hoàn tồn, ghi sổ cái |
| `SHIPPING` | `DELIVERED` | Quản trị | Đơn COD: ghi `paid_at` |

Hai trạng thái kết thúc không có đường ra. Quy tắc chặn thứ hai là điều kiện thanh toán: đơn đã có
`paid_at` không thể huỷ, vì hệ thống không có luồng hoàn tiền. Với đơn COD, điều này không cản trở gì
trong thực tế: khách chưa trả tiền cho tới khi nhận hàng, nên việc huỷ trước khi giao vẫn hợp lệ; sau
khi giao thì đơn đã thanh toán và không huỷ được nữa.

Một chi tiết dễ bỏ sót: **ngày ghi nhận doanh thu của đơn COD là ngày giao hàng, không phải ngày đặt**.
Báo cáo doanh thu vì vậy đọc theo `paid_at`, và một đơn đặt ngày 5 nhưng giao ngày 8 sẽ xuất hiện trong
báo cáo của ngày 8. Đây là lựa chọn có chủ đích, được ghi thành ADR-0007 và được kiểm thử ở nhóm báo
cáo.

## 2.6. Phân quyền

Ứng dụng dùng một bảng người dùng và một cột vai trò; không có bảng quyền riêng. Mọi endpoint được
chia thành bốn mức: công khai, yêu cầu đăng nhập, yêu cầu vai trò quản trị, và công khai có giới hạn
(chỉ đọc dữ liệu đang bán). Bảng dưới là ánh xạ mức quyền cho từng nhóm endpoint.

@table Ánh xạ quyền theo nhóm endpoint
| Nhóm | Mức truy cập | Ghi chú |
| Xác thực, hồ sơ, địa chỉ | Công khai với đăng ký và đăng nhập; còn lại yêu cầu token | Token hết hạn được làm mới bằng refresh token |
| Danh mục công khai, sản phẩm, bộ lọc | Công khai | Chỉ trả sản phẩm `ACTIVE` |
| Giỏ hàng | Yêu cầu đăng nhập | Giỏ thuộc về chính người gọi |
| Đơn hàng của tôi, thanh toán | Yêu cầu đăng nhập | Truy vấn luôn kèm điều kiện chủ sở hữu |
| Quản trị sản phẩm, danh mục, thương hiệu, ảnh | Yêu cầu vai trò `ADMIN` | |
| Quản trị đơn, kho, người dùng, báo cáo | Yêu cầu vai trò `ADMIN` | |

Kiểm tra quyền nằm ở middleware, không nằm trong từng handler: một middleware xác thực token và nạp
người dùng (từ chối tài khoản bị khoá), một middleware kiểm tra vai trò. Cách này khiến việc thêm
endpoint mới khó quên kiểm tra quyền hơn so với kiểm tra rải rác.

## 2.7. Phạm vi loại trừ

Những mục sau được chủ động loại khỏi phạm vi, và được nêu ở đây để người đọc không tìm kiếm chúng
trong chương trình:

- Giỏ hàng cho khách vãng lai và gộp giỏ giữa các thiết bị.
- Quên mật khẩu, đổi mật khẩu qua email, xác thực email.
- Đổi trả hàng, hoàn tiền, trạng thái trả hàng; đơn đã thanh toán không huỷ được.
- Đổi vai trò người dùng trong ứng dụng; tài khoản quản trị chỉ có từ seed.
- Sửa hoặc xoá phiếu nhập kho sau khi lưu.
- Xuất báo cáo ra CSV hoặc Excel; ảnh đại diện người dùng.
- Khuyến mãi, voucher, đánh giá sản phẩm, danh sách yêu thích, đa tiền tệ.

Việc loại trừ không làm giảm tính đầy đủ của đồ án: mười một chức năng đề bài yêu cầu đều nằm trong
phạm vi và đều có đường kiểm chứng ở chương 5.
