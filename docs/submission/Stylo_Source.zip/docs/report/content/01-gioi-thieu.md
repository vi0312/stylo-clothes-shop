# 1. GIỚI THIỆU

## 1.1. Đặt vấn đề

Bán lẻ quần áo tại Việt Nam đã chuyển phần lớn khâu chọn hàng sang điện thoại: khách xem ảnh, so
kích cỡ, hỏi giá và đặt hàng trên thiết bị di động, trong khi cửa hàng vẫn phải quản lý tồn kho theo
từng kích cỡ và màu, theo dõi đơn giao và biết chính xác lãi gộp của từng đơn. Hai phía này thường
được giải quyết bằng hai hệ thống rời nhau: một website bán hàng cho khách và một file bảng tính cho
chủ cửa hàng. Cách làm đó dẫn tới ba hệ quả quen thuộc: số lượng tồn trên màn hình khách không khớp
với số lượng thực tế trong kho, đơn hàng bị xác nhận hai lần cho cùng một lượng hàng, và báo cáo lãi
gộp chỉ được dựng lại bằng tay vào cuối tháng.

Đồ án này xây dựng **Stylo**, một ứng dụng bán quần áo gồm ứng dụng Android cho khách mua hàng và
phần quản trị nằm trong chính ứng dụng đó, dùng chung một API và một cơ sở dữ liệu. Điểm khác biệt của
hướng tiếp cận không nằm ở giao diện mà ở chỗ mọi con số bán hàng đều neo vào hai thứ được lưu vết:
tồn kho là sổ cái chỉ ghi thêm (append-only ledger), và doanh thu chỉ được ghi nhận khi đơn đã thanh
toán. Nhờ vậy khách thấy đúng số lượng còn bán, còn chủ cửa hàng đọc được cùng một con số ở màn hình
báo cáo và ở cơ sở dữ liệu.

## 1.2. Mục tiêu và phạm vi

Mục tiêu của đồ án là một hệ thống chạy được đầu-cuối trên máy phát triển, phủ đủ các chức năng mà đề
bài yêu cầu, với hai vai trò người dùng và thanh toán trực tuyến ở mức sandbox:

- **Khách (customer)**: tìm kiếm và lọc sản phẩm, xem chi tiết theo biến thể, quản lý giỏ hàng, đặt
  hàng, thanh toán khi nhận hàng (COD) hoặc thanh toán online qua cổng VNPay ở mức sandbox, theo dõi và
  huỷ đơn trong giới hạn trạng thái cho phép.
- **Quản trị (admin)**: quản lý sản phẩm, biến thể và ảnh; quản lý danh mục và thương hiệu; xử lý đơn
  theo đúng vòng đời; tạo phiếu nhập kho nhiều dòng và lưu lịch sử giá nhập; quản lý người dùng; xem
  năm báo cáo doanh thu, sản phẩm bán chạy, đơn theo trạng thái, tồn thấp và chi phí–lãi gộp.
- **Khách vãng lai (guest)**: xem và tìm sản phẩm mà không cần tài khoản; giỏ hàng và đơn hàng yêu cầu
  đăng nhập.

Phạm vi được chốt hẹp có chủ đích để phần đã làm là phần chạy được: một ứng dụng Android duy nhất cho
cả hai vai trò (không có web admin riêng), một cơ sở dữ liệu MySQL, backend chạy nội bộ trong mạng
LAN của máy phát triển, không triển khai lên máy chủ công cộng. Những phần không thuộc phạm vi — khuyến
mãi, voucher, đánh giá, danh sách yêu thích, đổi trả và hoàn tiền, đa tiền tệ — được liệt kê ở
mục 2.7 để người đọc không kỳ vọng nhầm.

## 1.3. Đối tượng sử dụng

| Vai trò | Mô tả | Việc chính trong hệ thống |
|---|---|---|
| Khách vãng lai | Người chưa đăng nhập, không phải một bản ghi trong cơ sở dữ liệu | Xem trang chủ, tìm kiếm, lọc, xem chi tiết sản phẩm |
| Khách hàng | Tài khoản `CUSTOMER` đang hoạt động | Giỏ hàng, đặt hàng, thanh toán, địa chỉ, hồ sơ, đơn của mình |
| Quản trị | Tài khoản `ADMIN` do seed tạo, không tự đăng ký | Sản phẩm, biến thể, ảnh, danh mục, thương hiệu, đơn, kho, người dùng, báo cáo |

## 1.4. Phương pháp thực hiện

Đồ án được làm theo hướng đặc tả trước, mã sau. Trước khi viết dòng mã đầu tiên, các quyết định lớn
được ghi thành văn bản: phạm vi chức năng, mô hình dữ liệu, hợp đồng API, thiết kế giao diện, chiến
lược kiểm thử và công thức giá vốn. Mười bảy quyết định kiến trúc (ADR) lưu trong `docs/adr/`, mỗi
quyết định nêu bối cảnh, lựa chọn và hệ quả; nhờ vậy khi một lựa chọn bị thay đổi, tài liệu chỉ rõ chỗ
nào phải sửa theo.

Cách làm này có giá: văn bản phải cập nhật cùng mã, nếu không nó nhanh chóng trở thành tài liệu sai.
Đổi lại, ba thứ đắt nhất trong một dự án nhỏ đều có chỗ dựa: API không tự mọc thêm trường tuỳ hứng,
giao diện không tự đặt màu ngoài bảng token, và mỗi chức năng có đường kiểm chứng rõ ràng — hoặc một
kiểm thử tích hợp ở backend, hoặc một hành trình Kaspresso trên máy ảo, hoặc cả hai.

Ba tầng kiểm chứng được dùng xuyên suốt: kiểm thử đơn vị cho phần logic thuần, kiểm thử tích hợp cho
đường HTTP và giao dịch cơ sở dữ liệu, và kiểm thử giao diện tự động cho các luồng đã hoàn thiện. Số
liệu của lần chạy cuối cùng được ghi ở chương 5, kèm môi trường chạy để người đọc đối chiếu.

## 1.5. Bố cục báo cáo

Báo cáo gồm sáu chương và ba phụ lục:

- **Chương 1** nêu bối cảnh, mục tiêu, phạm vi và phương pháp.
- **Chương 2** phân tích yêu cầu: mười hai nhóm chức năng, tác nhân, use case, quy tắc nghiệp vụ và
  vòng đời đơn hàng.
- **Chương 3** trình bày thiết kế cơ sở dữ liệu: mười sáu bảng, quy ước dữ liệu, sổ cái tồn kho và
  bốn quyết định miền có ADR riêng.
- **Chương 4** trình bày thiết kế giao diện: hệ thống thiết kế, điều hướng theo vai trò, các màn hình
  của khách và của quản trị, cùng ảnh chụp thật từ máy ảo.
- **Chương 5** trình bày cài đặt và kiểm thử: kiến trúc hai phía, hợp đồng API, luồng thanh toán,
  chiến lược kiểm thử và số liệu của lần chạy cuối.
- **Chương 6** kết luận, nêu giới hạn đã biết và hướng phát triển.
- **Phụ lục A** liệt kê toàn bộ endpoint theo module; **Phụ lục B** là kịch bản demo và môi trường;
  **Phụ lục C** là các bước chạy lại hệ thống từ đầu.
