# 6. KẾT LUẬN VÀ HƯỚNG PHÁT TRIỂN

## 6.1. Đối chiếu với yêu cầu đề bài

Mười một chức năng đề bài yêu cầu đều đã được cài đặt, có giao diện và có đường kiểm chứng. Bảng dưới
đối chiếu từng mục với nơi thực hiện và cách kiểm chứng, để người đọc không phải suy luận từ mô tả.

@table Đối chiếu mười một chức năng của đề bài
| Chức năng đề bài | Nơi thực hiện | Kiểm chứng |
| Đăng ký, đăng nhập | Màn Đăng nhập/Đăng ký; `POST /auth/register`, `POST /auth/login` | Tích hợp xác thực, JVM cho ViewModel, hành trình Kaspresso |
| Quản lý thông tin cá nhân | Màn Tôi, Địa chỉ giao hàng | Tích hợp hồ sơ và địa chỉ, JVM, Kaspresso |
| Quản lý giỏ hàng | Màn Giỏ hàng; năm endpoint giỏ | Tích hợp giỏ, Kaspresso, kiểm tra chặn quá tồn |
| Quản lý sản phẩm | Màn Sản phẩm của quản trị; nhóm endpoint sản phẩm, biến thể, ảnh | Tích hợp quản trị sản phẩm và tải ảnh |
| Quản lý đơn hàng | Màn Đơn hàng hai phía; endpoint đơn và chuyển trạng thái | Tích hợp vòng đời đơn, Kaspresso danh sách và huỷ đơn |
| Quản lý người dùng | Màn Người dùng; khoá và mở khoá | Tích hợp quản trị người dùng |
| Tìm kiếm sản phẩm | Màn Tìm kiếm, sheet bộ lọc; `GET /products`, `GET /catalog/filters` | Tích hợp danh mục, Kaspresso tìm kiếm không dấu |
| Chi tiết sản phẩm | Màn Chi tiết với chọn biến thể | Tích hợp chi tiết, JVM cho trạng thái chọn biến thể |
| Thanh toán | Màn Thanh toán; COD, mock, VNPay | Tích hợp thanh toán và báo cáo doanh thu, Kaspresso thanh toán online |
| Báo cáo và thống kê | Màn Báo cáo với năm báo cáo | Tích hợp báo cáo theo cửa sổ ngày |
| Phiếu giá nhập kho | Màn Kho; phiếu nhập nhiều dòng và lịch sử giá nhập | Tích hợp kho và sổ cái tồn |

## 6.2. Hạn chế đã biết

Không có hệ thống nào hoàn thiện; những hạn chế dưới đây là hạn chế có ý thức, được nêu để người đọc
đánh giá đúng mức độ hoàn thiện chứ không phải để che đi phần còn thiếu.

**Chưa có đổi trả và hoàn tiền.** Đơn đã thanh toán không huỷ được, và không có luồng trả hàng. Trong
thực tế đây là nghiệp vụ phổ biến nhất bị hỏi đầu tiên, và nó kéo theo yêu cầu về đối soát với cổng
thanh toán. Hệ thống hiện tại cố tình chặn ở điều kiện `paid_at IS NULL` để không tạo ra một trạng thái
trả hàng nửa vời.

**Chưa có giỏ hàng cho khách vãng lai.** Người chưa đăng nhập phải đăng nhập trước khi thêm vào giỏ.
Đổi lại, hệ thống không phải giải bài toán gộp giỏ giữa nhiều thiết bị và không phải quản lý giỏ rác.

**Chưa có quên mật khẩu và xác thực email.** Cả hai đều cần dịch vụ gửi thư, một thành phần ngoài phạm
vi đồ án. Hệ quả: tài khoản tạo ra là dùng được ngay, nhưng không có đường tự phục hồi khi quên.

**IPN của VNPay không chạy trong môi trường nội bộ.** Đường xác nhận trong demo là đường quay về kèm
kiểm tra chữ ký. Với một hệ thống chạy thật, IPN là đường chính và đường quay về chỉ là đường dự phòng.

**Tìm kiếm dùng `LIKE`.** Với 185 sản phẩm, cách này nhanh và đơn giản. Với vài chục nghìn sản phẩm,
nó sẽ là điểm nghẽn đầu tiên; khi đó cần chỉ mục toàn văn hoặc một cột tên đã chuẩn hoá.

**Không có CI.** Toàn bộ kiểm thử chạy trên máy phát triển bằng tay. Một đường ống CI sẽ là việc đầu
tiên nên làm nếu dự án có thêm người thứ hai.

**Chỉ kiểm chứng trên một máy ảo.** Giao diện được kiểm trên `stylo_api35` (Android 15, 360×640dp). Các
kích thước màn hình khác, đặc biệt máy tính bảng và màn hình gập, chưa được kiểm.

## 6.3. Hướng phát triển

Bốn hướng dưới đây được xếp theo tỉ lệ giữa giá trị mang lại và công sức bỏ ra, không theo mức độ hấp
dẫn kỹ thuật.

**Thêm luồng đổi trả có đối soát.** Đây là phần bù tự nhiên cho quy tắc "đơn đã thanh toán không huỷ
được". Cần một trạng thái trả hàng, một bản ghi hoàn tiền và một quy tắc hoàn tồn chỉ áp dụng khi hàng
về kho, vì hàng hoàn có thể hỏng.

**Đường ống CI chạy bốn bộ kiểm thử.** Ba bộ chạy được trên máy không cần thiết bị; bộ Kaspresso cần
một máy ảo trong CI. Chỉ cần một workflow nối các lệnh đã có trong `docs/testing.md`.

**Tìm kiếm có xếp hạng.** Thay `LIKE` bằng chỉ mục toàn văn, thêm trọng số cho tên sản phẩm và thương
hiệu, và ghi nhận từ khoá không có kết quả để chỉnh danh mục. Bước này chỉ nên làm khi dữ liệu đủ lớn để
đo được cải thiện.

**Thông báo đẩy cho trạng thái đơn.** Người mua hiện phải mở ứng dụng để biết đơn đã giao. Một thông
báo đẩy khi đơn chuyển sang `SHIPPING` hoặc `DELIVERED` là thay đổi nhỏ ở server và vừa phải ở phía
Android, và nó cải thiện trải nghiệm rõ hơn nhiều so với việc thêm màn hình mới.

## 6.4. Bài học

Ba bài học dưới đây đến từ những chỗ đồ án thực sự vấp, không phải từ danh sách nguyên tắc chung.

**Đặc tả trước giúp sửa sai rẻ hơn, nhưng chỉ khi đặc tả được kiểm.** Quyết định "tiền là số nguyên
VND" được ghi thành ADR từ đầu, nên không có đoạn mã nào phải sửa khi làm báo cáo. Ngược lại, quy ước
"mọi thay đổi tồn đều có dòng sổ cái" chỉ có giá trị vì nó được kiểm bằng một truy vấn đối chiếu chạy
trên dữ liệu seed; nếu không có truy vấn đó, nó sẽ chỉ là một câu trong tài liệu.

**Kiểm thử đắt nhất là kiểm thử ở ranh giới tiền và tồn.** Phần lớn lỗi được phát hiện trong quá trình
làm nằm ở ba chỗ: trừ tồn hai lần khi hai yêu cầu đến cùng lúc, ghi doanh thu sai ngày với đơn COD, và
đơn trùng khi mạng chập chờn. Cả ba đều không phải lỗi giao diện, và cả ba đều được chặn ở tầng giao
dịch hoặc ở một khoá duy nhất trong cơ sở dữ liệu.

**Lớp thành phần dùng chung rẻ hơn sửa từng màn.** Đợt đánh giá giao diện cho thấy cùng một lỗi tương
phản màu lặp lại ở nhiều màn, và mỗi lần sửa lại sinh ra một biến thể mới. Sau khi gom về một lớp thành
phần, việc sửa một quy tắc trở thành sửa một tệp. Bài học này áp dụng cho mọi dự án có nhiều màn hình
hơn số người làm giao diện.
