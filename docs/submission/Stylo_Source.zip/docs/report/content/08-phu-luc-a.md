# Phụ lục A. Danh sách endpoint theo module

Đường dẫn gốc là `/api/v1`. Cột "Quyền" ghi `Công khai` cho endpoint không cần token, `Đăng nhập` cho
endpoint cần access token, và `Quản trị` cho endpoint cần vai trò `ADMIN`.

@table Endpoint xác thực và hồ sơ
| Phương thức và đường dẫn | Quyền | Mục đích |
| `POST /auth/register` | Công khai | Tạo tài khoản khách, trả cặp token |
| `POST /auth/login` | Công khai | Đăng nhập, trả cặp token |
| `POST /auth/refresh` | Công khai | Đổi refresh token lấy cặp token mới |
| `POST /auth/logout` | Đăng nhập | Thu hồi refresh token hiện tại |
| `GET /me` | Đăng nhập | Hồ sơ của chính mình |
| `PATCH /me` | Đăng nhập | Sửa họ tên, số điện thoại |

@table Endpoint địa chỉ giao hàng
| Phương thức và đường dẫn | Quyền | Mục đích |
| `GET /me/addresses` | Đăng nhập | Danh sách địa chỉ, mặc định trước |
| `POST /me/addresses` | Đăng nhập | Thêm địa chỉ |
| `PATCH /me/addresses/:id` | Đăng nhập | Sửa địa chỉ hoặc đặt mặc định |
| `DELETE /me/addresses/:id` | Đăng nhập | Xoá địa chỉ |

@table Endpoint danh mục công khai
| Phương thức và đường dẫn | Quyền | Mục đích |
| `GET /products` | Công khai | Danh sách sản phẩm đang bán; `q`, `categoryId`, `brandId`, `color`, `size`, `minPrice`, `maxPrice`, `sort`, `page`, `limit` |
| `GET /products/:id` | Công khai | Chi tiết sản phẩm kèm biến thể và ảnh |
| `GET /catalog/filters` | Công khai | Danh mục, thương hiệu, màu, kích cỡ và khoảng giá đang có |

@table Endpoint giỏ hàng
| Phương thức và đường dẫn | Quyền | Mục đích |
| `GET /cart` | Đăng nhập | Giỏ hiện tại kèm tổng tiền |
| `POST /cart/items` | Đăng nhập | Thêm biến thể với số lượng |
| `PATCH /cart/items/:itemId` | Đăng nhập | Đổi số lượng |
| `DELETE /cart/items/:itemId` | Đăng nhập | Xoá một dòng |
| `DELETE /cart` | Đăng nhập | Xoá toàn bộ giỏ |

@table Endpoint đơn hàng
| Phương thức và đường dẫn | Quyền | Mục đích |
| `POST /orders` | Đăng nhập | Đặt hàng; body có `clientOrderId`, địa chỉ, phương thức thanh toán |
| `GET /orders` | Đăng nhập | Danh sách đơn của mình, lọc theo trạng thái |
| `GET /orders/:id` | Đăng nhập | Chi tiết một đơn của mình |
| `POST /orders/:id/cancel` | Đăng nhập | Huỷ đơn khi còn huỷ được |

@table Endpoint thanh toán
| Phương thức và đường dẫn | Quyền | Mục đích |
| `POST /orders/:id/payments` | Đăng nhập | Tạo lần thử thanh toán, trả URL cổng |
| `GET /payments/:txnRef` | Đăng nhập | Trạng thái một giao dịch |
| `GET /payments/vnpay/return` | Công khai | Cổng quay về trình duyệt; kiểm chữ ký rồi xác nhận |
| `GET /payments/vnpay/ipn` | Công khai | Thông báo giữa hai hệ thống; trả `RspCode` theo đặc tả |

@table Endpoint quản trị danh mục và thương hiệu
| Phương thức và đường dẫn | Quyền | Mục đích |
| `GET /admin/categories` | Quản trị | Danh sách, có tìm và lọc trạng thái |
| `POST /admin/categories` | Quản trị | Tạo danh mục |
| `PATCH /admin/categories/:id` | Quản trị | Đổi tên hoặc trạng thái |
| `DELETE /admin/categories/:id` | Quản trị | Xoá; `409` nếu còn sản phẩm |
| `GET /admin/brands` | Quản trị | Danh sách thương hiệu |
| `POST /admin/brands` | Quản trị | Tạo thương hiệu |
| `PATCH /admin/brands/:id` | Quản trị | Đổi tên hoặc trạng thái |
| `DELETE /admin/brands/:id` | Quản trị | Xoá; `409` nếu còn sản phẩm |

@table Endpoint quản trị sản phẩm, biến thể và ảnh
| Phương thức và đường dẫn | Quyền | Mục đích |
| `GET /admin/products` | Quản trị | Danh sách đầy đủ, lọc trạng thái, danh mục, thương hiệu |
| `GET /admin/products/:id` | Quản trị | Chi tiết kèm biến thể và ảnh |
| `POST /admin/products` | Quản trị | Tạo sản phẩm |
| `PATCH /admin/products/:id` | Quản trị | Sửa sản phẩm, kể cả ẩn hoặc hiện |
| `DELETE /admin/products/:id` | Quản trị | Xoá cứng; `409` nếu đã có chứng từ tham chiếu |
| `POST /admin/products/:id/variants` | Quản trị | Thêm biến thể |
| `PATCH /admin/variants/:id` | Quản trị | Sửa SKU, kích cỡ, màu, giá |
| `DELETE /admin/variants/:id` | Quản trị | Xoá biến thể chưa bị tham chiếu |
| `GET /admin/variants` | Quản trị | Tìm biến thể theo SKU hoặc tên, phục vụ phiếu nhập |
| `POST /admin/products/:id/images` | Quản trị | Tải một ảnh, tối đa 5 ảnh mỗi sản phẩm |
| `DELETE /admin/products/:id/images/:imageId` | Quản trị | Xoá ảnh và tệp tương ứng |

@table Endpoint quản trị người dùng và đơn hàng
| Phương thức và đường dẫn | Quyền | Mục đích |
| `GET /admin/users` | Quản trị | Danh sách, tìm theo tên hoặc email, lọc vai trò, trạng thái |
| `PATCH /admin/users/:id/status` | Quản trị | Khoá hoặc mở khoá tài khoản |
| `GET /admin/orders` | Quản trị | Hàng đợi đơn, lọc trạng thái, từ khoá, khoảng ngày |
| `GET /admin/orders/:id` | Quản trị | Chi tiết đơn kèm giá vốn từng dòng |
| `PATCH /admin/orders/:id/status` | Quản trị | Chuyển trạng thái theo bảng hợp lệ |

@table Endpoint quản trị kho
| Phương thức và đường dẫn | Quyền | Mục đích |
| `POST /admin/inventory-receipts` | Quản trị | Tạo phiếu nhập nhiều dòng, cộng tồn trong một giao dịch |
| `GET /admin/inventory-receipts` | Quản trị | Danh sách phiếu, lọc theo khoảng ngày |
| `GET /admin/inventory-receipts/:id` | Quản trị | Chi tiết phiếu kèm các dòng |

@table Endpoint quản trị báo cáo
| Phương thức và đường dẫn | Quyền | Mục đích |
| `GET /admin/reports/revenue` | Quản trị | Doanh thu theo ngày hoặc tháng |
| `GET /admin/reports/top-products` | Quản trị | Sản phẩm bán chạy theo số lượng |
| `GET /admin/reports/orders-by-status` | Quản trị | Số đơn theo từng trạng thái |
| `GET /admin/reports/low-stock` | Quản trị | Biến thể dưới ngưỡng tồn |
| `GET /admin/reports/inventory-cost` | Quản trị | Tiền nhập, giá vốn hàng bán và lãi gộp |

@table Endpoint hệ thống
| Phương thức và đường dẫn | Quyền | Mục đích |
| `GET /health` | Công khai | Kiểm tra API sống; dùng trong script kiểm thử giao diện |
| `GET /uploads/...` | Công khai | Phục vụ tệp ảnh sản phẩm đã tải lên |
