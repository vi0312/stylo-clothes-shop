# 3. THIẾT KẾ CƠ SỞ DỮ LIỆU

## 3.1. Quy ước dữ liệu

Cơ sở dữ liệu gồm mười sáu bảng, đủ cho mười hai nhóm chức năng ở chương 2. Trước khi liệt kê từng
bảng, các quy ước dưới đây áp dụng cho toàn bộ lược đồ; chúng được chọn một lần để mọi bảng trông giống
nhau, thay vì mỗi bảng theo một kiểu.

@table Quy ước chung của lược đồ
| Quy tắc | Giá trị |
| Engine và bảng mã | InnoDB, `utf8mb4`, collation `utf8mb4_0900_ai_ci` (không phân biệt hoa thường và dấu) |
| Tên bảng | `snake_case` số ít, ánh xạ qua `@@map`; tên model `PascalCase` |
| Tên cột | `snake_case` qua `@map`; trường Prisma `camelCase` |
| Khoá chính | `id INT AUTO_INCREMENT`, không dùng UUID |
| Thời gian | `created_at`/`updated_at` kiểu `DATETIME(3)`, lưu UTC; ứng dụng hiển thị theo `Asia/Ho_Chi_Minh` |
| Tiền | `INT` đơn vị VND, không phần thập phân |
| Enum | `ENUM` gốc của MySQL, giá trị `SCREAMING_SNAKE_CASE` |
| Ẩn hay xoá | Hiển thị bằng cột `status`; xoá cứng chỉ khi không còn dòng nào tham chiếu (`RESTRICT`) |
| Từ khoá trùng | `order` là từ khoá của MySQL, nên mọi câu SQL thô phải viết `` `order` `` |

Bốn quy ước quan trọng nhất có ADR riêng vì chúng ảnh hưởng tới nhiều tầng: thanh toán theo từng lần
thử (ADR-0001), sổ cái tồn kho và việc trừ tồn lúc đặt hàng (ADR-0002), tiền là số nguyên VND
(ADR-0003), và đơn hàng lưu ảnh chụp dữ liệu tại thời điểm đặt (ADR-0004). Bốn quyết định này được
tóm tắt ở mục 3.8.

## 3.2. Sơ đồ thực thể liên kết

Sơ đồ dưới đây được sinh trực tiếp từ `server/prisma/schema.prisma` bằng một script đọc lược đồ, nên
nó không thể lệch khỏi cơ sở dữ liệu đang chạy: đổi tên một cột trong lược đồ là bước sinh lại sơ đồ
báo lỗi ngay. Bản in A3 nộp kèm là cùng một sơ đồ, phóng to.

@figure ../assets/erd.png|Sơ đồ thực thể liên kết của mười sáu bảng, sinh từ lược đồ Prisma

Sơ đồ chia thành bốn cụm theo tự nhiên. Cụm tài khoản gồm `user`, `refresh_token`, `address` và `cart`.
Cụm danh mục gồm `category`, `brand`, `product`, `product_variant` và `product_image`. Cụm bán hàng
gồm `order`, `order_item` và `payment`. Cụm kho gồm `inventory_receipt`, `inventory_receipt_item` và
`stock_movement`. Hai đường nối đáng chú ý: `order_item` trỏ tới cả `order` và `product_variant`, và
`stock_movement` trỏ tới `product_variant` cùng một cặp (`ref_type`, `ref_id`) trỏ về chứng từ sinh ra
nó. Cặp này là một tham chiếu mềm có chủ đích, vì một dòng sổ cái có thể đến từ đơn hàng hoặc từ phiếu
nhập kho, và khoá ngoại cứng sẽ buộc phải tách bảng.

## 3.3. Từ điển dữ liệu

Mười sáu bảng được nhóm theo cụm chức năng. Cột "Ràng buộc chính" chỉ nêu các ràng buộc quyết định hành
vi của hệ thống; các cột thời gian và khoá ngoại đơn giản được lược bớt cho dễ đọc.

@table Từ điển dữ liệu: nhóm tài khoản
| Bảng | Mục đích | Cột chính | Ràng buộc chính |
| `user` | Tài khoản đăng nhập | `email`, `password_hash`, `full_name`, `phone`, `role`, `status` | `email` duy nhất; `role` là `CUSTOMER` hoặc `ADMIN`; `status` là `ACTIVE` hoặc `DISABLED` |
| `refresh_token` | Refresh token đã băm | `user_id`, `token_hash`, `expires_at`, `revoked_at` | `token_hash` duy nhất; xoá theo `user` (`CASCADE`) |
| `address` | Địa chỉ nhận hàng | `user_id`, `recipient_name`, `phone`, `line`, `is_default` | Đúng một mặc định mỗi khách, service bảo đảm trong giao dịch |
| `cart` | Giỏ hàng của khách | `user_id` | Mỗi khách một giỏ |
| `cart_item` | Dòng giỏ hàng | `cart_id`, `variant_id`, `quantity` | Duy nhất theo (`cart_id`, `variant_id`) |

@table Từ điển dữ liệu: nhóm danh mục
| Bảng | Mục đích | Cột chính | Ràng buộc chính |
| `category` | Danh mục sản phẩm | `name`, `status` | `name` duy nhất; ẩn bằng `INACTIVE` |
| `brand` | Thương hiệu | `name`, `status` | `name` duy nhất; ẩn bằng `INACTIVE` |
| `product` | Mặt hàng trừu tượng | `name`, `description`, `category_id`, `brand_id`, `status` | Khoá ngoại `RESTRICT` tới danh mục và thương hiệu |
| `product_variant` | Đơn vị bán và đơn vị tồn kho | `product_id`, `sku`, `size`, `color`, `price`, `stock` | `sku` duy nhất; duy nhất theo (`product_id`, `size`, `color`); `price` và `stock` là số nguyên |
| `product_image` | Ảnh sản phẩm | `product_id`, `url`, `position` | Duy nhất theo (`product_id`, `position`); tối đa 5 ảnh mỗi sản phẩm ở tầng service |

@table Từ điển dữ liệu: nhóm bán hàng
| Bảng | Mục đích | Cột chính | Ràng buộc chính |
| `order` | Đơn hàng | `code`, `user_id`, `client_order_id`, `status`, `payment_method`, `paid_at`, `subtotal`, `shipping_fee`, `total` | `code` duy nhất; duy nhất theo (`user_id`, `client_order_id`); `paid_at` là nguồn sự thật của "đã thanh toán" |
| `order_item` | Dòng đơn hàng, ảnh chụp tại lúc đặt | `order_id`, `product_id`, `variant_id`, `product_name`, `variant_sku`, `size`, `color`, `unit_price`, `unit_cost`, `quantity` | Không cập nhật sau khi tạo; `unit_cost` có thể rỗng nếu biến thể chưa từng nhập |
| `payment` | Một lần thử thanh toán | `order_id`, `provider`, `status`, `amount`, `txn_ref`, `provider_txn_no`, `bank_code`, `pay_date`, `raw_response` | `txn_ref` duy nhất; mỗi lần thử một dòng; `status` là `PENDING`, `SUCCEEDED` hoặc `FAILED` |

@table Từ điển dữ liệu: nhóm kho
| Bảng | Mục đích | Cột chính | Ràng buộc chính |
| `inventory_receipt` | Phiếu nhập kho | `code`, `supplier`, `note`, `total_cost`, `created_by` | `code` dạng `PN-…`; bất biến sau khi lưu |
| `inventory_receipt_item` | Dòng phiếu nhập | `receipt_id`, `variant_id`, `quantity`, `unit_cost` | Lưu lịch sử giá nhập của từng biến thể |
| `stock_movement` | Sổ cái tồn kho | `variant_id`, `delta`, `reason`, `ref_type`, `ref_id`, `unit_cost` | Chỉ ghi thêm; mỗi thay đổi tồn có đúng một dòng |

Năm enum dưới đây được khai báo ở tầng cơ sở dữ liệu, không phải chuỗi tự do. Việc dùng enum gốc giúp
truy vấn báo cáo không phải xử lý giá trị lạ, nhưng cũng có giá: thêm một trạng thái mới cần một
migration có kiểm soát thay vì một dòng dữ liệu mới.

@table Các enum của lược đồ
| Enum | Giá trị | Dùng ở |
| `Role` | `CUSTOMER`, `ADMIN` | `user.role` |
| `UserStatus` | `ACTIVE`, `DISABLED` | `user.status` |
| `CatalogStatus` | `ACTIVE`, `INACTIVE` | `category`, `brand`, `product` |
| `OrderStatus` | `PENDING`, `CONFIRMED`, `SHIPPING`, `DELIVERED`, `CANCELLED` | `order.status` |
| `PaymentMethod` | `COD`, `ONLINE` | `order.payment_method` |
| `PaymentProvider` | `MOCK`, `VNPAY` | `payment.provider` |
| `PaymentStatus` | `PENDING`, `SUCCEEDED`, `FAILED` | `payment.status` |
| `StockMovementReason` | `RECEIPT`, `SALE`, `CANCEL_RESTOCK` | `stock_movement.reason` |
| `StockMovementRefType` | `RECEIPT`, `ORDER` | `stock_movement.ref_type` |

## 3.4. Sổ cái tồn kho

Tồn kho là chỗ một hệ thống bán hàng dễ sai nhất, nên nó được thiết kế theo nguyên tắc kế toán kép thu
nhỏ: cột `product_variant.stock` là số dư hiện tại, và mỗi lần số dư thay đổi đều sinh một dòng
`stock_movement` ghi lại `delta` (âm khi bán, dương khi nhập hoặc hoàn), lý do và chứng từ sinh ra nó.
Hai bất biến rút ra từ cách làm này, và cả hai đều được kiểm thử:

- Tổng `delta` của một biến thể bằng đúng `stock` hiện tại của nó.
- Mỗi dòng `stock_movement` thuộc đúng một chứng từ: một đơn hàng hoặc một phiếu nhập.

Sổ cái chỉ ghi thêm, không sửa và không xoá. Khi cần điều chỉnh, cách duy nhất là tạo một chứng từ
mới sinh ra dòng bù. Cách này khiến câu hỏi "vì sao tồn là 12" luôn trả lời được bằng một truy vấn
duy nhất trên sổ cái, thay vì phải suy đoán từ nhiều nguồn.

Ba lý do tồn thay đổi tương ứng với ba giá trị của `reason`: `RECEIPT` khi nhập hàng, `SALE` khi bán
(lúc tạo đơn), `CANCEL_RESTOCK` khi huỷ đơn. Việc trừ tồn xảy ra **lúc tạo đơn**, không phải lúc xác
nhận thanh toán: nếu chờ đến khi thanh toán xong mới trừ, hai khách có thể cùng mua món hàng cuối cùng.
Đây là nội dung của ADR-0002.

## 3.5. Các giao dịch then chốt

Bốn nghiệp vụ dưới đây chạy trong một giao dịch cơ sở dữ liệu. Chúng là phần dễ sinh dữ liệu không
nhất quán nhất, nên mỗi bước được nêu rõ thứ tự.

**Đặt hàng.** Giao dịch đọc các dòng giỏ, khoá các biến thể bằng `SELECT … FOR UPDATE` theo thứ tự
`id` tăng dần để tránh deadlock giữa hai lượt đặt hàng cùng chạm một biến thể, kiểm tra lại sản phẩm
còn `ACTIVE` và tồn đủ, tính tạm tính từ giá đã khoá, ghi đơn và các dòng đơn kèm ảnh chụp tên sản
phẩm, SKU, kích cỡ, màu, đơn giá và giá vốn; sau đó trừ tồn và ghi sổ cái cho từng dòng, xoá giỏ, và
với đơn online thì tạo dòng `payment` ở trạng thái `PENDING` kèm `txn_ref` mới. Toàn bộ nằm trong một
giao dịch, nên không có trạng thái trung gian nào quan sát được từ bên ngoài.

**Tạo phiếu nhập kho.** Ghi phiếu và các dòng, cộng tồn từng biến thể, ghi một dòng sổ cái mỗi dòng
phiếu với `reason = RECEIPT` và `unit_cost` của dòng. Phiếu không có endpoint sửa hay xoá.

**Huỷ đơn.** Khoá đơn bằng `SELECT … FOR UPDATE`, kiểm tra cặp trạng thái và điều kiện `paid_at` rỗng,
hoàn tồn và ghi sổ cái `CANCEL_RESTOCK` cho từng dòng, rồi đặt trạng thái `CANCELLED`. Bước khoá đơn
là bắt buộc: nếu hai yêu cầu huỷ đến cùng lúc mà không khoá, tồn sẽ được hoàn hai lần.

**Xác nhận thanh toán.** Tra `payment` theo `txn_ref`; nếu bản ghi đã `SUCCEEDED` thì trả lời thành
công mà không chạm vào đơn, vì cổng thanh toán có thể gọi lại nhiều lần. Ngược lại, kiểm tra số tiền,
đặt `payment.status = SUCCEEDED`, ghi `pay_date` và chuyển đơn sang `CONFIRMED` nếu đơn còn `PENDING`,
đồng thời ghi `paid_at`. Tính idempotent ở đây đến từ việc kiểm tra trạng thái bản ghi thanh toán, không
đến từ khoá ngoài.

## 3.6. Giá vốn và lãi gộp

Giá vốn của một biến thể tại thời điểm bán là **bình quân gia quyền** của các lần nhập trước đó, tính
bằng `SUM(quantity × unit_cost) / SUM(quantity)` trên các dòng phiếu nhập của biến thể. Kết quả được
làm tròn tới đồng và chép vào `order_item.unit_cost`, nên báo cáo lãi gộp của một đơn cũ không đổi khi
sau này cửa hàng nhập thêm hàng với giá khác.

Nếu biến thể chưa từng được nhập kho, `unit_cost` để rỗng thay vì gán 0. Lựa chọn này quan trọng: gán 0
sẽ khiến báo cáo lãi gộp báo lãi 100% cho những mặt hàng chưa có giá nhập, một con số sai theo hướng
lạc quan. Báo cáo chi phí vì vậy trả cả hai chỉ số: lãi gộp tính trên các dòng có giá vốn, và số dòng
thiếu giá vốn để người đọc biết độ tin cậy của con số.

Công thức lãi gộp của một kỳ là `revenue − cogs`, trong đó `revenue` là tổng `order.total` của các đơn
đã thanh toán trong kỳ và `cogs` là tổng `unit_cost × quantity` của các dòng thuộc các đơn đó. Cả hai
đều đọc theo `paid_at`, nên một đơn được ghi nhận doanh thu ở kỳ nào thì giá vốn cũng vào đúng kỳ đó.

## 3.7. Chỉ mục và truy vấn

Các chỉ mục được đặt theo truy vấn thật của ứng dụng, không theo phỏng đoán. Bảng dưới nêu những chỉ
mục không hiển nhiên.

@table Các chỉ mục phục vụ truy vấn thực tế
| Bảng | Chỉ mục | Truy vấn dùng nó |
| `product` | (`status`, `created_at`) | Danh sách sản phẩm đang bán, sắp mới nhất |
| `product_variant` | (`product_id`, `price`) | Sắp xếp theo giá trong một sản phẩm và lọc khoảng giá |
| `product_variant` | (`color`) | Bộ lọc màu trên toàn danh mục |
| `order` | (`user_id`, `created_at`) | Đơn của tôi, mới nhất trước |
| `order` | (`paid_at`) | Báo cáo doanh thu theo khoảng ngày |
| `order` | (`status`) | Báo cáo đơn theo trạng thái và hàng đợi xử lý |
| `stock_movement` | (`variant_id`, `created_at`) | Lịch sử tồn của một biến thể |
| `stock_movement` | (`ref_type`, `ref_id`) | Truy vết chứng từ sinh ra một thay đổi tồn |
| `refresh_token` | (`user_id`, `expires_at`) | Thu hồi token hết hạn của một người dùng |

Tìm kiếm theo tên dùng `LIKE '%…%'` trên cột `name` với chuỗi đã bỏ dấu ở cả hai phía; vì vậy người
dùng gõ "ao thun" vẫn tìm được "Áo thun basic". Với quy mô dữ liệu của đồ án (185 sản phẩm), cách này
nhanh hơn nhiều so với dựng một chỉ mục toàn văn, và nó không cần thêm thành phần hạ tầng nào. Nếu
danh mục lớn lên vài chục nghìn dòng, bước tiếp theo là một cột tên đã chuẩn hoá kèm chỉ mục, hoặc
chuyển sang `FULLTEXT` với bộ tách từ tiếng Việt.

## 3.8. Bốn quyết định miền

**ADR-0001 — thanh toán theo từng lần thử.** Một đơn có thể có nhiều bản ghi `payment`, mỗi lần thử một
bản ghi với `txn_ref` riêng. Lý do: cổng thanh toán thất bại thường do phía ngân hàng, và người dùng
cần thử lại mà không phải tạo đơn mới. Nếu mỗi đơn chỉ một bản ghi thanh toán thì lần thử thứ hai sẽ
ghi đè lịch sử của lần thứ nhất, làm mất dấu vết khi đối soát.

**ADR-0002 — sổ cái tồn kho và trừ tồn lúc đặt hàng.** Tồn là một cột, nhưng mọi thay đổi đều có dòng
sổ cái trong cùng giao dịch; tồn bị trừ ngay khi đơn được tạo. Lý do: trừ muộn cho phép bán quá tồn,
còn chỉ dùng sổ cái mà không có cột số dư thì mỗi lần đọc tồn phải cộng toàn bộ lịch sử.

**ADR-0003 — tiền là số nguyên VND.** Mọi cột tiền là `INT`, đơn vị đồng, không có phần lẻ. Lý do:
VND không dùng phần thập phân trong thực tế, và số nguyên loại bỏ hoàn toàn sai số làm tròn khi cộng
doanh thu. Đổi lại, hệ thống không biểu diễn được giá có phần lẻ; nếu cần, đó là một thay đổi lược đồ
có chủ đích chứ không phải một tuỳ chọn của từng bảng.

**ADR-0004 — đơn hàng lưu ảnh chụp.** Dòng đơn hàng chép lại tên sản phẩm, SKU, kích cỡ, màu, đơn giá
và giá vốn tại thời điểm đặt, đồng thời chép cả người nhận, số điện thoại và địa chỉ giao. Lý do: giá
đổi, sản phẩm đổi tên, địa chỉ bị sửa — nhưng hoá đơn của khách thì không được đổi theo. Vì vậy
`order` không có khoá ngoại tới `address`, và `order_item` giữ `product_name` dù vẫn trỏ tới
`product_id` để truy vết.
