# 4. THIẾT KẾ GIAO DIỆN

## 4.1. Định hướng thiết kế

Ứng dụng bán quần áo có một nghịch lý: người dùng đến để mua hàng, nhưng thứ họ nhìn nhiều nhất lại là
ảnh sản phẩm và giá. Giao diện vì vậy phải nhường chỗ cho ảnh, và mọi thành phần khác chỉ được phép
xuất hiện khi nó trả lời một câu hỏi của người mua. Ba nguyên tắc dưới đây dẫn dắt toàn bộ chương này.

**Ấm và tĩnh.** Bảng màu là ivory, mực và terracotta; chữ tiêu đề dùng serif, phần thân dùng sans. Lựa
chọn này khác với mặc định xanh–tím của Material 3, vì một cửa hàng quần áo cần cảm giác giấy và vải
chứ không phải cảm giác phần mềm doanh nghiệp. Chỉ có một theme sáng: không dark mode, không chuyển
theme động, vì mỗi theme thêm vào là một bộ ảnh và một bộ kiểm thử độ tương phản phải làm lại.

**Phẳng, phân tách bằng bề mặt.** Thẻ sản phẩm không có đổ bóng, không có viền. Việc phân tách dựa vào
chênh lệch độ sáng giữa thẻ và nền, và chênh lệch đó được đo chứ không được cảm nhận: thẻ trắng
`#FFFFFF` trên nền `#F6F1E8` đạt tỉ lệ tương phản 1.13:1, đủ nhận ra ranh giới; màu `#FBF8F1` chỉ đạt
1.06:1 nên không được dùng làm thẻ.

**Thuật ngữ thuần Việt.** Chuỗi hiển thị lấy từ bảng thuật ngữ của dự án: "Kích cỡ" chứ không phải
"Size", "Biến thể" trong ngữ cảnh quản trị, "Thêm S vào giỏ" thay cho "Thêm vào giỏ" để người dùng biết
mình đang mua kích cỡ nào. Tên model trong code (`Variant`, `ProductVariant`) không xuất hiện trên giao
diện.

## 4.2. Hệ thống thiết kế

Toàn bộ màu, chữ và hình dạng đi qua một theme duy nhất (`StyloTheme`). Không màn hình nào được đặt mã
màu trực tiếp; đổi một token là đổi cả ứng dụng.

### 4.2.1. Màu

Bảng dưới là các vai trò màu của Compose `ColorScheme` cùng giá trị hex. Cột "Dùng cho" chỉ ra nơi vai
trò đó thực sự xuất hiện, để tránh việc khai báo đủ vai trò rồi chỉ dùng ba màu.

@table Bảng màu của hệ thống thiết kế
| Vai trò | Hex | Dùng cho |
| `primary` / `onPrimary` | `#1E1C18` / `#FBF8F1` | Nút chính, chip đang chọn, tiêu đề |
| `secondary` / `onSecondary` | `#A6512B` / `#FFF6EF` | Nhấn mạnh thương hiệu, liên kết, giá khuyến mãi |
| `tertiary` / `onTertiary` | `#4F5E3F` / `#FFFFFF` | Trạng thái thành công, nhãn "Đang bán" |
| `error` / `onError` | `#B3261E` / `#FFFFFF` | Lỗi, hành động xoá, huỷ đơn |
| `background` / `onBackground` | `#F6F1E8` / `#1E1C18` | Nền toàn ứng dụng |
| `surface` / `onSurface` | `#FBF8F1` / `#1E1C18` | Thanh trên, thanh dưới, sheet |
| `surfaceContainerLowest` | `#FFFFFF` | Thẻ sản phẩm, thẻ KPI, thẻ đơn |
| `surfaceVariant` / `onSurfaceVariant` | `#EDE5D8` / `#6C6255` | Chip chưa chọn, nhãn phụ |
| `surfaceDim` | `#E9E3D8` | Khung xương khi tải |
| `outline` / `outlineVariant` | `#8F8069` / `#E8DFD1` | Viền control, đường phân cách |

Năm màu trạng thái (`success`, `warning`, `info`, `indigo`, `neutral`) không có trong `ColorScheme` của
Material 3, nên chúng được cung cấp qua một đối tượng riêng (`StyloStatusColors`) với cặp
`container`/`onContainer`. Nhờ vậy nhãn trạng thái đơn hàng có cùng một bộ màu ở mọi màn hình thay vì
mỗi nơi tự chọn.

### 4.2.2. Chữ

Hai họ chữ, không nhúng tệp font: serif hệ thống cho tiêu đề, sans hệ thống cho phần còn lại. Bảng dưới
là các token đang dùng; không màn hình nào đặt cỡ chữ trực tiếp.

@table Thang chữ của hệ thống thiết kế
| Vai trò | Token Compose | Cỡ / dòng | Kiểu |
| Hero trang chủ | `headlineMedium` | 28sp / 36sp | Serif, semibold |
| Tiêu đề màn hình, KPI | `headlineSmall` | 24sp / 30sp | Serif, semibold |
| Tiêu đề thẻ | `titleLarge` | 18sp / 24sp | Serif, semibold |
| Giá lớn | `titleMedium` | 16sp / 24sp | Sans, semibold |
| Giá thường | `titleSmall` | 14sp / 20sp | Sans, semibold |
| Thân bài | `bodyMedium` | 14sp / 20sp | Sans |
| Nút và chip | `labelLarge` | 14sp / 20sp | Sans, medium |
| Nhãn, metadata | `labelMedium` | 12sp / 16sp | Sans, medium |
| Overline | `labelSmall` | 11sp / 16sp | Sans, tracking 1.5sp |

Số tiền luôn dùng `Formatters.money` và nối ký hiệu `₫` bằng khoảng trắng không ngắt (NBSP), nên giá
không bao giờ bị tách dòng giữa số và đơn vị. Trên màn hình khách, số tiền viết đầy đủ; riêng thẻ KPI
của quản trị dùng "tr" cho gọn, và quy ước này được ghi trong tài liệu thiết kế để không ai phải đoán.

### 4.2.3. Khoảng cách, hình dạng, độ nổi

Lưới cơ sở là 4dp; lề ngang của trang là 20dp; khoảng cách giữa các section là 24dp, giữa các thẻ trong
lưới là 14dp, giữa các dòng trong một danh sách là 10–12dp. Thang bo góc: 4, 8, 12, 18, 24. Thẻ dùng
12, ảnh trong thẻ dùng 12, ảnh thu nhỏ dùng 8, ô nhập và menu dùng 8, chip và nút dùng bo tròn hoàn
toàn, hộp thoại và sheet dùng 24 (sheet chỉ bo hai góc trên).

Không dùng đổ bóng ở bất kỳ đâu. Phân cấp thị giác đến từ ba thứ: bề mặt (thẻ trắng trên nền ivory),
khoảng trắng, và trọng lượng chữ. Cách này giữ được giao diện nhẹ và tránh hiệu ứng "mọi thứ đều nổi"
thường thấy khi lạm dụng elevation.

### 4.2.4. Bộ thành phần dùng chung

Một phát hiện từ đợt đánh giá giao diện (mục 4.7) là các điều khiển giống nhau bị dựng lại ở nhiều màn
với ba bốn biến thể khác nhau. Sau khi sửa, mọi điều khiển lặp lại chỉ tồn tại ở một nơi, trong gói
`core/ui/components`; màn hình chỉ còn bố cục và trạng thái.

@table Các thành phần dùng chung và nơi chúng xuất hiện
| Thành phần | Vai trò | Xuất hiện ở |
| `StyloCard` | Bề mặt thẻ phẳng, bo 12, không viền | Trang chủ, danh sách, quản trị |
| `StyloSearchField` | Ô tìm kiếm dạng pill cao 48dp | Trang chủ, tìm kiếm, quản trị |
| `StyloFilterChip` | Chip lọc có trạng thái chọn kèm icon | Tìm kiếm, bộ lọc, quản trị |
| `StyloSwatch` | Ô màu tròn kèm tên màu | Chi tiết sản phẩm |
| `StyloSizeChip` | Chip kích cỡ | Chi tiết sản phẩm |
| `StyloQtyStepper` | Bộ tăng giảm số lượng, tự chặn ở tồn | Giỏ hàng, phiếu nhập |
| `StyloBusyButton` | Nút có trạng thái đang xử lý | Đăng nhập, đặt hàng, lưu |
| `StyloStickyCta` | Thanh dưới cố định: giá bên trái, nút bên phải | Chi tiết, giỏ, thanh toán |
| `StyloStatusBadge` | Nhãn trạng thái theo bộ màu chung | Đơn hàng, sản phẩm, người dùng |
| `StyloListSkeleton` | Khung xương khi tải | Mọi danh sách |
| `StyloEmptyState` | Trạng thái rỗng kèm hành động | Giỏ, đơn, danh sách quản trị |
| `StyloErrorState` | Trạng thái lỗi kèm nút thử lại | Mọi màn tải dữ liệu |
| `StyloInlineError` | Lỗi ngay dưới ô nhập | Biểu mẫu |
| `StyloConfirmDialog` | Hộp thoại xác nhận hành động không hoàn tác | Huỷ đơn, đăng xuất, xoá |

### 4.2.5. Trạng thái chung

Bốn trạng thái dữ liệu được thiết kế một lần và dùng lại: **đang tải** là khung xương có đúng số thẻ
của lưới, không phải vòng xoay giữa màn hình; **rỗng** là một câu giải thích cùng một hành động
("Chưa có đơn hàng" kèm nút về trang chủ); **lỗi** là thông điệp tiếng Việt đọc từ mã lỗi của API kèm
nút "Thử lại"; **lỗi cục bộ** nằm ngay dưới ô nhập và không đẩy cả biểu mẫu đi. Việc ánh xạ mã lỗi
sang câu tiếng Việt nằm ở một chỗ duy nhất (`ErrorMessages`), nên API đổi mã lỗi sẽ lộ ra ngay chứ
không âm thầm hiển thị câu cũ.

## 4.3. Điều hướng theo vai trò

Phía khách có năm tab dưới: Trang chủ, Tìm kiếm, Giỏ hàng, Đơn hàng, Tôi. Năm tab này phản ánh đúng
năm việc người mua làm, và giỏ hàng có huy hiệu số lượng để trả lời câu hỏi "tôi đã thêm gì rồi".

@figure figures/01-home.png|Trang chủ: hero, chip danh mục, dải miễn phí giao hàng và hai khối sản phẩm

Phía quản trị giữ bốn tab vận hành thường ngày (Tổng quan, Đơn hàng, Sản phẩm, Kho) và đưa các mục ít
dùng hơn (Danh mục & thương hiệu, Người dùng, Báo cáo, Đăng xuất) vào một ngăn kéo mở từ góc trên.
Lý do: người quản trị mở ứng dụng hàng chục lần mỗi ngày để xử lý đơn và kiểm tra tồn, nhưng rất ít
khi mở báo cáo; đặt báo cáo ngang hàng với đơn hàng sẽ làm chậm việc thường ngày.

Điều hướng được mount theo vai trò: đồ thị quản trị chỉ tồn tại khi tài khoản là `ADMIN`, và khi đổi
tab quản trị, trạng thái cuộn cùng bộ lọc của tab cũ được lưu lại. Người dùng không thấy màn hình quản
trị bị chớp qua khi đăng nhập bằng tài khoản khách.

## 4.4. Màn hình phía khách

### 4.4.1. Đăng nhập và đăng ký

Một màn hình hai chế độ, chuyển bằng segmented control. Đăng nhập chỉ hỏi email và mật khẩu; đăng ký
hỏi thêm họ tên và số điện thoại (không bắt buộc). Mọi lỗi đăng nhập đều trả về cùng một câu "Email
hoặc mật khẩu không đúng" để không tiết lộ email nào đã tồn tại; lỗi đăng ký thì chỉ rõ từng ô. Nút
gửi có trạng thái đang xử lý, và bàn phím không che nút nhờ cuộn được.

@figure figures/11-register.png|Biểu mẫu đăng ký với bốn ô và nút tạo tài khoản

### 4.4.2. Trang chủ

Bố cục A: hero toàn chiều rộng, dải chip danh mục, carousel "Mới về" tám sản phẩm, dải miễn phí giao
hàng, rồi hai khối danh mục "Áo" và "Quần", mỗi khối bốn sản phẩm kèm liên kết "Xem tất cả". Trang chủ
không cần đăng nhập và không có section "bán chạy": API không cung cấp sắp xếp theo số bán, nên dựng
một section như vậy sẽ phải bịa dữ liệu.

@figure figures/02-home-collections.png|Trang chủ sau khi cuộn: carousel "Mới về" và hai khối danh mục

### 4.4.3. Tìm kiếm và lọc

Màn hình tìm kiếm là một ô tìm kiếm dính trên, dải chip danh mục, nút "Bộ lọc", bộ chọn sắp xếp, dòng
đếm kết quả và lưới hai cột. Bộ lọc mở trong một sheet từ dưới lên, gồm danh mục, thương hiệu, màu,
kích cỡ và khoảng giá; nút "Áp dụng" nằm cuối sheet và chỉ đóng sheet khi bộ lọc đã được gửi đi.

@figure figures/03-catalog.png|Màn hình tìm kiếm với chip danh mục, sắp xếp và lưới hai cột

Tìm kiếm không phân biệt dấu: gõ "ao thun" khớp "Áo thun basic". Bộ lọc kết hợp được với nhau và với
từ khoá, vì tất cả đi trong một yêu cầu duy nhất tới `GET /products`.

@figure figures/04-catalog-search.png|Kết quả cho từ khoá "ao thun": 39 sản phẩm, không cần gõ dấu

@figure figures/05-filter-sheet.png|Bộ lọc dạng sheet: danh mục, thương hiệu, màu sắc

### 4.4.4. Chi tiết sản phẩm

Trang chi tiết là nơi giao diện phải trả lời ba câu hỏi liên tiếp: món này trông thế nào, còn kích cỡ
nào, và giá của đúng biến thể đang chọn là bao nhiêu. Vì vậy thứ tự các khối là ảnh, thông tin và giá,
chọn màu, chọn kích cỡ, tồn kho của biến thể, rồi mô tả. Giá và tồn cập nhật ngay khi đổi biến thể; khi
tồn xuống thấp, nhãn chuyển sang màu cảnh báo kèm chữ "(tồn thấp)".

@figure figures/08-detail-top.png|Chi tiết sản phẩm: ảnh, thương hiệu, tên và giá

@figure figures/09-detail-variants.png|Chọn màu và kích cỡ; tồn kho hiển thị theo biến thể đang chọn

Nút mua ở thanh dưới luôn nêu kích cỡ đang chọn ("Thêm M vào giỏ"), một quyết định đến từ đợt đánh giá
giao diện: nút chỉ ghi "Thêm vào giỏ" khiến người dùng không chắc mình đã chọn đúng cỡ hay chưa.

### 4.4.5. Giỏ hàng

Mỗi dòng giỏ hiển thị ảnh, tên, tổ hợp màu và kích cỡ, đơn giá, bộ tăng giảm số lượng và nút xoá. Bộ
tăng giảm tự chặn ở số lượng tồn và hiện nhãn "Tối đa" khi chạm trần, nên người dùng biết vì sao không
tăng được nữa thay vì thấy nút im lặng. Thanh dưới hiển thị tạm tính và nút thanh toán; phí vận chuyển
được nêu rõ là tính ở bước sau.

@figure figures/18-cart.png|Giỏ hàng với một dòng, bộ tăng giảm và tạm tính

@figure figures/19-cart-quantity.png|Tăng số lượng ngay trong giỏ; nút tự dừng khi chạm tồn của biến thể

### 4.4.6. Thanh toán và kết quả

Màn hình thanh toán gồm địa chỉ nhận (kèm nút "Đổi"), danh sách sản phẩm rút gọn, hai phương thức thanh
toán, ô ghi chú không bắt buộc và thanh dưới chứa tổng tiền. Nút đặt hàng ghi cả số tiền để người dùng
không phải nhớ.

@figure figures/20-checkout.png|Thanh toán: địa chỉ, sản phẩm, phương thức COD hoặc online

Với COD, đơn được tạo ngay và mở trang chi tiết đơn ở trạng thái "Chờ xác nhận". Với thanh toán online,
ứng dụng mở cổng thanh toán trong trình duyệt; khi quay lại, trạng thái đơn được đọc lại từ server chứ
không tin vào tham số trên đường dẫn.

@figure figures/21-order-detail-new.png|Chi tiết đơn vừa đặt, có thanh trạng thái bốn mốc

### 4.4.7. Đơn hàng

Danh sách đơn chia theo bốn tab trạng thái, mỗi thẻ nêu mã đơn, thời điểm, số món, trạng thái và tổng
tiền. Chi tiết đơn hiển thị thanh tiến trình bốn mốc, sản phẩm, địa chỉ giao và tạm tính; hành động huỷ
chỉ xuất hiện khi đơn còn huỷ được.

@figure figures/22-orders-list.png|Danh sách đơn hàng của tôi theo tab trạng thái

### 4.4.8. Hồ sơ và địa chỉ

Hồ sơ cho sửa họ tên và số điện thoại, email chỉ đọc. Danh sách địa chỉ đánh dấu rõ địa chỉ mặc định,
mỗi dòng có "Sửa", "Xoá" và "Đặt làm mặc định"; biểu mẫu thêm địa chỉ gồm người nhận, số điện thoại và
một dòng địa chỉ tự do.

@figure figures/12-profile.png|Hồ sơ khách hàng: thông tin, địa chỉ, đăng xuất

@figure figures/13-address-list.png|Danh sách địa chỉ với địa chỉ mặc định được đánh dấu

Một dòng địa chỉ tự do thay vì ba ô chọn tỉnh/quận/phường là lựa chọn có chủ đích: bộ dữ liệu hành
chính ba cấp cần dữ liệu nguồn và luôn lệch sau mỗi lần sáp nhập đơn vị hành chính, trong khi đồ án chỉ
cần một địa chỉ đủ để giao hàng.

## 4.5. Màn hình phía quản trị

### 4.5.1. Tổng quan

Bốn thẻ KPI (doanh thu, số đơn, giá trị đơn trung bình, số biến thể tồn thấp), biểu đồ cột doanh thu
bảy ngày, danh sách sản phẩm bán chạy và đơn gần đây. Biểu đồ có nhãn đọc cho trình đọc màn hình, liệt
kê từng ngày kèm doanh thu và số đơn, nên thông tin không chỉ tồn tại dưới dạng hình.

@figure figures/23-admin-dashboard.png|Tổng quan quản trị: bốn KPI và biểu đồ doanh thu bảy ngày

### 4.5.2. Sản phẩm

Danh sách sản phẩm có tìm kiếm, bộ lọc trạng thái (Tất cả, Đang bán, Đã ẩn, Tồn thấp) và bộ lọc danh
mục, thương hiệu. Mỗi dòng nêu số biến thể và khoảng giá. Biểu mẫu sản phẩm gồm tên, mô tả, danh mục,
thương hiệu và trạng thái; biến thể và ảnh được quản lý ở màn hình riêng của sản phẩm.

@figure figures/28-admin-products.png|Danh sách sản phẩm quản trị với trạng thái và số biến thể

@figure figures/29-admin-product-form.png|Biểu mẫu thêm sản phẩm

### 4.5.3. Đơn hàng

Hàng đợi đơn chia tab theo trạng thái, lọc nhanh theo thời gian (hôm nay, 7 ngày, 30 ngày). Chi tiết đơn
của quản trị nhiều hơn của khách hai phần: giá vốn từng dòng, và khối "Xử lý đơn" chứa các hành động
hợp lệ với trạng thái hiện tại. Mỗi hành động mở hộp thoại xác nhận nêu rõ cặp trạng thái sẽ chuyển,
ví dụ "Chờ xác nhận → Đã xác nhận", để thao tác không thể nhầm.

@figure figures/24-admin-orders.png|Hàng đợi đơn hàng của quản trị

@figure figures/26-admin-order-confirm-dialog.png|Hộp thoại xác nhận chuyển trạng thái

### 4.5.4. Kho và phiếu nhập

Màn hình kho liệt kê phiếu nhập và tồn thấp. Phiếu nhập nhiều dòng: mỗi dòng chọn biến thể, số lượng và
đơn giá nhập; tổng tiền phiếu cộng dần khi thêm dòng. Sau khi lưu, phiếu không sửa được nữa, đúng như
quy tắc nghiệp vụ ở chương 2.

@figure figures/30-admin-inventory.png|Kho: danh sách phiếu nhập và biến thể tồn thấp

### 4.5.5. Báo cáo

Năm báo cáo nằm trong một màn hình, chuyển bằng segmented control, dùng chung một bộ chọn khoảng ngày.
Báo cáo doanh thu có thêm lựa chọn nhóm theo ngày hoặc theo tháng. Biểu đồ luôn kèm bảng số liệu bên
dưới, nên người đọc có thể lấy số chính xác mà không phải ước lượng từ cột.

@figure figures/31-report-revenue.png|Báo cáo doanh thu theo khoảng ngày

@figure figures/33-report-low-stock.png|Báo cáo tồn thấp theo ngưỡng

### 4.5.6. Người dùng và danh mục

Danh sách người dùng có tìm kiếm theo tên hoặc email, nhãn vai trò và trạng thái, cùng hành động khoá
hoặc mở khoá kèm hộp thoại xác nhận. Danh mục và thương hiệu dùng chung một kiểu màn hình: danh sách
kèm trạng thái và biểu mẫu thêm mới.

@figure figures/35-admin-users.png|Quản lý người dùng với trạng thái và hành động khoá

## 4.6. Khả năng tiếp cận

Ba yêu cầu được kiểm tra trên từng màn hình thay vì chỉ ghi trong tài liệu. **Tương phản**: mọi cặp
chữ/nền đạt tối thiểu 4.5:1 cho chữ thường và 3:1 cho chữ lớn; viền control dùng `outline` đạt 3.63:1
trên nền `surface`, 3.42:1 trên `background` và 3.08:1 trên `surfaceVariant`, đủ cho yêu cầu 3:1 của
WCAG 1.4.11; màu `outlineVariant` không được dùng làm viền control vì chỉ đạt 1.28:1. **Không chỉ dựa
vào màu**: chip đang chọn có thêm icon kiểm, trạng thái đơn có nhãn chữ, tồn thấp có chữ "(tồn thấp)"
bên cạnh màu cảnh báo. **Vùng chạm**: mọi nút và chip cao tối thiểu 48dp; danh sách giữ nguyên kích
thước khi phóng to chữ hệ thống nhờ dùng `sp` và bố cục co giãn.

## 4.7. Đợt đánh giá và những gì đã thay đổi

Sau khi hoàn thiện các màn hình, một đợt đánh giá có hệ thống được chạy trên hai mươi mốt màn hình, đối
chiếu với tài liệu thiết kế và Material 3. Kết quả: ba lỗi mức P0, hai mươi bốn mức P1 và khoảng ba
mươi mức P2. Nguyên nhân gốc của phần lớn lỗi không phải từng màn hình riêng lẻ mà là việc thiếu một
lớp thành phần dùng chung: mỗi màn tự dựng chip, thẻ và nhãn trạng thái theo cách riêng, nên sửa một
lỗi ở một màn không lan sang các màn còn lại.

Sáu quyết định được chốt và thi công trong một lần sửa (ADR-0016): thẻ dùng `surfaceContainerLowest`
thay vì `surface`; bỏ đổ bóng và viền khỏi thẻ; đưa mọi điều khiển lặp lại vào lớp thành phần chung;
thay menu tràn của quản trị bằng ngăn kéo; bỏ chỉ số "Đã bán N" vì API không có endpoint tổng hợp; và
đổi nhãn nút mua để nêu kích cỡ. Sau khi sửa, giao diện chỉ còn một cách hiển thị cho mỗi loại điều
khiển, và các màn hình đều dùng chung bốn trạng thái dữ liệu ở mục 4.2.5.
