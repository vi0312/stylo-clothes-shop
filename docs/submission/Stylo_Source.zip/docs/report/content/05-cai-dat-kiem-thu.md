# 5. CÀI ĐẶT VÀ KIỂM THỬ

## 5.1. Kiến trúc tổng thể

Kho mã nguồn gồm hai dự án build độc lập và một thư mục tài liệu dùng chung:

```
stylo-clothing-store/
├── android/        ứng dụng Android, một module Gradle
├── server/         API Node.js, Prisma, MySQL
├── docs/           đặc tả, ADR, tài liệu thiết kế
└── GLOSSARY.md     thuật ngữ dùng xuyên suốt
```

Hai dự án không chia sẻ mã. Chúng chia sẻ một thứ duy nhất: hợp đồng API. Đây là lựa chọn có chủ đích
cho một đồ án một người, vì nó biến mọi thay đổi giao diện thành thay đổi cục bộ và buộc mọi thay đổi
dữ liệu phải đi qua một chỗ có kiểm thử. Đường đi của một yêu cầu điển hình: màn hình Compose gọi
ViewModel, ViewModel gọi repository, repository gọi API qua Retrofit; phía server, route kiểm tra đầu
vào bằng Zod, gọi service, service mở giao dịch và gọi repository, repository nói chuyện với Prisma.

## 5.2. Phía server

### 5.2.1. Công nghệ và phiên bản

@table Thành phần phía server
| Thành phần | Phiên bản | Vai trò |
| Node.js | 24 | Môi trường chạy, yêu cầu tối thiểu 22.12 |
| Express | 5.3.0 | Định tuyến HTTP |
| Prisma | 7.10.1 | ORM và migration, client sinh từ lược đồ |
| Prisma adapter MariaDB | 7.10.1 | Driver thật cho MySQL 8.4 |
| MySQL | 8.4 | Cơ sở dữ liệu, chạy trong container |
| Zod | 4.6.7 | Kiểm tra và kiểu hoá dữ liệu vào |
| argon2 | 0.45.2 | Băm mật khẩu |
| Vitest | 5.1 | Kiểm thử đơn vị và tích hợp |
| Supertest | 7.3 | Gọi HTTP trong kiểm thử, không mở cổng |

### 5.2.2. Luật module

Mỗi nhóm chức năng nằm trong một thư mục với bốn loại tệp có trách nhiệm tách bạch: `*.routes.ts` đọc
HTTP và gọi đúng một hàm service; `*.service.ts` giữ quy tắc nghiệp vụ, mở giao dịch và quyết định mã
lỗi; `*.repository.ts` chỉ chứa truy vấn Prisma; `*.schema.ts` chứa Zod schema của đầu vào. Ba luật đi
kèm, và cả ba đều được kiểm bằng cách đọc mã khi review: service không import kiểu của Express,
repository không bao giờ ném lỗi nghiệp vụ, và kiểu đầu vào chỉ được suy ra từ Zod (`z.infer`). Nhờ
vậy không có hai nguồn sự thật cho hình dạng dữ liệu vào.

Module xuất hàm thuần, không dùng lớp và không có container DI ở server. Điều này giữ đường gọi ngắn:
route nhìn thấy service, service nhìn thấy repository, repository nhìn thấy một Prisma client duy nhất.

### 5.2.3. Mô hình lỗi

Mọi lỗi trả về cùng một hình dạng: `{ error: { code, message, details? } }`. `code` là hằng ổn định
(`VALIDATION_FAILED`, `OUT_OF_STOCK`, `INVALID_ORDER_STATE`, `ACCOUNT_DISABLED`, …), `message` là câu
tiếng Anh dành cho log và lập trình viên, `details` có hình dạng cố định theo từng mã. Ứng dụng Android
dịch `code` sang tiếng Việt và không bao giờ đọc `message`; nhờ vậy đổi câu chữ ở server không làm hỏng
giao diện, còn thêm một mã lỗi mới thì buộc phải thêm một chuỗi tiếng Việt.

Một điểm kỹ thuật đáng ghi lại: khi dùng Prisma với driver MariaDB, lỗi khoá ngoại và lỗi trùng khoá
đến thẳng từ driver dưới dạng mã `ER_ROW_IS_REFERENCED_2`, `ER_NO_REFERENCED_ROW_2`, `ER_DUP_ENTRY`,
không phải lúc nào cũng thành `P2002`/`P2003` của Prisma. Vì vậy service kiểm tra cả hai họ mã trước khi
quyết định trả `IN_USE` hay `CONFLICT`; nếu chỉ kiểm tra mã Prisma, người dùng sẽ nhận lỗi 500 ở đúng
những tình huống đã được thiết kế để trả lỗi 409.

### 5.2.4. Cấu hình và chạy

Cấu hình đọc từ biến môi trường và được kiểm bằng Zod ngay khi khởi động, nên thiếu biến bắt buộc là
lỗi rõ ràng lúc chạy chứ không phải lỗi khó hiểu về sau. Cổng mặc định của API là 8787; lý do chọn cổng
này là cổng 3000 trên máy phát triển đã bị một ứng dụng khác chiếm. Android bản debug trỏ tới
`http://127.0.0.1:8787` và đi qua cầu `adb reverse`, nên máy ảo gọi được API trên máy thật mà không cần
cấu hình mạng.

## 5.3. Hợp đồng API

### 5.3.1. Quy ước

@table Quy ước của hợp đồng API
| Quy tắc | Giá trị |
| Đường dẫn gốc | `/api/v1` |
| Tên trường | `camelCase` trong JSON; `snake_case` chỉ trong cơ sở dữ liệu |
| Tiền | Số nguyên VND, không chuỗi, không phần thập phân |
| Thời gian | ISO-8601 UTC kèm mili giây |
| Ngày lịch | `YYYY-MM-DD`, hiểu theo `Asia/Ho_Chi_Minh` |
| Giá trị thiếu | Trường vẫn có mặt với `null`, không bị bỏ |
| Trường lạ trong body | Bị từ chối bằng `VALIDATION_FAILED` |
| Thành công | Trả chính tài nguyên, hoặc `{ items, page, limit, total }` cho danh sách |
| Phân trang | `page` từ 1, `limit` 1–100, mặc định 20; `total` là tổng số dòng khớp |
| Sắp xếp | Mỗi endpoint có tập giá trị `sort` riêng; luôn kết thúc bằng `id` để ổn định |
| Xác thực | `Authorization: Bearer <accessToken>` |

### 5.3.2. Nhóm endpoint

Toàn bộ danh sách endpoint nằm ở phụ lục A; bảng dưới chỉ nêu nhóm và số lượng để thấy mức phủ.

@table Các nhóm endpoint của API
| Nhóm | Endpoint | Ghi chú |
| Xác thực và hồ sơ | 6 | Đăng ký, đăng nhập, làm mới, đăng xuất, xem và sửa hồ sơ |
| Địa chỉ | 4 | Danh sách, thêm, sửa, xoá; đặt mặc định qua `PATCH` |
| Danh mục công khai | 3 | Danh sách sản phẩm, chi tiết, bộ lọc |
| Giỏ hàng | 5 | Xem, thêm, sửa, xoá dòng, xoá tất cả |
| Đơn hàng | 4 | Đặt, danh sách, chi tiết, huỷ |
| Thanh toán | 4 | Tạo giao dịch, tra giao dịch, hai endpoint cho cổng |
| Quản trị | 30 | Danh mục, thương hiệu, sản phẩm, biến thể, ảnh, đơn, kho, người dùng, báo cáo |

### 5.3.3. Hai cơ chế bảo vệ

**Idempotency khi đặt hàng.** Mỗi lần bấm đặt hàng, ứng dụng sinh một `clientOrderId` và gửi kèm.
Server lưu cặp (`user_id`, `client_order_id`) là duy nhất; nếu nhận lại cùng cặp, server trả về đơn đã
tạo thay vì tạo đơn thứ hai. Cơ chế này giải quyết tình huống thực tế nhất của mạng di động: yêu cầu
đến được server, phản hồi bị mất, người dùng bấm lại. Không có nó, mỗi lần mạng chập chờn là một đơn
hàng và một lần trừ tồn.

**Xác nhận thanh toán muộn.** Với thanh toán online, trạng thái đơn không được đặt từ tham số trên
đường dẫn trình duyệt quay về, vì tham số đó do phía client mang tới. Server xác minh chữ ký và số tiền
với dữ liệu giao dịch đã lưu rồi mới đổi trạng thái (ADR-0007). Điều này quan trọng ở môi trường sandbox
nơi IPN không gọi được vào máy nội bộ: vẫn có một đường xác nhận đúng, thay vì tin vào URL.

## 5.4. Phía Android

### 5.4.1. Kiến trúc và thư viện

Một module `:app`, `minSdk 26`, `compileSdk` và `targetSdk` 36, Java 17. Mô hình MVVM cộng repository;
mỗi feature là một gói gồm `ui`, `domain` (nếu có) và `data`. Trạng thái màn hình là một `data class`
bất biến, hiệu ứng một lần (điều hướng, snackbar) đi qua kênh riêng, và ViewModel chỉ phát ra dữ liệu —
không chuỗi tiếng Việt nào nằm trong ViewModel.

@table Thành phần phía Android
| Thành phần | Phiên bản | Vai trò |
| Kotlin | 2.3.21 | Ngôn ngữ |
| Android Gradle Plugin | 8.13.2 | Build |
| Compose BOM | 2026.03.00 | Bộ thư viện UI |
| Hilt | 2.58 | Tiêm phụ thuộc |
| Navigation Compose | 2.9.6 | Điều hướng |
| Retrofit | 3.0.0 + OkHttp 4.12 | Tầng mạng |
| kotlinx.serialization | 1.12.0 | JSON |
| Coil | 3.0.4 | Tải ảnh |
| DataStore | 1.2.0 | Lưu token |
| Kaspresso | 1.6.1 | Kiểm thử giao diện |

### 5.4.2. Tầng mạng và phiên đăng nhập

Mọi lời gọi API trả về một kiểu kết quả có ba nhánh: thành công, lỗi nghiệp vụ (đã dịch sang mã và
thông điệp), và lỗi hạ tầng (mạng, timeout). Nhờ vậy ViewModel không phải bắt ngoại lệ, và lỗi mạng
không bị hiển thị như lỗi nghiệp vụ.

Access token sống 15 phút; refresh token 30 ngày và được xoay mỗi lần dùng. Một interceptor gắn token
vào mỗi yêu cầu; một authenticator chặn lời gọi khi gặp 401, làm mới token đúng một lần cho nhiều yêu
cầu song song, rồi chạy lại yêu cầu ban đầu. Nếu làm mới thất bại, phiên bị xoá và người dùng về màn
hình đăng nhập. Token được lưu trong DataStore, không lưu trong bộ nhớ tĩnh.

### 5.4.3. Tầng giao diện

Một theme duy nhất, một lớp thành phần dùng chung (chương 4). Điều hướng mount theo vai trò: đồ thị
quản trị chỉ được thêm vào khi vai trò là `ADMIN`. Các danh sách dùng `LazyColumn` với khoá ổn định, và
trạng thái cuộn của tab được lưu khi đổi tab.

Điểm đáng nêu vì nó là nguồn lỗi phổ biến: ứng dụng không giữ bản sao dữ liệu trong ViewModel lâu hơn
màn hình. Sau khi đặt hàng, giỏ được đọc lại từ server thay vì xoá cục bộ; sau khi huỷ đơn, danh sách
đơn được tải lại. Cách này đắt hơn một chút về số lời gọi nhưng loại bỏ hoàn toàn lớp lỗi "giao diện
nói một đằng, server nói một nẻo".

## 5.5. Thanh toán

### 5.5.1. Ranh giới trừu tượng

Cổng thanh toán nằm sau một interface duy nhất (`PaymentGateway`) với hai hiện thực: `MockGateway` và
`VNPayGateway`. Chọn cổng bằng biến môi trường `PAYMENT_PROVIDER`. Service đặt hàng không biết cổng nào
đang chạy; nó chỉ tạo dòng `payment` và hỏi cổng lấy URL thanh toán. Nhờ vậy môi trường phát triển và
demo dùng cổng mock, còn sandbox dùng VNPay, mà không có nhánh `if` nào trong nghiệp vụ.

### 5.5.2. Cổng mock

Cổng mock dựng một trang HTML do chính API phục vụ, hiển thị số tiền và hai lựa chọn "thanh toán thành
công" hoặc "thanh toán thất bại". Mỗi lựa chọn gọi endpoint xác nhận của mock với đúng `txn_ref` của
giao dịch. Trang này là công cụ demo: nó cho thấy toàn bộ đường đi của thanh toán — tạo giao dịch, mở
trình duyệt, xác nhận, quay lại ứng dụng — mà không phụ thuộc dịch vụ ngoài.

### 5.5.3. Cổng VNPay

Adapter VNPay dựng URL thanh toán theo đặc tả sandbox: sắp xếp tham số theo tên, nối thành chuỗi truy
vấn, ký bằng HMAC-SHA512 với khoá bí mật, và đính kèm chữ ký. Chiều ngược lại, khi cổng gọi về, adapter
kiểm tra chữ ký trên toàn bộ tham số nhận được, đối chiếu số tiền với dòng `payment` đã lưu, rồi mới
xác nhận.

Giới hạn đã biết: IPN của VNPay không gọi được vào một server chạy trên máy cá nhân không có địa chỉ
công cộng, nên đường xác nhận trong demo là đường quay về trình duyệt kèm kiểm tra chữ ký. Đây không
phải chỗ đánh đổi chất lượng: chữ ký vẫn được kiểm, số tiền vẫn được đối chiếu, và bản ghi giao dịch
vẫn là nguồn sự thật. Chỉ khác là thông báo đến sớm hay muộn mà thôi.

@figure figures/21-order-detail-new.png|Đơn hàng sau khi đặt: trạng thái, sản phẩm, địa chỉ, tạm tính

## 5.6. Năm báo cáo

Báo cáo là phần dễ sai lệch nhất giữa "con số trên màn hình" và "con số trong cơ sở dữ liệu", nên mỗi
báo cáo được định nghĩa bằng cột ngày dùng để lọc và bằng công thức, không bằng cảm nhận.

@table Định nghĩa năm báo cáo
| Báo cáo | Cột ngày | Công thức | Ghi chú |
| Doanh thu | `order.paid_at` | Tổng `order.total` của đơn đã thanh toán trong kỳ | Gồm phí vận chuyển; lọc theo ngày Việt Nam |
| Sản phẩm bán chạy | `order.paid_at` | Tổng `quantity` theo sản phẩm, sắp giảm dần | Cùng tập đơn với báo cáo doanh thu |
| Đơn theo trạng thái | `order.created_at` | Đếm đơn theo từng trạng thái | Đủ năm trạng thái, kể cả trạng thái không có đơn |
| Tồn thấp | không có | Các biến thể có `stock` dưới ngưỡng | Là ảnh chụp hiện tại, không phải theo kỳ |
| Chi phí và lãi | `paid_at` cho giá vốn, `inventory_receipt.created_at` cho tiền nhập | `revenue − cogs`, kèm tổng tiền nhập | Hai dòng tiền khác nhau nên tách cột |

Ba quy tắc áp dụng cho cả năm: khoảng ngày là bao gồm hai đầu và hiểu theo giờ Việt Nam (UTC+7, không
có giờ mùa hè); kỳ trả về luôn được lấp đầy, tức mọi ngày trong khoảng đều có mặt kể cả ngày không có
đơn, để biểu đồ không bị co lại thành những cột dồn cục; và việc lấp đầy làm ở tầng service chứ không
ở SQL, để truy vấn giữ được chỉ mục.

Doanh thu của đơn COD ghi nhận ở ngày giao, không phải ngày đặt. Đây là hệ quả trực tiếp của định nghĩa
"doanh thu là tiền đã nhận", và nó được kiểm thử bằng một đơn đặt trước nhưng giao sau, nằm ở hai kỳ
khác nhau.

## 5.7. Chiến lược kiểm thử

### 5.7.1. Bốn tầng

@table Các tầng kiểm thử
| Tầng | Công cụ | Phạm vi | Mục tiêu thời gian |
| Đơn vị backend | Vitest, không cơ sở dữ liệu | Hàm thuần: tiền, chuyển trạng thái, ngày, chữ ký VNPay | dưới 5 giây |
| Tích hợp backend | Vitest + Supertest + MySQL thật | Đường HTTP, service, giao dịch, SQL, sổ cái | dưới 60 giây |
| JVM Android | JUnit4, coroutines-test, Turbine | Trạng thái ViewModel, mapper, giải mã DTO, câu lỗi | dưới 30 giây |
| Giao diện Android | Kaspresso 1.6.1 trên máy ảo | Đăng ký, đăng nhập, danh mục, hồ sơ, địa chỉ, giỏ, COD, thanh toán online, đơn hàng | vài phút |

Nguyên tắc chọn tầng: kiểm thử bất biến ở nơi một lỗi gây mất tiền hoặc sai tồn, không kiểm thử từng
route. Prisma không bao giờ bị mock ở tầng tích hợp — mọi kiểm thử tích hợp chạy trên MySQL thật với
lược đồ thật, vì phần lớn lỗi của hệ thống này nằm ở giao dịch và ràng buộc, không nằm ở tầng HTTP.

### 5.7.2. Cách ly dữ liệu kiểm thử

Kiểm thử tích hợp dùng một cơ sở dữ liệu riêng tên `stylo_test`, và global setup dừng ngay nếu tên
không khớp. Trước mỗi tệp kiểm thử, toàn bộ bảng bị truncate với `FOREIGN_KEY_CHECKS = 0`; mỗi ca kiểm
thử tạo dữ liệu của riêng nó qua factory với email, SKU và mã đơn duy nhất. Không có phụ thuộc thứ tự,
không có ID cố định, và không có `sleep`: thời gian được mô phỏng bằng cách sửa trực tiếp các cột thời
gian khi cần kiểm tra hết hạn hoặc cửa sổ báo cáo.

### 5.7.3. Kiểm thử giao diện

Năm hành trình Kaspresso, mỗi tệp một hành trình: khách vãng lai duyệt và tìm kiếm; khách hàng đăng ký,
đăng nhập, sửa hồ sơ, thêm địa chỉ; giỏ hàng và đặt COD; thanh toán online qua cổng mock; danh sách và
chi tiết đơn kèm huỷ đơn. Chúng chạy trên máy ảo `stylo_api35` với server thật và dữ liệu seed, đúng
như buổi demo.

Một chi tiết vận hành đáng ghi: trên máy phát triển này, cổng 5037 mặc định của adb nằm trong dải cổng
bị Windows giữ, nên cả máy ảo, adb và Gradle đều được chạy với biến `ANDROID_ADB_SERVER_PORT=5359`.
Ngoài ra công cụ điều khiển thiết bị dùng chung kết nối UiAutomation với Kaspresso, nên daemon của nó
phải được dừng trước khi chạy kiểm thử giao diện; cả hai điều kiện được gói trong một script chạy duy
nhất (`android/e2e.cmd`).

Một điều kiện nữa chỉ lộ ra khi chạy thật: bộ kiểm thử giả định app bắt đầu ở trạng thái khách, nên nếu
lần chạy trước kết thúc trong phiên quản trị thì bước đầu tiên treo cho tới hết thời gian chờ. Cách xử
lý là xoá dữ liệu app trước khi chạy (`adb shell pm clear com.stylo.shop`), không phải nới thời gian
chờ — nới ra chỉ giấu đi việc app đang ở sai màn hình.

## 5.8. Kết quả lần chạy cuối

Số liệu dưới đây là của lần chạy tại thời điểm đóng băng hồ sơ, trên máy phát triển nêu ở phụ lục B.
Không có số liệu nào được làm tròn hay suy đoán.

@table Kết quả kiểm thử tại thời điểm đóng băng
| Bộ kiểm thử | Số tệp | Số ca | Kết quả | Thời gian |
| Đơn vị backend | 7 | 57 | 57 đạt | 1,28 giây |
| Tích hợp backend | 13 | 197 | 197 đạt | 356 giây |
| JVM Android | 33 lớp | 190 | 190 đạt | 39 giây |
| Giao diện Android | 5 | 5 | 5 đạt | 135 giây |

Một lỗi thật đã được phát hiện và sửa trong chính lần chạy này, và nó đáng được ghi lại vì nó thuộc
loại lỗi chỉ lộ ra khi dữ liệu lớn lên: ca kiểm thử chạy seed đầy đủ rồi truy vấn qua endpoint công
khai bị quá thời gian chờ 30 giây của bộ kiểm thử. Nguyên nhân không phải seed chậm bất thường mà là
seed đã lớn — 185 sản phẩm, 546 biến thể, 140 đơn, hơn một nghìn dòng phiếu nhập — trong khi hạn mức
vẫn là con số đặt ra lúc danh mục còn nhỏ. Cách sửa là cho riêng ca kiểm thử đó một hạn mức 180 giây
kèm ghi chú giải thích, thay vì nâng hạn mức toàn bộ (điều sẽ che mất các ca chậm bất thường khác).
Sau khi sửa, cả 197 ca đạt.

### 5.8.1. Dữ liệu seed

Dữ liệu demo được sinh bằng một script có tính tất định: chạy lại cho ra đúng tập dữ liệu đó, cùng thứ
tự, cùng SKU. Nguồn là một bộ dữ liệu quần áo công khai, được lọc bỏ giày dép và chỉnh lại mô tả tiếng
Việt.

@table Thành phần dữ liệu seed
| Thực thể | Số lượng | Ghi chú |
| Danh mục | 4 | Ba danh mục đang bán (Áo, Quần, Áo khoác) và một danh mục ẩn (Phụ kiện) |
| Thương hiệu | 4 | Stylo, Basic Lab, Urban Viet, Local Brand |
| Sản phẩm | 185 | 95 áo, 60 quần, 30 áo khoác; 162 đang bán, 23 đã ẩn |
| Biến thể | 546 | Mỗi biến thể một SKU, size và màu riêng |
| Ảnh sản phẩm | 185 | Mỗi sản phẩm một ảnh, tệp cục bộ |
| Người dùng | 13 | Một quản trị và mười hai khách, trong đó một khách bị khoá |
| Đơn hàng | 140 | Trải trên cả năm trạng thái, có đơn COD và đơn online |
| Phiếu nhập kho | 3 | 1.156 dòng, đủ để tính giá vốn bình quân |
| Dòng sổ cái tồn | 1.478 | Khớp tuyệt đối với tồn hiện tại của mọi biến thể |

Tính đúng của sổ cái được kiểm bằng một truy vấn đối chiếu: tổng `delta` theo từng biến thể phải bằng
`stock`. Trên dữ liệu seed, số dòng lệch là 0.

### 5.8.2. Kiểm chứng hồ sơ nộp

Ba kiểm chứng dưới đây được chạy trên chính các tệp nộp kèm, không phải trên mã nguồn:

- **Tệp dump** được nạp vào một lược đồ rỗng, sau đó API được khởi động trỏ vào lược đồ đó: `/health`
  trả `ok`, danh sách sản phẩm trả 151 sản phẩm đang bán với trang đầu 20 dòng, bộ lọc trả đúng ba danh
  mục đang bán và chín kích cỡ. Toàn bộ đếm dòng của 17 bảng khớp với cơ sở dữ liệu gốc.
- **Sơ đồ ERD** được sinh từ lược đồ Prisma, không vẽ tay, nên nó khớp với cơ sở dữ liệu đang chạy.
- **Báo cáo PDF** được xuất từ Word với font nhúng, mục lục cập nhật, và số trang thân bài nằm trong
  khoảng yêu cầu.

## 5.9. Hồ sơ nộp

@table Các tệp trong hồ sơ nộp
| Tệp | Nội dung | Cách sinh |
| `BaoCao_Stylo.pdf` và `.docx` | Báo cáo này | Sinh từ nguồn Markdown bằng script, xuất PDF qua Word |
| `Slide_BaoVe.pptx` và `.pdf` | Slide bảo vệ 15 phút | Sinh từ script, xuất PDF qua PowerPoint |
| `ERD_Stylo_A3.pdf` | Sơ đồ ERD một trang A3 | Sinh từ lược đồ Prisma, in A3 ngang |
| `stylo-db.sql` | Dump cơ sở dữ liệu sau seed | `mysqldump --databases stylo` |
| `Stylo_Source.zip` | Mã nguồn, không gồm thư viện và tệp môi trường | Kết xuất từ git |
| `Demo_Stylo.mp4` | Video demo 5–10 phút trên máy ảo | Quay màn hình thiết bị |
