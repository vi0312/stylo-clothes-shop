# Phụ lục C. Các bước chạy lại hệ thống

Phần này đủ để một người khác dựng lại hệ thống từ một máy trống có sẵn Docker, Node.js và Android SDK.

## C.1. Cơ sở dữ liệu

```bash
docker run -d --name stylo-mysql -e MYSQL_ROOT_PASSWORD=root \
  -e MYSQL_DATABASE=stylo -e MYSQL_USER=stylo -e MYSQL_PASSWORD=stylo \
  -p 3306:3306 mysql:8.4
docker exec stylo-mysql mysql -ustylo -pstylo -e "CREATE DATABASE stylo_test"
```

Hai schema được dùng với hai mục đích khác nhau: `stylo` cho dữ liệu phát triển và demo, `stylo_test`
cho kiểm thử tích hợp. Kiểm thử tích hợp dừng ngay nếu tên schema không phải `stylo_test`, nên không có
cách nào vô tình xoá dữ liệu phát triển.

## C.2. API

```bash
cd server
npm install
cp .env.example .env        # điền DATABASE_URL, JWT secrets, PAYMENT_PROVIDER
npm run db:reset            # migrate + seed
npm run dev                 # API trên 127.0.0.1:8787
curl http://127.0.0.1:8787/health
```

`npm run db:reset` xoá và dựng lại schema rồi chạy seed. Seed có tính tất định: chạy hai lần cho ra
cùng tập dữ liệu, cùng thứ tự và cùng SKU. Nếu đổi danh mục seed, phải chạy lại `db:reset` thay vì chỉ
`db:seed`, vì thứ tự sinh SKU phụ thuộc thứ tự sinh sản phẩm.

## C.3. Ứng dụng Android

```bash
cd android
gradlew.bat :app:assembleDebug
adb -P 5359 install -r app/build/outputs/apk/debug/app-debug.apk
adb -P 5359 reverse tcp:8787 tcp:8787
```

Bản debug trỏ tới `http://127.0.0.1:8787`, tức là địa chỉ nhìn từ trong máy ảo; cầu `adb reverse` biến
nó thành kết nối tới máy phát triển. Nếu dùng cổng adb khác, đặt `ANDROID_ADB_SERVER_PORT` cho cả adb,
máy ảo và Gradle.

## C.4. Tài khoản demo

@table Tài khoản có sẵn trong dữ liệu seed
| Vai trò | Email | Mật khẩu |
| Quản trị | `admin@stylo.local` | `Admin@12345` |
| Khách hàng | `customer01@stylo.local` … `customer12@stylo.local` | `Customer@12345` |

Một trong mười hai khách có trạng thái `DISABLED` để minh hoạ việc khoá tài khoản. Mật khẩu trong dữ
liệu seed là mật khẩu demo, không dùng cho bất kỳ môi trường thật nào.

## C.5. Chạy kiểm thử

```bash
cd server && npm run test:unit && npm run test:integration
cd android && gradlew.bat :app:testDebugUnitTest
android\e2e.cmd                       # toàn bộ hành trình Kaspresso
android\e2e.cmd -Class OrdersJourneyTest   # một hành trình
```

Bộ kiểm thử giao diện cần máy ảo đang chạy, API đã lên và cầu `adb reverse` đã đặt. Script tự kiểm ba
điều kiện đó và dừng daemon điều khiển thiết bị trước khi gọi Gradle, vì Kaspresso và daemon đó không
thể cùng giữ kết nối UiAutomation.

## C.6. Dựng lại hồ sơ

```bash
python docs/report/build_report.py      # sinh BaoCao_Stylo.docx từ docs/report/content
python docs/report/export_pdf.py        # cập nhật mục lục và xuất PDF
python docs/report/tools/erd_from_schema.py --columns > docs/report/assets/erd.mmd
python docs/report/build_slides.py      # sinh Slide_BaoVe.pptx
```

Ba script đầu chỉ cần Python cùng Word; script ERD cần Mermaid CLI và một trình duyệt để dựng hình.
Nhờ vậy hồ sơ có thể dựng lại sau khi sửa nội dung, thay vì phải chỉnh tay trong Word.
