# Phụ lục B. Kịch bản demo và môi trường

## B.1. Kịch bản demo

Buổi demo chạy trực tiếp trên máy ảo với server nội bộ, tổng thời lượng khoảng mười lăm phút. Thanh
toán dùng cổng mock làm đường chính, vì IPN của VNPay không gọi được vào server chạy trên máy cá nhân;
adapter VNPay được trình bày ở mức mã nguồn và cấu hình.

@table Kịch bản demo theo mốc thời gian
| Mốc | Việc làm | Điều cần thấy |
| 0:00 | Khách vãng lai: trang chủ, tìm "ao thun" không dấu, lọc theo thương hiệu, mở chi tiết | Tìm không dấu vẫn khớp; bộ lọc kết hợp được; chi tiết nêu tồn theo biến thể |
| 3:00 | Đăng nhập, sửa hồ sơ, thêm địa chỉ và đặt làm mặc định | Địa chỉ đầu tiên tự thành mặc định; danh sách cập nhật ngay |
| 5:00 | Thêm vào giỏ, tăng số lượng tới trần tồn, đặt hàng COD | Bộ tăng giảm dừng ở tồn và hiện "Tối đa"; đơn xuất hiện trong danh sách |
| 8:00 | Quản trị: xem tổng quan, xác nhận một đơn đang chờ | Hộp thoại nêu rõ cặp trạng thái; danh sách đổi trạng thái sau khi xác nhận |
| 10:00 | Quản trị: mở biểu mẫu sản phẩm, xem danh sách sản phẩm, mở kho | Trạng thái đang bán và đã ẩn phân biệt được; phiếu nhập và tồn thấp cùng màn |
| 12:00 | Quản trị: năm báo cáo, đổi khoảng ngày | Doanh thu khớp với số đơn đã thanh toán; biểu đồ có bảng số liệu |
| 14:00 | Quản trị: khoá một khách, rồi thử đăng nhập bằng tài khoản đó | Đăng nhập bị từ chối với thông điệp tài khoản bị khoá |

Ba mẹo khi trình bày, rút ra từ chính các lần chạy thử: bật chế độ không làm phiền để thông báo hệ
thống không che màn hình; giữ máy ảo ở pin 100% và tắt âm thanh; và luôn có video dự phòng đã quay sẵn
phòng trường hợp mạng nội bộ gặp sự cố.

## B.2. Môi trường phát triển

@table Môi trường của lần chạy cuối
| Thành phần | Giá trị |
| Hệ điều hành | Windows 10 (10.0.26300), x64 |
| Java | Temurin JDK 17 |
| Android SDK | cmdline-tools 22.0, platform-tools 37.0.1, build-tools 35.0.0, platform android-36 |
| Máy ảo | `stylo_api35`, Android 15, 1080×1920 @ 480dpi (360×640dp) |
| Node.js | 24.22 |
| MySQL | 8.4 trong container Docker `stylo-mysql`, schema `stylo` và `stylo_test` |
| Cổng API | 8787, nối vào máy ảo bằng `adb reverse tcp:8787 tcp:8787` |
| Cổng adb | 5359, vì dải 4942–5041 bị Windows giữ nên cổng mặc định 5037 không dùng được |

## B.3. Cách ghi video

Video được ghi ngay trên máy ảo, không quay màn hình máy tính, nên hình ảnh đúng tỉ lệ thiết bị và
không lộ cửa sổ của công cụ phát triển.

1. Dựng lại ứng dụng bản debug và cài lên máy ảo.
2. Khởi động server, kiểm tra `/health`, đặt lại cầu `adb reverse`.
3. Bắt đầu `adb shell screenrecord` cho từng đoạn tối đa ba phút, vì công cụ này giới hạn độ dài mỗi
   tệp; các đoạn được nối lại bằng ffmpeg.
4. Chạy kịch bản ở mục B.1 với nhịp nghỉ khoảng một giây giữa các thao tác để người xem theo kịp.
5. Cắt phần thanh trạng thái ở đầu khung hình để không lộ thông báo hệ thống và đồng hồ, sau đó xuất
   MP4 một luồng hình.

Bản quay nộp kèm dài 5 phút 18 giây, khung 1080×1792, mở đầu và kết thúc bằng thẻ tiêu đề. Video gồm
hai lượt: lượt khách đi từ trang chủ, tìm kiếm không dấu, bộ lọc, chi tiết sản phẩm, đăng nhập, sổ địa
chỉ, giỏ hàng, đặt COD tới danh sách đơn; lượt quản trị đi từ đăng nhập, tổng quan, xác nhận đơn đang
chờ, danh sách sản phẩm, kho, năm báo cáo tới danh sách người dùng. Đơn trong video là Áo thun basic
S/Đen với số lượng ba, tổng 627.000 ₫ gồm 30.000 ₫ phí giao. Phần chặn trần tồn được trình bày khi demo
trực tiếp vì quay hết một biến thể sẽ làm cạn tồn của dữ liệu mẫu.
