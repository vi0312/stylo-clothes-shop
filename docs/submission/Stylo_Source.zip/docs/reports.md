# Reports

Source of truth for the semantics and SQL of the five admin reports, decided at
[ticket 10](../.scratch/stylo-app/issues/10-cong-thuc-gia-von.md). JSON shapes live in
[api.md](api.md#reports); tables and the `unit_cost` definition live in [erd.md](erd.md). This file owns
the numbers: which rows count, which date column, and what `NULL` means.

## Time basis

Every report takes inclusive calendar days `from`/`to` in `Asia/Ho_Chi_Minh` (UTC+7, no DST). The service
converts them to one half-open UTC window and every query uses the same one:

| Parameter | Meaning |
|---|---|
| `fromUtc` | `from 00:00:00` Vietnam = previous day `17:00:00` UTC |
| `toUtc` | `to + 1 day 00:00:00` Vietnam = `to` day `17:00:00` UTC, exclusive |

Example: `from=2026-11-01&to=2026-11-07` → `fromUtc='2026-10-31 17:00:00'`, `toUtc='2026-11-07 17:00:00'`.
Missing `from`/`to` defaults to the last 30 days including today.

Which column dates each report:

| Report | Date column | Why |
|---|---|---|
| revenue | `order.paid_at` | money recognised when paid |
| top products | `order.paid_at` | same population as revenue |
| orders by status | `order.created_at` | counts orders placed in the range |
| low stock | none | it is a snapshot of now |
| inventory cost | `paid_at` for `cogs`, `inventory_receipt.created_at` for `receiptsCost` | flow vs flow |

**COD revenue lands on the delivery date**, not the order date: `paid_at` is set by the
`SHIPPING → DELIVERED` transition. Online orders set it at `PENDING → CONFIRMED`. So a report for a day
shows what was paid that day, and reading it by order date will be off by the delivery lag. That is
intended; see [erd.md](erd.md) for the lifecycle.

`groupBy=month` buckets with `DATE_FORMAT(paid_at + INTERVAL 7 HOUR, '%Y-%m')`; a month is a Vietnamese
calendar month. Periods are always returned ascending and zero-filled: every day in the range, every month
in it, all five statuses. Zero-filling happens in the service, not in SQL, so an empty range still returns
the full shape. `revenue` defaults to `day`; `month` is allowed for any range.

## Money

All amounts are integer VND, no decimals. Aggregates come back from the MariaDB adapter as `BigInt` or
string, so every value is passed through `Number()` in the repository, the same way
[`catalog.repository.ts`](../server/src/modules/catalog/catalog.repository.ts) does for `MIN(price)`.
A `SUM` row can arrive as `null` for an empty range; coalesce before `Number()`.

## Revenue

`SUM(order.total)` and order count over paid orders, grouped by the Vietnamese date of `paid_at`.

```sql
SELECT DATE(paid_at + INTERVAL 7 HOUR) AS period,
       SUM(total) AS revenue,
       COUNT(*)  AS orders
FROM `order`
WHERE paid_at >= ? AND paid_at < ?
GROUP BY period
ORDER BY period;                                  -- `month`: DATE_FORMAT(paid_at + INTERVAL 7 HOUR, '%Y-%m')
```

`totalRevenue` and `totalOrders` are the sums of the returned series; no second query. Cancelled orders
never appear: `CANCELLED` requires `paid_at IS NULL`, and there is no refund flow, so a paid order is never
removed from revenue afterwards.

## Top products

Quantity first, revenue second, name third. Grouped by `product_id`, so one row per product even when sizes
and colours differ. Revenue uses the `unit_price` snapshot, not the current price.

```sql
WITH agg AS (
  SELECT oi.product_id,
         SUM(oi.quantity)                AS quantitySold,
         SUM(oi.unit_price * oi.quantity) AS revenue
  FROM order_item oi
  JOIN `order` o ON o.id = oi.order_id
  WHERE o.paid_at >= ? AND o.paid_at < ?
  GROUP BY oi.product_id
), latest AS (
  SELECT oi.product_id, oi.product_name,
         ROW_NUMBER() OVER (PARTITION BY oi.product_id ORDER BY o.paid_at DESC, oi.id DESC) AS rn
  FROM order_item oi
  JOIN `order` o ON o.id = oi.order_id
  WHERE o.paid_at >= ? AND o.paid_at < ?
)
SELECT a.product_id AS productId, l.product_name AS name, a.quantitySold, a.revenue
FROM agg a
JOIN latest l ON l.product_id = a.product_id AND l.rn = 1
ORDER BY a.quantitySold DESC, a.revenue DESC, l.product_name ASC
LIMIT ?;                                          -- default 10, max 50
```

`name` is the snapshot from the most recent paid line, so a renamed or deactivated product still reports
under the name it was sold as. `INACTIVE` products stay in the list: they were sold, and hiding them would
break the sum.

## Orders by status

Orders **created** in the range, counted by their current status. `total` is `SUM(order.total)` of that
group, including `CANCELLED` — it shows value that never converted.

```sql
SELECT status, COUNT(*) AS count, SUM(total) AS total
FROM `order`
WHERE created_at >= ? AND created_at < ?
GROUP BY status;
```

The service emits all five statuses in enum order `PENDING, CONFIRMED, SHIPPING, DELIVERED, CANCELLED`,
with `count: 0, total: 0` when absent. Because the date column is `created_at`, an order created in October
and delivered in November counts in October's `DELIVERED` bucket.

## Low stock

Snapshot of now, no range. Variants of `ACTIVE` products at or below the threshold.

```sql
SELECT v.id AS variantId, v.sku, p.name AS productName, v.size, v.color, v.stock
FROM product_variant v
JOIN product p ON p.id = v.product_id
WHERE p.status = 'ACTIVE' AND v.stock <= ?
ORDER BY v.stock ASC, v.sku ASC;
```

The threshold is the `threshold` query param (0–1000) or `LOW_STOCK_THRESHOLD` (default 5). `stock = 0` is
included: it is the strongest signal. There is no index on `stock`; at seed scale (tens of variants) the
scan is fine and is recorded as a known limitation rather than optimised.

## Inventory cost

Four numbers, mixed bases made explicit:

```sql
-- receiptsCost: purchase money that entered stock in the range
SELECT COALESCE(SUM(iri.quantity * iri.unit_cost), 0) AS receiptsCost
FROM inventory_receipt_item iri
JOIN inventory_receipt ir ON ir.id = iri.receipt_id
WHERE ir.created_at >= ? AND ir.created_at < ?;

-- cogs: snapshot cost of what was sold and paid in the range
SELECT COALESCE(SUM(oi.quantity * COALESCE(oi.unit_cost, 0)), 0) AS cogs
FROM order_item oi
JOIN `order` o ON o.id = oi.order_id
WHERE o.paid_at >= ? AND o.paid_at < ?;

-- revenue: the revenue report's totalRevenue, same window
SELECT COALESCE(SUM(total), 0) AS revenue
FROM `order`
WHERE paid_at >= ? AND paid_at < ?;
```

`grossProfit = revenue - cogs`. `receiptsCost` is a purchase-flow figure and is deliberately not part of
the profit formula: stock bought this month may sell next month.

### `unit_cost` is `NULL`

`unit_cost` is `NULL` when the variant had never been received at the moment of sale. Sales only ever draw
on stock, and stock only grows through inventory receipts (seed included), so a paid order item with a
`NULL` cost is not reachable through the app. The policy therefore treats it as `0` and guards the
assumption with an invariant test, rather than returning an error or changing the response shape:

```sql
SELECT COUNT(*) AS offending
FROM order_item oi JOIN `order` o ON o.id = oi.order_id
WHERE o.paid_at IS NOT NULL AND oi.unit_cost IS NULL;   -- must be 0 in every seeded state
```

The reports integration test asserts `offending = 0` after the seed and after each checkout it drives, so a
future path that sells unreceived stock fails the suite instead of quietly inflating `grossProfit`.

## Limitations

- `revenue` and therefore `grossProfit` include the flat `shipping_fee`; `cogs` has no delivery cost, so
  profit is overstated by the shipping fee of each paid order. Documented, not corrected: the shape is
  fixed and there is no shipping cost model.
- No returns or refunds in scope, so revenue is never reduced after payment.
- `unit_cost` is a snapshot; later receipts never rewrite history.
- Colour and size are stored as text; the low-stock report groups nothing and needs no normalisation.

## Verification

Checked against the dev MySQL 8.4 container on 2026-11-07 inside a transaction that was rolled back
(`stylo` schema, 1 order + 1 receipt at the time):

- fixture: three `DELIVERED`/COD orders paid at `2026-11-06 17:30Z`, `2026-11-07 16:59Z`, `2026-11-07 17:00Z`
  for the window `from=2026-11-01&to=2026-11-07` → revenue returned one bucket `2026-11-07`, `revenue=560000`,
  `orders=2`: the first two are the Vietnamese 7th, the third is Vietnamese 8th 00:00 and correctly excluded;
- `cogs` = `2×100000 + 2×90000 + 1×NULL` = `380000`, proving `COALESCE` counts the unknown row as zero;
- top products returned one row `quantitySold=4, revenue=500000` (snapshot prices `150000`/`100000`);
- the `NULL`-cost invariant reported `offending=1` for that fixture, so the assertion is meaningful;
- after `ROLLBACK` the table was back to 1 order.
